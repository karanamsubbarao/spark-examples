/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $$Rev: 7137 $$
Last Modified: $$Date: 2007-02-21 12:14:19 +0530 (Wed, 21 Feb 2007) $$
Last Modified By: $$Author: smariswamy $$
*/

package com.wyse.rapport.services;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import com.wyse.rapport.services.command.IDeviceContactService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;

public class SpringApplicationContext {
    private static ApplicationContext context;

    private SpringApplicationContext() {
    }

    public static ApplicationContext getWebApplicationContext() {
        return context;
    }

    public static void setWebApplicationContext(ApplicationContext ctx) {
        assert ctx != null;
        context = ctx;
    }

    public static SchedulerService schedulerService() {
        return (SchedulerService) context.getBean("scheduler");
    }

    public static IDeviceRepository repositoryServiceSessionPerThread() {
        return (IDeviceRepository) context.getBean("deviceRepositoryUsingSessionPerThread");
    }
    
    public static IDeviceContactService deviceContactService() {
        return (IDeviceContactService) context.getBean("deviceContactService");
    }
    
    public static ISystemLogService getSystemLogServicePerThread() {
        return (ISystemLogService) context.getBean("systemLogServicePerThread");
    }

	public static MessageSource getMessageResource() {
		return (ReloadableResourceBundleMessageSource) context.getBean("messageSource");
	}
}
