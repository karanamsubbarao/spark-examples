/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 4071 $
Last Modified: $Date: 2006-05-16 12:38:50 +0530 (Tue, 16 May 2006) $
Last Modified By: $Author: kquinto $
*/

package com.wyse.rapport.services;

import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

import com.wyse.common.UUIDGenerator;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Schedule;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.services.persistence.IDeviceRepository;

/**
 *
 */
public class SchedulerService implements ISchedulerService {
	
	private static Logger log = Logger.getLogger(SchedulerService.class);
	private Scheduler scheduler ;

    public SchedulerService(IDeviceRepository deviceRepository) {
    	SchedulerFactory sf = new StdSchedulerFactory();
        try {
			scheduler = sf.getScheduler(); 
			scheduler.start();
			Collection<DeviceInfo> devices = deviceRepository.findNewDevices();
			for (DeviceInfo device : devices) {
				List<Task> tasks = device.getTasks();
				if(tasks.size() > 0){
					log.info("Re-creating the scheduled jobs for device - "+device.getActiveIp());
				}
				for (Task task : tasks) {
					schedule(device, task);
				}
			}
		} catch (SchedulerException e) {
			log.error("Failed to create and start the scheduler "+e.getMessage());
			
		}
                
    }

    public void schedule(Device device, Task task) {
        JobDetail job = wdmJob(device, task);
        try {
        	Schedule schedule = task.getSchedule();
        	if(task.isExecutable()){
        		schedule.executeNow();
        	}
        	scheduler.scheduleJob(job, schedule.trigger());
		} catch (SchedulerException e) {
			log.error("Failed to schedule job "+e.getMessage());
		}
    }

    public void unschedule(Task task) {
    	Schedule schedule = task.getSchedule();
    	try {
			scheduler.unscheduleJob(schedule.getJobName(), Schedule.SCHEDULER_GROUP_NAME);
		} catch (SchedulerException e) {
			log.error("Failed to remove the schedule for task "+task.getName());
		}
	}
    
    private JobDetail wdmJob(Device device, Task task) {
    	JobDetail job = new JobDetail();
        job.setJobClass(SchedulerJob.class);
        job.setName(task.getName() + new UUIDGenerator().generate());
        job.getJobDataMap().put("deviceGuid", device.getDeviceGuid());
        job.getJobDataMap().put("taskId", task.getTaskId());
        return job;
    }
	
}
