/*
 Copyright (c) 2005 Wyse Technology, Inc.
 Current Revision: $$Rev$$
 Last Modified: $$Date$$
 Last Modified By: $$Author$$
 */

package com.wyse.rapport.services.command;

import java.net.ConnectException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.Date;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.common.UUIDGenerator;
import com.wyse.rapport.businesslogic.DeviceRequestParser;
import com.wyse.rapport.businesslogic.httpclient.ConnectionTimeoutException;
import com.wyse.rapport.command.ELegacyCommand;
import com.wyse.rapport.command.SetMonitorServerCommand;
import com.wyse.rapport.command.StartDialogFromDeviceCommand;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.IThreadPoolService;
import com.wyse.rapport.services.deviceinterface.Event;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.util.WDMUtil;
import com.wyse.rapport.util.XmlUtil;

public class DeviceContactService implements IDeviceContactService {
	private IThreadPoolService threadPoolService;
	private IHibernateSessionService sessionServicePerThread;
	private Logger log = Logger.getLogger(DeviceContactService.class);
	ISystemLogService systemLogService;
	private static final int SET_SERVER_RETRY_COUNT = 3;
	
	public DeviceContactService(IHibernateSessionService sessionServicePerThread, IThreadPoolService threadPoolService, ISystemLogService systemLogService) {
		this.sessionServicePerThread = sessionServicePerThread;
		this.threadPoolService = threadPoolService;
		this.systemLogService = systemLogService;
	}
	
	public void sendLegacyCommand(Device device,ELegacyCommand command) {
		Runnable contactDeviceThread = new SendCommandToLegacyDeviceThread(device.getDeviceGuid(), command.command((DeviceInfo)device));
		logInfo("Sending "+command.name()+" command ", device);
		threadPoolService.submitJob(contactDeviceThread);
	}
	
	private void logInfo(String msg, Device device) {
		systemLogService.info(msg,device);
	}
	
	public void contactDevice(Device device) {
		Task lastExecutedTask = device.getLastExecutedTask();
		if (!device.hasTaskInProgress() ){
			if(lastExecutedTask.isEmptyTask() || device.hasNextTaskExecutable(lastExecutedTask)){
				submitContactDeviceThread(device);
			}
		}
	}
	
	private void submitContactDeviceThread(Device device) {
		Runnable contactDeviceThread = new ContactDeviceThread(device.getDeviceGuid(), false);
		threadPoolService.submitJob(contactDeviceThread);
	}
	
	public void changeCheckinInterval(Collection<DeviceInfo> devices, long checkinIntervalInSeconds) {
		for (Device device : devices) {
			device.setNextAssetReportTime(new Date(), checkinIntervalInSeconds);
			Runnable contactDeviceThread = new ContactDeviceThread(device.getDeviceGuid(), true);
			threadPoolService.submitJob(contactDeviceThread);
		}
	}
	
	private void deviceNotReachable(Device device, Exception e) {
		String ipAddress = device.getActiveIp();
		log.error("Failed to contact device with ip address (" + ipAddress + "); cause : "+e.getMessage());
		if(ipAddress != null) {
			systemLogService.error(device.getCurrentTask().getName()+" is failed ; cause : device not reachable.",device);
			device.notReachable(ipAddress);
		}
	}
	
	String sendCommand(Device device, String command, IDeviceCommunicationService communicationService) {
		int noOfRetry = 1;
		String ipAddress = device.getActiveIp();
		while (noOfRetry <= SET_SERVER_RETRY_COUNT) {
			try {
				String response = sendCommand(ipAddress, communicationService, command);
				log.info("Recieved Response from device "+ipAddress+" - "+response);
				device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
				return response;
			} catch (Exception e) {
				log.error("Contacting Device " + ipAddress + " is failed - retry count : " + noOfRetry);
				noOfRetry++;
				assert device != null;
				if (noOfRetry > SET_SERVER_RETRY_COUNT) {
					throw new ConnectionTimeoutException(e.getMessage());
				}
			}
		}
		return null;
	}
	
	public String messageWithStartDialog(Device device, String dialogGuid) {
		return WDMUtil.wdmMessage(new StartDialogFromDeviceCommand(dialogGuid, WDMUtil.getWDMServerUrl(), "WDM Server"));
	}
	
	String sendCommand(String ipAddress, IDeviceCommunicationService communicationService, String command) throws UnknownHostException {
		return communicationService.sendCommand(InetAddress.getByName(ipAddress), command);
	}
	
	public class SendCommandToLegacyDeviceThread implements Runnable {
		private String deviceGuid;
		private String command;
		
		SendCommandToLegacyDeviceThread(String deviceGuid, String command) {
			this.deviceGuid = deviceGuid;
			this.command = command;
		}
		
		public void run() {
			Device device = null;
			String ipAddress = null;
			try {
				device = (Device) sessionServicePerThread.find(DeviceInfo.class, deviceGuid);
				ipAddress = device.getActiveIp();
				IDeviceCommunicationService communicationService = new LegacyDeviceCommunicationService();
				sendCommand(ipAddress, communicationService, command);
			} catch (Exception e) {
				if (device != null) {
					deviceNotReachable(device, e);
				}
			} finally {
				try{
					sessionServicePerThread.closeSession();
				}catch (Exception e) {
					log.info("Error while closing HibernateSessionPerThread : "+e.getMessage());
				}
			}
		}
	}
	
	public class ContactDeviceThread implements Runnable {
		private String deviceGuid;
		private boolean changeCheckinInterval;
		
		ContactDeviceThread(String deviceGuid, boolean changeCheckinInterval) {
			this.deviceGuid = deviceGuid;
			this.changeCheckinInterval=changeCheckinInterval;
		}
		
		public void run() {
			Device device = null;
			try {
				device = (Device) sessionServicePerThread.find(DeviceInfo.class, deviceGuid);
				contactDevice(device);
			}catch (Exception e) {
				log.info("Error while contacting the device : "+e.getMessage());
			} finally {
				try{
					sessionServicePerThread.closeSession();
				}catch (Exception e) {
					log.info("Error while closing HibernateSessionPerThread : "+e.getMessage());
				}
			}
		}
		
		void contactDevice(Device device) {
			try{
				IDeviceCommunicationService communicationService;
				if (device.isLegacy()) {
					communicationService = new LegacyDeviceCommunicationService();
					sendCommand(device,ELegacyCommand.FULL_CHECKIN.command(null), communicationService);
				} else if(changeCheckinInterval){
	                communicationService = new DeviceCommunicationService();
	                sendCommand(device, WDMUtil.wdmMessage(new SetMonitorServerCommand(WDMUtil.getWDMServerUrl(), 5)), communicationService);
				} else {
					if(device.isWtosDevice() && RapportServer.isWNOMProduct()) 
						{
							contactWtosDevice(device);
						}else 
						{
							contactNonWtosDevice(device);
						}
				}

			}catch (Exception e) {
				if ((e instanceof ConnectException) || e instanceof ConnectionTimeoutException) {
					if(!device.getCurrentTask().isWtosImagingTask()){
						deviceNotReachable(device, e);
					}
				}
			}
		}
	}
	
	
	private void contactWtosDevice(Device device) {
		String command = WDMUtil.wdmMessage(new SetMonitorServerCommand(WDMUtil.getWDMServerUrl(), SetMonitorServerCommand.DEFAULT_NEXT_ASSET_REPORT_INTERVAL));
		IDeviceCommunicationService communicationService = new DeviceCommunicationService();
		String response = sendCommand(device, command, communicationService);
		if(response != null) {
			device.setDisplayStatus(DeviceDisplayStatus.BUSY);
		}
	}
	
	private void contactNonWtosDevice(Device device) {
		String dialogGuid=new UUIDGenerator().generate();
		String command = messageWithStartDialog(device, dialogGuid);
		IDeviceCommunicationService communicationService = new DeviceCommunicationService();
		String response = sendCommand(device, command, communicationService);
		device.setDialogGuid(dialogGuid);
		if(response!=null && hasStartDialogError(XmlUtil.document(response))){
			device.setDisplayStatus(DeviceDisplayStatus.BUSY);
			device.setDialogGuid(null);
		}
	}
	public boolean hasStartDialogError(Document document) {
		return new Event(document, new DeviceRequestParser()).hasError();
	}
	
	public void setSystemLogService(ISystemLogService systemLogService) {
		this.systemLogService = systemLogService;
	}
}
