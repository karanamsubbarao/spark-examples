/**
 * Copyright (c) Wyse Technology, Inc.
 * Current Revision: $Rev: 5128 $
 * Last Modified: $Date: 2006-09-01 14:17:37 +0530 (Fri, 01 Sep 2006) $
 * Last Modified By: $Author: myadav $
 */

package com.wyse.rapport.services.command;

import java.net.InetAddress;

import com.wyse.rapport.businesslogic.httpclient.HttpNioConnection;
import com.wyse.rapport.server.RapportServer;

/** This is the class which will talk to Legacy device agent using Socket Communication. */
public class LegacyDeviceCommunicationService extends ADeviceCommunicationService {
	public LegacyDeviceCommunicationService(InetAddress address, String command) {
		super(address, command);
	}

	public LegacyDeviceCommunicationService() {
		super();
	}

	/**
	 * Thid method will do the actual communication part to the agent. sends the
	 * command string to the device agent and receives the acknowledgement.
	 *
	 * @param deviceAddress socket address where device agent is listening, including host
	 *                      and port
	 * @param command       command string sent to the device
	 *
	 * @return true if the device successfully acknowledged the command. This
	 *         does not mean that the command is actually completed.
	 */
	public String sendCommand(InetAddress deviceAddress, String command) {

		int port = RapportServer.getLegacyAgentPort();
		HttpNioConnection con = new HttpNioConnection(deviceAddress.getHostName(), port);
		return con.sendLegacyMessage(command);
	}
}

