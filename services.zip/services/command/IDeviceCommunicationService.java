/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 4183 $
 Last Modified: $Date: 2006-05-26 01:06:44 +0530 (Fri, 26 May 2006) $
 Last Modified By: $Author: kquinto $
 */

package com.wyse.rapport.services.command;

import java.io.Writer;
import java.net.InetAddress;

/** Interface for low level communication with a device. */
public interface IDeviceCommunicationService extends Runnable {
    public String sendCommand(InetAddress addrNetwork, String command);

    public void sendResponse(Writer writer, String command);

    public void wakeOnLan(String macAddress);
}