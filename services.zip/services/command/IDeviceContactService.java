/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.command;

import java.util.Collection;

import com.wyse.rapport.command.ELegacyCommand;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceInfo;

public interface IDeviceContactService {
    public void sendLegacyCommand(Device device, ELegacyCommand command);

    public void contactDevice(Device device);

    public void changeCheckinInterval(Collection<DeviceInfo> devices,
                                      long checkinIntervalInSeconds);
}