/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 3186 $
 Last Modified: $Date: 2005-12-13 18:28:25 +0530 (Tue, 13 Dec 2005) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.command;

import java.io.IOException;
import java.io.Writer;
import java.net.InetAddress;

import org.apache.log4j.Logger;

import com.wyse.rapport.businesslogic.wol.WakeOnLAN;
import com.wyse.rapport.util.XmlUtil;

/** @author smariswamy */
public abstract class ADeviceCommunicationService implements IDeviceCommunicationService {
    private InetAddress address;
    private String command;
    protected static Logger log = Logger.getLogger(DeviceCommunicationService.class);

    public ADeviceCommunicationService(InetAddress address, String command) {
        this.address = address;
        this.command = command;
    }

    public ADeviceCommunicationService() {

    }

    public void wakeOnLan(String macAddress) {
        new WakeOnLAN().wakeUpDevice(macAddress);
    }

    public void run() {
        sendCommand(address, command);
    }
    
    public void sendResponse(Writer writer, String command) {
		log.info("Response before validating: "+command);
    	if(XmlUtil.validate(command)){
	        writeResponse(writer, command);
    	}
    }
    
	private void writeResponse(Writer writer, String command) {
		try {
			log.info("Sending Response after validating: "+command);
		    writer.write(command);
		} catch (IOException e) {
		    throw new RuntimeException("Unexpected error sending response to device ", e);
		} finally {
		    try {
		        writer.close();
		    } catch (IOException e) {
		        //do nothing
		    }
		}
	}
}
