/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 5451 $
Last Modified: $Date: 2006-09-21 19:22:37 +0530 (Thu, 21 Sep 2006) $
Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.command;

import java.net.InetAddress;

import com.wyse.rapport.businesslogic.httpclient.HttpNioConnection;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.util.XmlUtil;

public class DeviceCommunicationService extends ADeviceCommunicationService {

	public DeviceCommunicationService() {
		super();
	}

	public String sendCommand(InetAddress addrNetwork, String command) {
		if(XmlUtil.validate(command)){
			log.info("Sending the command to device "+ addrNetwork.getHostAddress()+" --> "+ command);
			HttpNioConnection client = new HttpNioConnection(addrNetwork.getHostName(), RapportServer.getWDMAgentPort());
			return client.send(command);
		}
		log.error("Validation failed for command "+command+" : not sending to device "+ addrNetwork.getHostAddress());
		return null;
	}
}
