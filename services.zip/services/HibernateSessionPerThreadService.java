/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 6246 $
Last Modified: $Date: 2006-11-18 14:59:57 +0530 (Sat, 18 Nov 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 * The session per thread hibernate session service. Obtains a session bound with a thread.
 * It is necessary to call closeSession() once a thread is done with using the current session.
 */
public class HibernateSessionPerThreadService extends AHibernateSessionService {
    private SessionFactory sessionFactory;
    private static ThreadLocal<Session> sessions = new ThreadLocal<Session>();

    public HibernateSessionPerThreadService(SessionFactory factory) {
        sessionFactory = factory;
    }

    protected Session currentSession() {
        if (sessions.get() == null) {
            sessions.set(sessionFactory.openSession());
        }
        return (Session) sessions.get();
    }

    public void closeSession() {
        if (sessions.get() != null) {
            closeCurrentSession();
            clearSession();
        }
    }
    
    private void closeCurrentSession() {
        currentSession().flush();
        currentSession().close();
    }

    public void closeSessionWithoutFlush() {
        if (sessions.get() != null) {
        	currentSession().close();
        	clearSession();
        }
    }

    void clearSession() {
        sessions.remove();
    }
    
	public void clear() {
		currentSession().clear();
	}

}
