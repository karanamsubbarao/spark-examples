/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 6334 $
Last Modified: $Date: 2006-11-22 14:34:39 +0530 (Wed, 22 Nov 2006) $
Last Modified By: $Author: skaranam $
*/

package com.wyse.rapport.services.discovery;

import java.io.StringWriter;
import java.io.Writer;
import java.net.InetAddress;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Node;

import com.wyse.rapport.command.DiscoverDeviceCommand;
import com.wyse.rapport.command.GetAssetsCommand;
import com.wyse.rapport.command.SetMonitorServerCommand;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.deviceinterface.EventChainFactory;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IDiscoveryProgressRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.util.OSTypes;
import com.wyse.rapport.util.WDMUtil;
import com.wyse.rapport.util.XmlUtil;

/** Understands discovering Rapport 5 devices. */
public class DeviceDiscoveryService implements IDeviceDiscoveryService {
    private Logger log = Logger.getLogger(DeviceDiscoveryService.class);
    private IDeviceRepository deviceRepository;
    private IDiscoveryProgressRepository discoveryProgressRepository;
    private IDeviceCommunicationService deviceCommunicationService;
    private EventChainFactory eventChainFactory;
    private IUserPreferencesRepository settingsRepository;

    public DeviceDiscoveryService(IDeviceRepository deviceRepository,
                                  IDeviceCommunicationService deviceCommunicationService,
                                  IDiscoveryProgressRepository deviceProgressRepository,
                                  EventChainFactory eventChainFactory,
                                  IUserPreferencesRepository settingsRepository) {
        this.deviceRepository = deviceRepository;
        this.deviceCommunicationService = deviceCommunicationService;
        this.discoveryProgressRepository = deviceProgressRepository;
        this.eventChainFactory = eventChainFactory;
        this.settingsRepository = settingsRepository;
    }

    public void discover(InetAddress address) {
        if(!deviceRepository.isLicenseLimitExceeded()){
            String discoverDeviceDetails = sendDiscoverDeviceCommand(address);
            try {
	                Document document = DocumentHelper.parseText(discoverDeviceDetails);
	                log.info("Recieved response from device" + document.asXML() );
	                if(XmlUtil.validateWithDebugLog(document, address.getHostAddress())) {
	                	if(RapportServer.isWNOMProduct() && isWTOSDevice(document)) {
	                		handleFullAssetInformation(address, document);
	                	}else {		
	                		handleFullAssetInformation(address, document);
	                	}
	                }
            } catch (DocumentException e) {
                log.info("Error while processing the response (" + discoverDeviceDetails + ") from device " + address.getHostAddress());
                throw new RuntimeException(e);
            }
        }else{
            log.info("License Limit of Max number of devices " + RapportServer.licenseLimit() + " exceeded" );
        }
    }

	private void handleFullAssetInformation(InetAddress address, Document document) {
		handleRequest(document, new StringWriter(), address.getHostAddress());
		discoveryProgressRepository.discovered(address.getHostAddress());
		sendSetMonitorServerCommand(address);
	}

    private String sendSetMonitorServerCommand(InetAddress address) {
        long checkinInterval = new UserPreferences(settingsRepository).getCheckinIntervalInSeconds();
        String setMonitorCommand = WDMUtil.wdmMessage(new SetMonitorServerCommand(WDMUtil.getWDMServerUrl(), checkinInterval));
        return deviceCommunicationService.sendCommand(address, setMonitorCommand);
    }

    private String sendDiscoverDeviceCommand(InetAddress address) {
        String discoverDeviceDetails = WDMUtil.wdmMessage(new DiscoverDeviceCommand(GetAssetsCommand.FULL));
        return deviceCommunicationService.sendCommand(address, discoverDeviceDetails);
    }

	Device handleRequest(Document xmlDoc, Writer writer, String socketAddress) {
        DeviceInfo device = eventChainFactory.createChain().handleRequest(xmlDoc, writer);
        if (device != null) {
            if(deviceRepository.isExistingDevice(device) || !deviceRepository.isLicenseLimitExceeded()){
                updateDeviceInfo(socketAddress, device);
            }else{
                log.info("License Limit of Max number of devices " + RapportServer.licenseLimit() + " exceeded" );
            }
        }
        
        return device;
    }

    private void updateDeviceInfo(String socketAddress, Device device) {
        device.setActiveNetwork(socketAddress);
        device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
        deviceRepository.createOrUpdate((DeviceInfo) device);
    }
    
	private String osName(Document document) {
		Node osName = document.selectSingleNode("//assetSet/deviceReport/deviceStatus/osName");
		return osName == null ? null : osName.getText();
	}
	
	public boolean isWTOSDevice(Document document) {
		String osName = osName(document);
		return osName == null ? false: OSTypes.WTOS.equals(osName);
	}
	
}
