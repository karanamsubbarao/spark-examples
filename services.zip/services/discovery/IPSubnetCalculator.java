/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 4383 $
 Last Modified: $Date: 2006-06-22 12:41:41 +0530 (Thu, 22 Jun 2006) $
 Last Modified By: $Author: myadav $
 */

package com.wyse.rapport.services.discovery;

import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;

import com.wyse.rapport.businesslogic.iprange.IPRange;
import com.wyse.rapport.db.tbl.Subnet;
import com.wyse.rapport.util.IPAddressUtil;

/**
 * IPSubnetCalculator calculates the IPADDRESS range from a given subnet mask and host
 * address for Class A, Class B and Class C network Class Address Ranges:- Class
 * A ----> (1.0.0.0 - 126.0.0.0) Class B ----> (128.0.0.0 - 191.255.0.0) Class C
 * ----> (192.0.1.0 - 223.255.255.0)
 *
 * @author smariswamy
 */
public class IPSubnetCalculator {
    /** Number of network bits in Class A (Host bits count is 24) */
    private static int CLASS_A_NETWORK_BITS = 8;
    /** Number of network bits in Class B (Host bits count is 16) */
    private static int CLASS_B_NETWORK_BITS = 16;
    /** Number of network bits in Class B (Host bits count is 16) */
    private static int CLASS_C_NETWORK_BITS = 24;
    private String subnetMask;
    private String ipAddress;
    private IPRange ipRange;

    public IPSubnetCalculator(String subnetMask, String ipAddress) {
        this.subnetMask = subnetMask;
        this.ipAddress = ipAddress;
        ipRange = calculateIPRange();
    }

    public IPSubnetCalculator(Subnet subnet) {
        this(subnet.getSubnetMask(), subnet.getIpAddress());
    }

    public IPRange ipRange() {
        return ipRange;
    }

    public String broadcastAddress() {
        int[] subnetBits = subnetAddressArray();
        String binarySubnetBits = "";
        for (int subnetBit : subnetBits) {
            binarySubnetBits += toBinaryString(subnetBit);
        }
        String binaryHostBits = binarySubnetBits.substring(networkBits());
        String binaryBroadcastAddress = binarySubnetBits.substring(0, networkBits()) +
                                        StringUtils.replace(binaryHostBits, "0", "1");
        return broadcastAddress(binaryBroadcastAddress);
    }

    /**
     * Calculates the number of hosts allowed in each subnet of the subnet mask.
     * (2 to the power n) - 2 where n is the number of host bits
     *
     * @return - number of expected hosts in each subnet of this <i>subnetMask</i>
     */
    long numberOfHostsPerNetwork() {
        return (long) (Math.pow(2, hostBits()) - 2);
    }

    private IPRange calculateIPRange() {
        subnetMask = this.correctMask();
        String networkAddress = this.subnetAddress();
        long noOfHostsPerNet = this.numberOfHostsPerNetwork();
        String startIP = startIP(networkAddress);
        String endIP = endIP(startIP, noOfHostsPerNet);
        return new IPRange(startIP, endIP);
    }

    /**
     * Validates the <i>subnetMask</i> and calculates the correct subnet mask
     * if the given subnetmask is not a valid one
     *
     * @return a string representing a valid subnet mask
     */
    String correctMask() {
        int[] maskArr = IPAddressUtil.subnetMaskArray(subnetMask);
        // Any octet value in the subnet mask should not be less than 128
        // because all the bits in an octet can not be 0s
        if (maskArr[0] < 128) {
            maskArr[0] = 0;
        } else if (maskArr[1] < 128) {
            maskArr[1] = 0;
        } else if (maskArr[2] < 128) {
            maskArr[2] = 0;
        } else if (maskArr[3] < 128) {
            maskArr[3] = 0;
        }

        // If any of the octet has some network bits and some host bits the next
        // octet can not have any network bits
        if (maskArr[0] < 255) {
            maskArr[1] = 0;
            maskArr[2] = 0;
            maskArr[3] = 0;
        } else if (maskArr[1] < 255) {
            maskArr[2] = 0;
            maskArr[3] = 0;
        } else if (maskArr[2] < 255) {
            maskArr[3] = 0;
        }

        subnetMask = maskArr[0] + "." + maskArr[1] + "." + maskArr[2] + "." + maskArr[3];
        return subnetMask;
    }

    /**
     * Returns character 'A', 'B', 'C' depending on the first octet value
     * belongs to which class of network
     *
     * @param hostAddress host address which indecates to which class the IPADDRESS belongs
     *
     * @return a charecter representing the class too which the host belongs
     */
    private char ipAddressClass(String hostAddress) {
        StringTokenizer st = new StringTokenizer(hostAddress, ".");
        int firstOctet = Integer.parseInt(st.nextToken());
        if (firstOctet >= 192 && firstOctet <= 223) {
            return 'C';
        } else if (firstOctet >= 128 && firstOctet <= 191) {
            return 'B';
        } else if (firstOctet >= 1 && firstOctet < 127) {
            return 'A';
        }
        return ' ';
    }

    /**
     * Calculates and returns the network address for the given subnet mask and
     * host address given by ANDing their octets
     *
     * @return - network address
     */
    public String subnetAddress() {
        return addressFormat(subnetAddressArray());
    }

    private String addressFormat(int[] addressBits) {
        String address = "";
        for (int addressBit : addressBits) {
            address += addressBit + ".";
        }
        return StringUtils.chomp(address, ".");
    }

    private int[] subnetAddressArray() {
    	int[] subnetAddress;
    	subnetAddress = new int[4];
    	int[] subnetTokens = IPAddressUtil.subnetMaskArray(subnetMask);
    	int[] ipTokens = IPAddressUtil.ipAddressArray(ipAddress);
    	for (int i = 0; i < subnetAddress.length; i++) {
    		subnetAddress[i] = subnetTokens[i] & ipTokens[i];
    	}
    	return subnetAddress;
    }

	private String broadcastAddress(String binaryString) {
        String broadcastAdd = "";
        for (int i = 0; i < 4; i++) {
            int index = 8 * i;
            String substring = binaryString.substring(index, index + 8);
            broadcastAdd += String.valueOf(Integer.parseInt(substring, 2)) + ".";
        }
        return StringUtils.chomp(broadcastAdd, ".");
    }

    private String toBinaryString(int firstBit) {
        String binaryString = Integer.toBinaryString(firstBit);
        int length = binaryString.length();
        if (length < 8) {
            binaryString = getOctact(binaryString, (8 - length));
        }
        return binaryString;
    }

    private String getOctact(String binaryString, int len) {
        String str = "";
        for (int i = 0; i < len; i++) {
            str = str + "0";
        }
        return str + binaryString;
    }

    /**
     * Calculates the number of possible sub networks allowed in a subnet mask.
     * For Class A and B ---> (2 to the power n)-2 For Class C ---> 2 to the
     * power n n - the number of host bits borrowed for that network
     *
     * @return number of subnets allowed in the <i>subnetMask</i>
     */
    long numberOfSubnets() {
        int subnetBits;
        long noOfSubnets;
        char classType = this.ipAddressClass(ipAddress);

        switch (classType) {
            case 'C':
                subnetBits = this.networkBits() - CLASS_C_NETWORK_BITS;
                noOfSubnets = (long) Math.pow(2, subnetBits);
                // From CISCO algorithm
                // noOfSubnets = (long) Math.pow(2, (CLASS_C_NETWORK_BITS-3));
                break;
            case 'B':
                subnetBits = this.networkBits() - CLASS_B_NETWORK_BITS;
                noOfSubnets = (long) Math.pow(2, subnetBits) - 2;
                if (noOfSubnets <= 0) {
                    noOfSubnets = 1;
                }
                break;
            case 'A':
                subnetBits = this.networkBits() - CLASS_A_NETWORK_BITS;
                noOfSubnets = (long) Math.pow(2, subnetBits) - 2;
                if (noOfSubnets <= 0) {
                    noOfSubnets = 1;
                }
                // From CISCO algorithm
                // noOfSubnets = (long) Math.pow(2, (CLASS_A_NETWORK_BITS-1)) - 2;
                break;
            default:
                noOfSubnets = 1;
                break;
        }
        //TODO - check why getting -ve number of subnets
        if (noOfSubnets < 0) {
            noOfSubnets = -1 * noOfSubnets;
        }
        return noOfSubnets;
    }

    /**
     * @param networkAddress
     *
     * @return
     */
    String startIP(String networkAddress) {
        int lastDotIndex = networkAddress.lastIndexOf('.');
        int lastOctetVal = Integer.parseInt(networkAddress.substring(lastDotIndex + 1)) + 1;
        return networkAddress.substring(0, lastDotIndex) + "." + lastOctetVal;
    }

    /**
     * Calculates the possible end IPADDRESS address in the network by iterating
     * through the <i>startIP</i> and modifying it number of times equal to
     * <i>norOfIps</i>
     *
     * @param startIP  -
     *                 Start IPADDRESS Address in the network/sub-network
     * @param norOfIps -
     *                 Total number of hosts in that network
     *
     * @return - End IPADDRESS address
     */
    String endIP(String startIP, long norOfIps) {
        String finalIP;
        int startIpArray[] = IPAddressUtil.ipAddressArray(startIP);

        for (int i = 1; i < norOfIps - 1; i++) {
            startIpArray[3] += 1;
            if (startIpArray[3] > 255) {
                startIpArray[3] = 0;
                startIpArray[2] += 1;
                if (startIpArray[2] > 255) {
                    startIpArray[2] = 0;
                    startIpArray[1] += 1;
                    if (startIpArray[1] > 255) {
                        startIpArray[1] = 0;
                        startIpArray[0] += 1;
                    }
                }
            }
        }
        // The final last octect value should not be greater than 254
        // 255 is assigned for broad cast address in each subnet
        for (int i = 1; i <= 1; i++) {
            startIpArray[3] += 1;
            if (startIpArray[3] > 254) {
                startIpArray[3] = 0;
                startIpArray[2] += 1;
                if (startIpArray[2] > 255) {
                    startIpArray[2] = 0;
                    startIpArray[1] += 1;
                    if (startIpArray[1] > 255) {
                        startIpArray[1] = 0;
                        startIpArray[0] += 1;
                    }
                }
            }
        }
        finalIP = startIpArray[0] + "." + startIpArray[1] + "."
                  + startIpArray[2] + "." + startIpArray[3];
        return finalIP;
    }

    /** @return - number of network bits in the <i>subnetMask</i> */
    int networkBits() {
        subnetMask = this.correctMask();
        int[] ipArr = IPAddressUtil.subnetMaskArray(subnetMask);
        int networkBits = 0;
        for (int anIpArr : ipArr) {
            networkBits += octalValue("" + Integer.toBinaryString(anIpArr));
        }
        return networkBits;
    }

    /**
     * Calculates the sum of the each bit in the given binary string
     *
     * @param binaryStr - a string of 0's and 1's
     *
     * @return an integer representing the sum of 0's and 1's in each the given binary string
     */
    private int octalValue(String binaryStr) {
        int octalVal = 0;
        for (int i = 0; i < binaryStr.length(); i++) {
            octalVal += Integer.parseInt("" + binaryStr.charAt(i));
        }
        return octalVal;
    }

    /** @return an integer indicating the number of bits allowed for hosts. */
    private int hostBits() {
        return 32 - networkBits();
    }

    /**
     * @param address -
     *                Address from which the octet value to be returned
     * @param index   -
     *                integer representing which octet value to be returned.
     *
     * @return returns the integer value of the octect represented by index
     */
    int prefferedOctect(String address, int index) {
        int addressArray[] = IPAddressUtil.ipAddressArray(address);
        int octetValue = 0;

        switch (index) {
            case 1:
                octetValue = addressArray[0];
                break;
            case 2:
                octetValue = addressArray[1];
                break;
            case 3:
                octetValue = addressArray[2];
                break;
            case 4:
                octetValue = addressArray[3];
                break;
        }
        return octetValue;
    }
}
