/*Copyright (c) Wyse Technology, Inc.
 Current Revision: $Rev: 4809 $
 Last Modified: $Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.discovery;

import java.net.InetAddress;

import org.apache.log4j.Logger;

import com.wyse.rapport.services.IHibernateSessionService;

/** @author GeorgeC The runnable discovery threads */
public class DiscoveryThread implements Runnable {
    private static Logger log = Logger.getLogger(DiscoveryThread.class);
    private InetAddress address;
    private IDeviceDiscoveryService legacyDeviceCommandService;
    private IDeviceDiscoveryService deviceCommandService;
    private IHibernateSessionService hibernateSessionPerThreadService;

    public DiscoveryThread(InetAddress address, IDeviceDiscoveryService legacyDeviceCommandService,
                           IDeviceDiscoveryService deviceCommandService, IHibernateSessionService hibernateSessionPerThreadService) {
        this.address = address;
        this.legacyDeviceCommandService = legacyDeviceCommandService;
        this.deviceCommandService = deviceCommandService;
        this.hibernateSessionPerThreadService = hibernateSessionPerThreadService;
    }

    public void run() {
        discoverDevices();
    }

    void discoverDevices() {
        try {
            discoverDevice();
        } catch (Exception e) {
            log.error("Error while discovering WDM Agent with IPADDRESS address: " + address + ", Cause: " + e);
            discoverLegacyDevice();
        } finally {
            hibernateSessionPerThreadService.closeSession();
        }
    }

    private void discoverLegacyDevice() {
        try {
            log.info("Attempting to discover legacy device with IPADDRESS address: " + address);
            legacyDeviceCommandService.discover(address);
            log.info("Successfully contacted legacy device with IPADDRESS address: " + address);
        } catch (Exception e) {
            log.error("Error while discovering legacy device with IPADDRESS address: " + address + ", Cause: " + e);
        }
    }

    private void discoverDevice() {
        log.info("Attempting to discover device with IPADDRESS address: " + address);
        deviceCommandService.discover(address);
        log.info("Successfully discovered device with IPADDRESS address: " + address);
    }
}