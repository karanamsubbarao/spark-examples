/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 4278 $
Last Modified: $Date: 2006-06-09 17:45:42 +0530 (Fri, 09 Jun 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.discovery;

import java.net.InetAddress;

import com.wyse.rapport.command.ELegacyCommand;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.command.IDeviceCommunicationService;

/** Understands discovering legacy devices. */
public class LegacyDeviceDiscoveryService implements IDeviceDiscoveryService {
    private IDeviceCommunicationService legacyDeviceCommunicator;
    
    public LegacyDeviceDiscoveryService(IDeviceCommunicationService legacyDeviceCommunicator) {
        this(legacyDeviceCommunicator, RapportServer.getServerAddress(), RapportServer.getServerPort());
    }

    public LegacyDeviceDiscoveryService(IDeviceCommunicationService legacyDeviceCommunicator, String server, int port) {
        this.legacyDeviceCommunicator = legacyDeviceCommunicator;
    }

    public void discover(InetAddress deviceAddress) {
        String command = ELegacyCommand.FULL_CHECKIN.command(null);
        legacyDeviceCommunicator.sendCommand(deviceAddress, command);
    }
}
