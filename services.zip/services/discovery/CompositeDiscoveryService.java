/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 4809 $
 Last Modified: $Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.discovery;

import java.net.InetAddress;

import com.wyse.rapport.server.DefaultRapportService;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.IThreadPoolService;

/** Initiates discovery for both new and legacy devices. */
public class CompositeDiscoveryService extends DefaultRapportService implements IDeviceDiscoveryService {
    private IThreadPoolService threadPoolService;
    private IDeviceDiscoveryService legacyDeviceDiscoveryService;
    private IDeviceDiscoveryService deviceDiscoveryService;
    private IHibernateSessionService sessionService;

    public CompositeDiscoveryService(IDeviceDiscoveryService legacyDeviceDiscoveryService, IDeviceDiscoveryService deviceDiscoveryService,
                                     IThreadPoolService threadPool, IHibernateSessionService sessionService) {
        this.legacyDeviceDiscoveryService = legacyDeviceDiscoveryService;
        this.deviceDiscoveryService = deviceDiscoveryService;
        this.sessionService = sessionService;
        this.threadPoolService = threadPool;
    }

    public EServiceStatus stop() {
        serviceStatus = EServiceStatus.STOPPED;
        threadPoolService.shutdown();
        return EServiceStatus.SUCCESS;
    }

    public void discover(InetAddress address) {
        threadPoolService.submitJob(createThread(address));
    }

    private Runnable createThread(InetAddress address) {
        return new DiscoveryThread(address, legacyDeviceDiscoveryService, deviceDiscoveryService, sessionService);
    }
}