/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev$
Last Modified: $Date$
Last Modified By: $Author$
*/

package com.wyse.rapport.services;

import java.io.Serializable;
import java.util.Collection;

import org.hibernate.Criteria;
import org.hibernate.Query;

/** Interface that all CRUD services will use for database operations. */
public interface IHibernateSessionService {
    void closeSession();

    void create(Object object);
    
    void closeSessionWithoutFlush();

    void createOrUpdate(Object object);

    void delete(Object object);

    void deleteCollection(Collection collection);
    
    void deleteAll(Class cls);

    void deleteWithQuery(String query);

    Query createQuery(String query);

    Object find(Class aClass, Serializable id);

    Long getCount(Class aClass, String[] attributes, Object[] values);
    
    void evict(Object obj);

    void flush();
    
    Criteria getCriteria(Class classObj);
    
    void clear();
    
    boolean contains(Object object);
}
