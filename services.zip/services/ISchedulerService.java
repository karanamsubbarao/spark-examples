package com.wyse.rapport.services;

import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.Task;

/**
 * Interface for SchedulerService 
 */
public interface ISchedulerService {
	
    void schedule(Device device, Task task);

	void unschedule(Task task);
    
}
