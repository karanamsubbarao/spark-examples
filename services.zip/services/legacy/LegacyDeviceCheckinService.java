/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 6581 $
 Last Modified: $Date: 2006-12-06 15:10:19 +0530 (Wed, 06 Dec 2006) $
 Last Modified By: $Author: myadav $
 */

package com.wyse.rapport.services.legacy;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wyse.rapport.command.ETaskStatus;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceGroup;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.persistence.DeviceRepository;
import com.wyse.rapport.services.persistence.DiscoveryProgressRepository;
import com.wyse.rapport.services.persistence.DiscoveryRangesRepository;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IDiscoveryProgressRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.services.persistence.SystemLogService;
import com.wyse.rapport.services.persistence.UserPreferencesRepository;
import com.wyse.rapport.util.WDMConstants;

/**
 * LegacyCheckin class add/update the new checked in devices to the database
 * based on the checkin query string passed.
 */
public class LegacyDeviceCheckinService {
    static final int CLEAR_CACHE = 1;
    static final int DISABLE_WRITE_FILTER = 2;
    static final int ENABLE_WRITE_FILTER = 3;
    static final String WDM_EXISTS = "Device with WDMAgent already exists";
    public static final String INCOMPLETE_INFO = "Error: Incomplete asset or heartbeat from a non-existing device";
    private IDeviceRepository deviceRepository;
    ISystemLogService systemLogService;
    private IDiscoveryProgressRepository discoveryProgressRepository;
    private LegacyDeviceResponseService legacyDeviceResponse;
    private IUserPreferencesRepository userPreferencesRepository;
    private static Logger log = Logger.getLogger(LegacyDeviceCheckinService.class);
    long checkinInterval = 0;

    public LegacyDeviceCheckinService(IHibernateSessionService sessionService) {
        setDeviceRepository(new DeviceRepository(sessionService));
        setUserPreferenceRepository(new UserPreferencesRepository(sessionService));
        setDiscoveryProgressRepository(new DiscoveryProgressRepository(sessionService, new DiscoveryRangesRepository(sessionService)));
        systemLogService = new SystemLogService(sessionService);
        this.legacyDeviceResponse = new LegacyDeviceResponseService();
    }

    void setUserPreferenceRepository(IUserPreferencesRepository userPreferencesRepository) {
        this.userPreferencesRepository = userPreferencesRepository;
    }

    void setDiscoveryProgressRepository(IDiscoveryProgressRepository discoveryProgressRepository) {
        this.discoveryProgressRepository = discoveryProgressRepository;
    }

    void setDeviceRepository(IDeviceRepository deviceRepository) {
        this.deviceRepository = deviceRepository;
    }

    public String checkin(LegacyQueryParser parser) {
        setCheckinInterval();
        DeviceInfo device = findLegacyDeviceByMac(parser.macAddress());
        if(device != null){
        	systemLogService.info("Device status updated", device);
        	return updateLegacyDevice(parser, device);
        }
        if(deviceRepository.isLicenseLimitExceeded()){
        	log.info("License Limit of Max number of devices " + RapportServer.licenseLimit() + " exceeded" );
        	return "license Limit Exceeded";
        }
        return createDevice(parser);
    }

    public String heartbeat(LegacyQueryParser parser) {
        DeviceInfo device = findLegacyDeviceByMac(parser.macAddress());
        if(device != null){
        	setCheckinInterval();
        	return updateDevice(parser, device);
        }
        return INCOMPLETE_INFO;
    }

    public String scriptCompletion(LegacyQueryParser parser) {
        String macId = parser.macAddress();
        if (macId != null) {
            DeviceInfo device = deviceRepository.findByMac(macId);
            if (device != null) {
        		device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
            	if(device.isLegacyDeviceUpgradePending()){
            		String result = handleWdmInstallation(parser, device);
            		deviceRepository.update(device);
            		return result;
            	}
            }
        }
        return "Invalid script completion request";
    }

    private String handleWdmInstallation(LegacyQueryParser parser, DeviceInfo device) {
        log.info("Write Filter Status : handleWdmInstallation()..." + device.getWriteFilterStatus());
        resetWriteFilterStatus(device);
        if (needEnableWriteFilter(device)) {
            return enableWriteFilterStatus(device);
        }
        if (parser.getString("ER") != null) {
            device.upgradeAgentFailed();
            systemLogService.error("Failed to install WDM Agent on Device", device);
            return "&UP0|&SI=1|UR=1|EL|01|";
        }
        device.upgradeAgentSucceeded();
        systemLogService.info("Successfully installed WDM Agent on Device ", device);
        return "&00";
    }

    private DeviceInfo findLegacyDeviceByMac(String macId) {
        return deviceRepository.findLegacyDeviceByMac(macId);
    }

    private void setCheckinDetails(DeviceInfo device, long checkinInterval) {
        device.setNextAssetReportTime(new Date(), checkinInterval);
        device.setCheckIn(new Date());
    }

    private String updateLegacyDevice(LegacyQueryParser parser, DeviceInfo device) {
        DeviceInfo newDevice = parser.update(device);
        persistDevice(newDevice);
        return constructResponse(newDevice);
    }

    private String updateDevice(LegacyQueryParser parser, DeviceInfo device) {
        persistDevice(parser.update(device));
        return constructResponse(device);
    }

    private String createDevice(LegacyQueryParser parser) {
        DeviceInfo device = deviceRepository.findByMac(parser.macAddress());
        if (device != null) {
            log.info("Write Filter Status : createDevice()..." + device.getWriteFilterStatus());
            resetWriteFilterStatus(device);
            if (needEnableWriteFilter(device)) {
                return enableWriteFilterStatus(device);
            }
            return WDM_EXISTS;
        }
        return createLegacyDevice(parser.device());
    }

    private void resetWriteFilterStatus(DeviceInfo newDevice) {
        if (newDevice.getWriteFilterStatus() ==WDMConstants.WRITE_FILTER_SENT) {
            newDevice.upgradeAgentSucceeded();
        }
    }

    private boolean needEnableWriteFilter(DeviceInfo newDevice) {
        return newDevice.getWriteFilterStatus() == WDMConstants.WRITE_FILTER_SEND;
    }

    private String enableWriteFilterStatus(DeviceInfo device) {
        log.info("Enabling the Write Filter after Upgrading Legacy Agent..." + device.getActiveIp());
        device.setWriteFilterStatus(WDMConstants.WRITE_FILTER_SENT);
        device.setLegacyDeviceUpgradePending(false);
        device.taskSucceeded(device.getCurrentTask());
        return "&UP0|&SI=1|UR=1|&WF=" + ENABLE_WRITE_FILTER + "|01|";
    }

    private String createLegacyDevice(DeviceInfo device) {
        if (device != null && hasFullAsetInfo(device)) {
            createDevice(device);
            device.setDeviceGroupPath(DeviceGroup.UNASSIGNED_PATH);
            return constructResponse(device);
        }
        return INCOMPLETE_INFO;
    }

    private boolean hasFullAsetInfo(DeviceInfo legacyDevice) {
        String hostName = legacyDevice.getPlatformName();
        return hostName != null && StringUtils.isNotBlank(hostName);
    }

    void createDevice(DeviceInfo device) {
        device.nextLegacyId(deviceRepository.getLastLegacyId());
        persistDevice(device);
    }

    private String constructResponse(DeviceInfo device) {
        return device.isLegacyDeviceUpgradePending() ? upgradeAgentScript(device) : legacyDeviceResponse.constructResponse(device, checkinInterval);
    }

    private void setCheckinInterval() {
        checkinInterval = new UserPreferences(userPreferencesRepository).getCheckinIntervalInSeconds();
    }

    private String upgradeAgentScript(DeviceInfo device) {
        log.info("Sending upgrade Agent script to device ");
        device.getCurrentTask().setStatus(ETaskStatus.IN_PROGRESS);
        device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
        if (device.isWriteFilterOn()) {
            if (device.isClearWFCacheCommandSent()) {
                device.setClearWFCacheCommandSent(false);
                log.info("Disabling the Write Filter before Upgrading Legacy Agent..." + device.getActiveIp());
                return legacyDeviceResponse.upgradeScript(true, device);
            }
            device.setClearWFCacheCommandSent(true);
            
            deviceRepository.update(device);
            return "&UP0|&SI=1|UR=1|&WF=" + CLEAR_CACHE + "|01|";
        }
        return legacyDeviceResponse.upgradeScript(false, device);
    }

    void persistDevice(DeviceInfo device) {
        setCheckinDetails(device, checkinInterval);
        device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
        device.setManualDevice(false);
        deviceRepository.createOrUpdate(device);
        discoveryProgressRepository.discovered(device.getActiveIp());
    }

    public void setSystemLogService(ISystemLogService systemLogService) {
        this.systemLogService = systemLogService;
    }

}