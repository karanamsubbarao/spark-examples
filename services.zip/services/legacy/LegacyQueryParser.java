/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 6343 $
 Last Modified: $Date: 2006-11-23 09:55:58 +0530 (Thu, 23 Nov 2006) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.legacy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;

import com.wyse.rapport.db.tbl.CustomValue;
import com.wyse.rapport.db.tbl.DeviceApplication;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.db.tbl.StorageDevice;
import com.wyse.rapport.deviceinterface.LegacyParameter;
import com.wyse.rapport.util.LegacyCharacterConversions;
import com.wyse.rapport.util.ModelTypes;
import com.wyse.rapport.util.NetworkUtil;
import com.wyse.rapport.util.OSTypes;

/**
 * Takes a query string in the constructor and extract the device properties and
 * values from it and constructs a device object. Designed to work with older
 * 4.x HAgents.
 */
public class LegacyQueryParser {
    private Map<String, List<String>> parametersHashMap = new HashMap<String, List<String>>();
    private String socketAddress;
    private String checkinString;
    private boolean isBlazer;
    private static final Long blazerOsCode = (long) 9;

    public LegacyQueryParser(String queryString, String socketAddress) {
        assert socketAddress != null : "Socket Address can not be null";
        this.socketAddress = socketAddress;
        this.checkinString = queryString;
        if (checkinString == null) {
            throw new RuntimeException("Null Checkin");
        }
        parseCheckInStringToHashMap(checkinString);
    }

    public void setBlazer(boolean isBlazer) {
        this.isBlazer = isBlazer;
    }

    public DeviceInfo device() {
        return isValidRequest() ? createDevice() : null;
    }

    public DeviceInfo update(DeviceInfo device) {
        return isValidRequest() ? updateDevice(device) : device;
    }

    public int getVerb() {
        String verb = checkinString.substring(2, 4);
        if (StringUtils.isNumeric(verb)) {
            return Integer.parseInt(verb);
        }
        return -1;
    }

    private DeviceInfo updateDevice(DeviceInfo device) {
        return hasHostName() ? merge(device) : updateIP(device);
    }

    private DeviceInfo updateIP(DeviceInfo device) {
        device.getActiveNetwork().setIpAddress(socketAddress);
        device.setLegacyId(getLong("CID"));
        return device;
    }

    private DeviceInfo merge(DeviceInfo device) {
        DeviceInfo newDevice = createDevice();
        newDevice.setDeviceGuid(device.getDeviceGuid());
        device.mergeWith(newDevice);
        return device;
    }

    private boolean hasHostName() {
        return getString("CN") != null;
    }

    String macAddress() {
        String mac = getString("IMAC");
        return (mac == null) ? getString("MAC") : mac;
    }

    public String getSocketAddress() {
        return socketAddress;
    }

    private void parseCheckInStringToHashMap(String asset) {
        asset = LegacyCharacterConversions.convertCheckinStringFromDevice(asset);
        List<String> allParameters = pipeSplit(asset, "|");
        for (Iterator<String> i = allParameters.listIterator(); i.hasNext();) {
            String param = i.next();
            if (StringUtils.isBlank(param)) {
                // if the parameter is blank then just skip it
                continue;
            }
            LegacyParameter lp = new LegacyParameter(param);
            int numberValues = getNumberExtraValues(lp.getKey());
            // Grab the specified number of extra values and add them to
            // the current LegacyParameter
            while (numberValues > 0) {
                if (i.hasNext()) {
                    lp.addValue(i.next());
                }
                numberValues--;
            }
            parametersHashMap.put(lp.getKey(), lp.getValues());
        }
    }

    /**
     * Check the key and determine if it has extra value parameters that will
     * come in extra key positions. The number returned is the number of extra
     * positions to use, so if the key only uses the current paramter
     * (key=value), then return 0.
     *
     * @param key -
     *            Key that is being parsed (e.g. "AP2")
     *
     * @return Number of extra positions to consume, default is 0 for
     *         unrecognized keys
     */
    private int getNumberExtraValues(String key) {
        assert StringUtils.isNotBlank(key) : "blank key passed to getNumberExtraValues";

        if (key == null) {
            return 0;
        }
        int keyLength = key.length();

        // AP - Application, has 2 extra parameters
        if (keyLength > 1
            && StringUtils.equalsIgnoreCase("AP", StringUtils.substring(
                key, 0, 2))) {
            return 2;
        }

        // IN - Information, has 1 extra parameter
        if (keyLength > 1
            && StringUtils.equalsIgnoreCase("IN", StringUtils.substring(
                key, 0, 2))) {
            return 1;
        }

        // ER - Error, has 1 extra parameter
        if (keyLength > 1
            && StringUtils.equalsIgnoreCase("ER", StringUtils.substring(
                key, 0, 2))) {
            return 1;
        }
        return 0;
    }

    private DeviceInfo createDevice(DeviceInfo device) {
        device.setLegacy(true);
        device.setLegacyId(getLong("CID"));
        device.setHostName(getString("CN"));
        device.setImageName(getString("IM"));
        int platformAgentId = getInt("P1");
        int vendorId = getInt("VI");
        Long osTypeId = null;
        if (isBlazer) {
            osTypeId = blazerOsCode;
            vendorId = 1;
        } else {
            osTypeId = getLong("OS");
        }
        String osName = OSTypes.legacyOsName(osTypeId);
		device.setOsName(osName);
        device.setOsVersion(getString("OSV"));
        device.setAgentLocation(getString("AL"));
        device.setRapportAgent(getString("AV"));
        
        device.setModel(ModelTypes.getModel(platformAgentId,vendorId, osName));
		device.setPlatformName(getString("P1"));
        device.setInstalledRAM(getLong("RM") == null ? 0L : getLong("RM"));
        device.setSoundCard(getString("PD1"));
        device.setVideoCard(getString("PD2"));
        device.setBiosVersion(getString("B1"));
        device.setCpuType(getString("CP"));
        device.setCpuSpeed(getInt("CPS"));
        device.setBatteryRemainingPercentage(getInt("BR"));
        device.setSerialNumber(getString("SN#"));
        device.setLocale(getString("LS1"));
        setCustomValues(device);
        return device;
    }

    private void setCustomValues(DeviceInfo device) {
        addCustomValue("location", getString("LO"), device);
        addCustomValue("contact", getString("CO"), device);
        addCustomValue("custom1", getString("C1"), device);
        addCustomValue("custom2", getString("C2"), device);
        addCustomValue("custom3", getString("C3"), device);
    }

    private void addCustomValue(String key, String value, DeviceInfo device) {
        if (value != null) device.addCustomValue(new CustomValue(key, value));
    }

    private DeviceInfo addNetworks(DeviceInfo device) {
        device.getDeviceNetworks().clear();
        if (isValidRequest()) {
            DeviceNetworkInfo deviceNetwork = new DeviceNetworkInfo();
            deviceNetwork.setMacAddress(macAddress());
            setIpAddress(deviceNetwork);
            setSubnetMask(deviceNetwork);
            deviceNetwork.setGateway(getString("GW"));
            deviceNetwork.setDomainName(getString("DM"));
            deviceNetwork.setDhcpEnabled(getBoolean("ED"));
            deviceNetwork.setDhcpServerIp(getString("DS"));
            deviceNetwork.setDnsAuto(getBoolean("0D"));
            deviceNetwork.setWinsAuto(getBoolean("0W"));
            deviceNetwork.setDnsServer1(getString("1D"));
            deviceNetwork.setDnsServer2(getString("2D"));
            deviceNetwork.setWinsServer1(getString("1W"));
            deviceNetwork.setWinsServer2(getString("2W"));
            deviceNetwork.setSpeed(getString("NS"));
            device.addDeviceNetwork(deviceNetwork);
            device.setActiveNetwork(socketAddress);
        }
        return device;
    }

	private void setSubnetMask(DeviceNetworkInfo deviceNetwork) {
		String subnetMask = getString("SM");
		if(NetworkUtil.validateSubnet(subnetMask)){
			deviceNetwork.setSubnetMask(subnetMask);
		}
	}

	private void setIpAddress(DeviceNetworkInfo deviceNetwork) {
		deviceNetwork.setIpAddress(socketAddress);
	}

    private boolean isValidRequest() {
        return macAddress() != null;
    }

    private DeviceInfo addStorage(DeviceInfo device) {
        device.getStorageDevices().clear();
        if (getInt("FS") != 0) {
            StorageDevice type = new StorageDevice();
            type.setRawCapacity(getInt("FS"));
            type.setWriteFilterExists(getBoolean("WFE"));
            type.setWriteFilterOn(getBoolean("WF"));
            //Assuming the Legacy Devices FS stands for Flash Size
            type.setType(StorageDevice.FLASH);
            device.addStorageDevice(type);
        }
        return device;
    }

    private DeviceInfo addApplications(DeviceInfo device) {
        Iterator itr = parametersHashMap.keySet().iterator();
        List<String> values = null;
        device.getDeviceApplications().clear();
        while (itr.hasNext()) {
            String key = itr.next().toString();
            if (StringUtils.equalsIgnoreCase("AP", StringUtils.substring(key,
                                                                         0, 2))) {
                values = parametersHashMap.get(key);
                if (values != null && values.size() > 2) {
                    if (StringUtils.equalsIgnoreCase(values.get(1), "NA")) {
                        values.add(1, "");
                    }
                    if (StringUtils.equalsIgnoreCase(values.get(2), "NA")) {
                        values.add(2, "");
                    }
                    DeviceApplication app = new DeviceApplication(values.get(0), values.get(1),
                                                                  values.get(2), "");
                    if (app.isHAgentApp() && device.getRapportAgent() == null) {
                        device.setRapportAgent(app.getVersion());
                    }
                    device.addDeviceApp(app);
                }
            }
        }
        return device;
    }

    List<String> pipeSplit(String source, String pattern) {
        while (source.indexOf("||") >= 0) {
            source = StringUtils.replace(source, "||", "| |");
        }
        StringTokenizer st = new StringTokenizer(source, "|");
        List<String> ls = new ArrayList<String>(st.countTokens());
        while (st.hasMoreTokens()) {
            ls.add(st.nextToken());
        }
        return ls;
    }

    private Object getValue(String key) {
        List<String> values = null;
        if (key != null && (values = parametersHashMap.get(key)) != null
            && values.size() > 0) {
            return values.get(0);
        }
        return null;
    }

    List<String> getValues(String key) {
        return parametersHashMap.get(key);
    }

    String getString(String key) {
        Object value = getValue(key);
        return (value == null) ? null : value.toString();
    }

    private boolean getBoolean(String key) {
        return (getString(key) == null)
               ? false
               : getString(key).equals("1") ? true : false;
    }

    private Integer getInt(String key) {
        String value = getString(key);
        if (value != null && StringUtils.isNotBlank(value)
            && StringUtils.isNumeric(value)) {
            return Integer.parseInt(value);
        }
        return 0;
    }

    private Long getLong(String key) {
        String value = getString(key);
        if (value != null && StringUtils.isNotBlank(value)
            && StringUtils.isNumeric(value)) {
            return new Long(value);
        }
        return null;
    }

    private DeviceInfo createDevice() {
        DeviceInfo newDevice = new DeviceInfo();
        newDevice = createDevice(newDevice);
        addNetworks(newDevice);
        addStorage(newDevice);
        addApplications(newDevice);
        return newDevice;
    }

	public String getOsType() {
		Long osTypeId = null;
        if (isBlazer) {
            osTypeId = blazerOsCode;
        } else {
            osTypeId = getLong("OS");
        }
        return OSTypes.legacyOsName(osTypeId);
	}
}
