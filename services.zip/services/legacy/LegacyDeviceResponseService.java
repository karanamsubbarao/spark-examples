/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 6581 $
 Last Modified: $Date: 2006-12-06 15:10:19 +0530 (Wed, 06 Dec 2006) $
 Last Modified By: $Author: myadav $
 */

package com.wyse.rapport.services.legacy;

import org.apache.commons.lang.StringUtils;

import com.wyse.rapport.command.ELegacyCommand;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.util.LegacyCharacterConversions;
import com.wyse.rapport.util.WDMConstants;

/** Sends response to legacy devices */
public class LegacyDeviceResponseService {

    String constructResponse(DeviceInfo device, long checkinInterval) {
        StringBuffer response = new StringBuffer();
        response.append("&00");
        response.append("|Rapport NG Check in response");
        response.append("|&IT=" + checkinInterval);
        response.append("|&CID=" + device.getLegacyId());
        response.append("|QUB=3|QUT=120|CU=0|");
        return response.toString();
    }

    String upgradeScript(boolean writeFilterEnabled, DeviceInfo device) {
        StringBuffer sbf = new StringBuffer();
        if (writeFilterEnabled) {
            device.setWriteFilterStatus(WDMConstants.WRITE_FILTER_SEND);
            sbf.append("&WF=" + LegacyDeviceCheckinService.DISABLE_WRITE_FILTER + "|");
        }
        sbf.append(upgradeAgentScript(device));
        sbf.append(ELegacyCommand.ftpServerDetails());
        sbf.append("&IT=3600|&CID=" + device.getLegacyId());
        sbf.append("|QUB=3|QUT=120|CU=1|");

        return (device.getOsName().indexOf("Linux") >= 0)
               ? LegacyCharacterConversions.linuxConversions(sbf.toString())
               : LegacyCharacterConversions.windowsConversions(sbf.toString());
    }

    private String upgradeAgentScript(DeviceInfo device) {
        String osName = device.getOsName().toUpperCase();

        if (osName.indexOf("XP") >= 0) {
            String command = isPatchRequired(device.getRapportAgent()) ?
                             ELegacyCommand.XP_UPGRADE_AGENT_WITH_PATCH.command(device)
                             : ELegacyCommand.XP_UPGRADE_AGENT_WITHOUT_PATCH.command(device);
            return command;
        } else if (osName.indexOf("LINUX") >= 0) {
            return ELegacyCommand.LINUX_UPGRADE_AGENT.command(device);
        }
        return null;
    }

    boolean isPatchRequired(String rapportAgentVersion) {
        if (StringUtils.isBlank(rapportAgentVersion)) return true;
        String[] hAgentFields = StringUtils.split(rapportAgentVersion, ".");
        int majorVersion = Integer.parseInt(hAgentFields[0]);
        int minorVersion = Integer.parseInt(hAgentFields[1]);
        int buildNumber = Integer.parseInt(hAgentFields[2]);
        int patchNumber = Integer.parseInt(hAgentFields[3]);
        if (majorVersion >= 4) {
            if (minorVersion == 0 && buildNumber >= 5 && patchNumber >= 2) {
                return true;
            } else if (minorVersion == 1 && buildNumber >= 0 && patchNumber >= 0) {
                return true;
            }
        }
        return false;
    }
}
