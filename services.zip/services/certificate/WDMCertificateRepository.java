package com.wyse.rapport.services.certificate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;

import com.wyse.rapport.db.tbl.WDMCertificate;
import com.wyse.rapport.services.IHibernateSessionService;

public class WDMCertificateRepository implements IWDMCertificateRepository {

	private IHibernateSessionService sessionService;
    
    public WDMCertificateRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
    }
    
	public void create(WDMCertificate license) {
		deleteAllCertificates();
		sessionService.create(license);
	}

	public void delete(WDMCertificate license) {
		sessionService.delete(license);
	}

	public void update(WDMCertificate license) {
		sessionService.createOrUpdate(license);
	}

	public byte[] certificateContents(String name) {
		WDMCertificate certificate = getCertificate(name);
		return certificate == null ? null :certificate.getContents();
	}
    
	public WDMCertificate getCertificate(String name) {
        List list =getAllCertificates();
        if( list !=null && list.size()>0){
            return (WDMCertificate)list.get(0);           
        }else{
            return null;
        }
	}
	
    private List getAllCertificates(){
        Criteria criteria = sessionService.getCriteria(WDMCertificate.class);
        return criteria.list();
    }

    private void deleteAllCertificates(){
        List list = getAllCertificates();
        if(list != null){
            for(Object obj:list){
                sessionService.delete(obj);
            }
        }
        list =null;
    }

	
}
