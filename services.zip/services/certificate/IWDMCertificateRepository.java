package com.wyse.rapport.services.certificate;

import com.wyse.rapport.db.tbl.WDMCertificate;

public interface IWDMCertificateRepository {

	 public void create(WDMCertificate certificate);
	 
	 public void update(WDMCertificate certificate);
	 
	 public void delete(WDMCertificate certificate);
	 
	 public byte[] certificateContents(String productName);
	 
	 public WDMCertificate getCertificate(String name);
}
