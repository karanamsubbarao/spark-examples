/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev: 6312 $$
Last Modified: $$Date: 2006-11-21 15:53:49 +0530 (Tue, 21 Nov 2006) $$
Last Modified By: $$Author: myadav $$
*/

package com.wyse.rapport.services.device;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.wyse.rapport.businesslogic.WDMFile;
import com.wyse.rapport.configuration.DeviceConfigurationTaskBuilder;
import com.wyse.rapport.db.tbl.Schedule;

/** operations on devices */
public interface IDeviceService {
    
    void delete(Collection<String> deviceGuids);
    
    void refreshDeviceStatus(Collection<String> guids);

    void shutdown(Collection<String> deviceGuids);

    void reboot(Collection<String> deviceGuid);

    void deleteDirectory(Collection<String> deviceGuids, String directoryLocation);

    void deleteFile(Collection<String> deviceGuids, String fileLocation);

    void execute(Collection<String> deviceGuids, String executeLocation, String deviceCommand, boolean stdOutEnabled, boolean stdErrEnabled, boolean writeFilterEnabled);

    void downloadFileFromServer(Collection<String> guids, String deviceLocation, String repositoryUrl);

    void uploadFileToServer(Collection<String> deviceGuids, String source, String serverUrl);

    void mergeRegistry(Collection<String> deviceGuids, String serverLocation);

    void setConfiguration(String deviceGuid, Map<String, String> configurationMap, Schedule schedule, boolean allowNextTask);

    void setConfiguration(String deviceGuid, DeviceConfigurationTaskBuilder builder, Schedule schedulerType, int taskRetryCount, boolean allowNextTask);
    
    void customTask(String string, String commandListXml, Schedule schedulerType, int i, boolean allowNextTask);
    
    void uploadImageToServer(String deviceGuid, String imageName, Schedule schedule, boolean allowNextTask);

    void downloadImageFromServer(String deviceGuid, List<WDMFile> imageFiles, Schedule schedulerType, int taskRetryCount, boolean allowNextTask, String imageVersion);

    void installOnDevice(String deviceGuid, String repositoryUrl, Schedule schedulerType, int taskRetryCount, boolean allowNextTask);

    void uninstallFromDevice(String deviceGuid, String application, Schedule schedule, int taskRetryCount, boolean allowNextTask);
    
	void upgradeAgent(String guid, String agentName, Schedule schedulerType, int i, boolean allowNextTask);
	
}
