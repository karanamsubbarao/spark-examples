/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev: 7307 $$
Last Modified: $$Date: 2007-05-09 12:17:29 +0530 (Wed, 09 May 2007) $$
Last Modified By: $$Author: skaranam $$
*/

package com.wyse.rapport.services.device;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.wyse.rapport.businesslogic.WDMFile;
import com.wyse.rapport.configuration.DeviceConfigurationTaskBuilder;
import com.wyse.rapport.configuration.DeviceSettings;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.IDEMediaType;
import com.wyse.rapport.db.tbl.Schedule;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.util.OSTypes;
import com.wyse.rapport.util.WDMUtil;

/** The default implementation of the device service */
public class DefaultDeviceService implements IDeviceService {
	//
	//constants
	//
	private static final Logger log = Logger.getLogger(DefaultDeviceService.class);
	
	//
	//members
	//
	private IDeviceRepository deviceRepository;
	private IUserPreferencesRepository userPreferenceRepository;
	
    public DefaultDeviceService(IDeviceRepository repository) {
        this.deviceRepository = repository;
	}

    public void delete(Collection<String> deviceGuids) {
        for (String deviceGuid : deviceGuids) {
            DeviceInfo device = findDevice(deviceGuid);
			if (device != null && !device.hasTaskInProgress()) {
			    log.info("Deleted device - name: " + device.getHostName() + ", ip:" + device.getActiveIp() + ", mac: " + device.getActiveMac());
			    deviceRepository.delete(device);
			}
        }
    }

	public void setUserPreferenceRepository(IUserPreferencesRepository userPreferenceRepository) {
		this.userPreferenceRepository = userPreferenceRepository;
	}

	private int taskRetryCount() {
		return userPreferenceRepository.getTaskRetryCount();
	}

	private DeviceInfo findDevice(String deviceGuid) {
        return deviceRepository.findByGuid(deviceGuid);
    }

	private String repositoryUrlAsString(String repositoryUrl) {
		return WDMUtil.getRepositoryUrl(repositoryUrl).toString();
	}

    public void refreshDeviceStatus(Collection<String> guids) {
    	int taskRetryCount = taskRetryCount();
        for (String deviceGuid : guids) {
			findDevice(deviceGuid).refreshDeviceStatus(taskRetryCount);
        }
	}
    
    public void shutdown(Collection<String> deviceGuids) {
    	int taskRetryCount = taskRetryCount();
        for (String deviceGuid : deviceGuids) {
			findDevice(deviceGuid).shutdown(taskRetryCount);
        }
    }

    public void reboot(Collection<String> deviceGuids) {
    	int taskRetryCount = taskRetryCount();
        for (String deviceGuid : deviceGuids) {
            findDevice(deviceGuid).reboot(taskRetryCount);
        }
    }

    public void deleteDirectory(Collection<String> deviceGuids, String directoryLocation) {
    	int taskRetryCount = taskRetryCount();
    	for (String deviceGuid : deviceGuids) {
            DeviceInfo device = findDevice(deviceGuid);
			device.deleteDirectory(directoryLocation, taskRetryCount);
        }
    }

    public void deleteFile(Collection<String> deviceGuids, String fileLocation) {
    	int taskRetryCount = taskRetryCount();
        for (String deviceGuid : deviceGuids) {
            findDevice(deviceGuid).deleteFile(fileLocation, taskRetryCount);
        }
    }

    public void execute(Collection<String> deviceGuids, String executeLocation, String deviceCommand, boolean stdOutEnabled, boolean stdErrEnabled, boolean writeFilterEnabled) {
    	int taskRetryCount = taskRetryCount();
        for (String deviceGuid : deviceGuids) {
            findDevice(deviceGuid).execute(executeLocation, deviceCommand, stdOutEnabled, stdErrEnabled, writeFilterEnabled, taskRetryCount);
        }
    }

    public void downloadFileFromServer(Collection<String> deviceGuids, String deviceLocation, String repositoryFile) {
    	String repositoryUrl = repositoryUrlAsString(repositoryFile);
    	int taskRetryCount = taskRetryCount();
        for (String deviceGuid : deviceGuids) {
            findDevice(deviceGuid).downloadFileFromServer(deviceLocation, repositoryUrl, taskRetryCount);
        }
    }

	public void uploadFileToServer(Collection<String> deviceGuids, String source, String destination) {
		String destinationURL = WDMUtil.getUploadUrl(destination).toString();
		int taskRetryCount = taskRetryCount();
        for (String deviceGuid : deviceGuids) {
            findDevice(deviceGuid).uploadFileToServer(source, destinationURL, taskRetryCount);
        }
    }

    public void mergeRegistry(Collection<String> deviceGuids, String serverLocation) {
    	String repositoryUrl = repositoryUrlAsString(serverLocation);
    	int taskRetryCount = taskRetryCount();
        for (String deviceGuid : deviceGuids) {
            findDevice(deviceGuid).mergeRegistry(repositoryUrl, taskRetryCount);
        }
    }
   
    public void setConfiguration(String deviceGuid, DeviceConfigurationTaskBuilder builder, Schedule schedule, int taskRetryCount, boolean allowNextTask) {
        DeviceInfo device = findDevice(deviceGuid);
        device.setConfiguration(builder.toXml(device), schedule, taskRetryCount, allowNextTask);
	}

    public void setConfiguration(String deviceGuid, Map<String, String> configurationMap, Schedule schedule, boolean allowNextTask) {
        DeviceSettings settings = new DeviceSettings(configurationMap, findDevice(deviceGuid));
        findDevice(deviceGuid).setConfiguration(settings.toXml(), schedule, taskRetryCount(), allowNextTask);
    }
    
	public void customTask(String deviceGuid, String commandListXml, Schedule schedule, int taskRetryCount, boolean allowNextTask) {
		findDevice(deviceGuid).customTask(commandListXml, schedule, taskRetryCount, allowNextTask);
	}

    public void uploadImageToServer(String deviceGuid, String imageName, Schedule schedule, boolean allowNextTask) {
        DeviceInfo device = findDevice(deviceGuid);
        IDEMediaType ide = device.getActiveIDEMediaType();
        if(ide ==null) throw new RuntimeException("IDE information not available");
        log.info("UploadImageToServer : Channel number from device : "+ide.getChannel()+" and drive number : "+ide.getActiveDriveNumber());
		device.uploadImageToServer(imageName, schedule, taskRetryCount(), allowNextTask, ide.getChannel(),ide.getActiveDriveNumber());
    }

    public void downloadImageFromServer(String deviceGuid, List<WDMFile> imageFiles, Schedule schedule, int taskRetryCount, boolean allowNextTask, String imageVersion){
    	DeviceInfo device = findDevice(deviceGuid);
    	if(OSTypes.WTOS.equalsIgnoreCase(device.getOsName())){
    		if(!imageVersion.equalsIgnoreCase(WDMUtil.getParsedWtosImageVersion(device.getImageName()))){
        		device.downloadImageFromServerForWTOS(imageFiles,schedule,taskRetryCount,allowNextTask);
    		}
    	}else{
            IDEMediaType ide = device.getActiveIDEMediaType();
            if(ide ==null) throw new RuntimeException("IDE information not available");
            log.info("DownloadImageFromServer : Channel number from device : "+ide.getChannel()+" and drive number : "+ide.getActiveDriveNumber());
    		device.downloadImageFromServer(imageFiles,schedule,taskRetryCount,allowNextTask,ide.getChannel(), ide.getActiveDriveNumber());
    	}
    }

	public void installOnDevice(String deviceGuid, String repositoryUrl, Schedule schedule, int taskRetryCount, boolean allowNextTask) {
		findDevice(deviceGuid).installOnDevice(repositoryUrl, schedule, taskRetryCount,allowNextTask);
	}
    
    public void uninstallFromDevice(String deviceGuid, String application, Schedule schedule, int taskRetryCount, boolean allowNextTask) {
    	findDevice(deviceGuid).uninstallFromDevice(application, schedule, taskRetryCount, allowNextTask);
	}
    
	public void upgradeAgent(String deviceGuid, String agentName, Schedule schedule, int taskRetryCount, boolean allowNextTask) {
		DeviceInfo device = findDevice(deviceGuid);
		if (device.isLegacy()) {
			device.legacyAgentUpgrade(agentName.substring(agentName.lastIndexOf("/") + 1));
	    } else {
	    	device.upgradeAgent(repositoryUrlAsString(agentName), schedule, taskRetryCount, allowNextTask);
	    }		
	}
	
}
