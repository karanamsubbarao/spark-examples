package com.wyse.rapport.services.deviceinterface;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceGroup;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceUser;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.persistence.IDeviceGroupRepository;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IDeviceUserRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.IUserGroupRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.util.MacAddress;
import com.wyse.rapport.util.WDMUtil;
import com.wyse.rapport.wnom.IWnomConfigurationRepository;
import com.wyse.rapport.wnom.WnomConfiguration;

public class BlazerConfigurationHandler extends ADeviceEventHandler {
    private static List<String> fileServerRequiredAttributes = WDMUtil.asStringList("desktop=\"", "icon=\"");
    public static final String LEOSTREAM_PREFIX = "Result=OK";
    private static final String LEOSTREAM_PREFIX_ERROR = "Result=Error";

    private IDeviceRepository deviceRepository;
    private IDeviceUserRepository deviceUserRepository;
    private IUserGroupRepository userGroupRepository;
    private IDeviceGroupRepository deviceGroupRepository;
    protected ISystemLogService systemLogService; 
    protected IWnomConfigurationRepository wnomConfigurationRepository;
    private IUserPreferencesRepository userPreferencesRepository;

    private static Logger log = Logger.getLogger(BlazerConfigurationHandler.class);
    private static String DEVICE_CONFIGURATION_REQUEST="sysinit";
    private static String USER_CONFIGURATION_REQUEST="signon";

    protected BlazerConfigurationHandler(IHibernateSessionService sessionPerThreadService) {
        super(sessionPerThreadService);
    }

    protected void handleEvent(HttpServletRequest request, HttpServletResponse response) {
        String requestType = "Device Configuration";
        try {
            String command = request.getParameter("command").trim();
            if(command.equalsIgnoreCase(DEVICE_CONFIGURATION_REQUEST)) {
                String macAddress = MacAddress.format(request.getParameter("mac"));
                log.info("Request for Device Configuration from Device " + macAddress);
                DeviceInfo device = deviceRepository.findByMac(macAddress);
                deviceConfigurationContents(request,response, device);
            }else if(command.equalsIgnoreCase(USER_CONFIGURATION_REQUEST)) {
                requestType = "User Configuration";
                String userName = getRequestParameter(request, "username");
                log.info("Request for User Configuration from User" + userName);
                userConfigurationContents(userName, request, response);
            }
        } catch (IOException e) {
            log.info("Error while writing the "+requestType+" INI contents to device " + e.getMessage());
        }
    }

    private void deviceConfigurationContents(HttpServletRequest request, HttpServletResponse response, DeviceInfo device) throws IOException {
        StringBuffer iniContents = new StringBuffer(LEOSTREAM_PREFIX);
        iniContents.append("\n");
        if(device != null){
            Task currentTask = device.getCurrentTask();
            if(device.hasWtosImagingTaskInProgress() && currentTask.isWtosAutoloadSent() && !device.isBiosUpdateNeeded()){
                currentTask.complete();
                currentTask.setWtosAutoloadSent(false);
            }
            //Device Configuration INI
            sendConfigIniForGroup(response, device, iniContents);
        }else{
            sendDefaultDeviceConfigIni(response, iniContents);
        }
    }

    private void sendConfigIniForGroup(HttpServletResponse response, DeviceInfo device, StringBuffer iniContents) throws IOException {
        DeviceGroup deviceGroup = getDeviceGroup(device);
        WnomConfiguration configuration = deviceGroup.getConfiguration();
        addFileServerDetails(iniContents);
        String modifiedIniContents = configuration.getContentsToView();
//      String iniWithCustomSettings = configuration.iniWithCustomSettings(modifiedIniContents);
        if(StringUtils.isNotBlank(modifiedIniContents)) {
            iniContents.append(modifiedIniContents);
        }
        //AUTOLOAD Settings			
        addWtosAutoloadSettings(device, iniContents);
        String iniString = iniContents.toString();
        log.info("***************** ");
        log.info("SENDING INI CONTENT TO DEVICE WITH IP ADDRESS: " + device.getActiveIp() + "\n INI CONTENTS ARE : \n" + iniString);
        log.info("*******************************************");
        writeIniContents(response, iniString, "Device Configuration");
        changeWtosTaskStatus(iniString, device);
        String configIniSent = configuration.getIniContents(configuration.getConfigurationXml());
        device.setPreviousConfigSent(configIniSent);
        deviceRepository.update(device);
    }

    private void sendDefaultDeviceConfigIni(HttpServletResponse response, StringBuffer iniContents) throws IOException {
        if(userPreferencesRepository.isAutomaticDiscoveryAllowed()){
            log.info("Sending Global Device Configuartion INI");
            WnomConfiguration configuration = wnomConfigurationRepository.getGlobalDeviceConfiguration();
            addFileServerDetails(iniContents);
            String modifiedIniContents = configuration.getModifiedIni("");
            String iniWithCustomSettings = configuration.iniWithCustomSettings(modifiedIniContents);
            iniContents.append(iniWithCustomSettings);
        }else{
            log.info("Automatic discovery diabled. Sending default configuartion INI");
        }
        writeIniContents(response, iniContents.toString(), "Device Configuration");
    }

    public void addFileServerDetails(StringBuffer iniContents) {
        if(userPreferencesRepository.isHttpsCommunicationAllowed()) {
            iniContents.append("FileServer=\"https://");
            iniContents.append(RapportServer.getServerUrl(true));
        }else {
            iniContents.append("FileServer=\"http://");
            iniContents.append(RapportServer.getServerUrl(false));
        }
        iniContents.append("\"");
        iniContents.append("\n\n");
    }

    private DeviceGroup getDeviceGroup(DeviceInfo device) {
        String deviceGroupPath = device.getDeviceGroupPath();
        if(DeviceGroup.UNASSIGNED_PATH.equals(deviceGroupPath)){
            return deviceGroupRepository.findDefaultUnassigned();
        }
        int index = deviceGroupPath.lastIndexOf("/");
        Long groupId = Long.parseLong(deviceGroupPath.substring(index+1));
        return deviceGroupRepository.findById(groupId);
    }
    
    

    private void addWtosAutoloadSettings(DeviceInfo device, StringBuffer response) {
        response.append("\n\n");
        if(device.hasWtosImagingTaskInProgress()){
            List<ICommand> commands = device.getCurrentTask().getCommands();
            if(commands.size() > 0){
                ICommand command = commands.get(0);
                if(command.isCompleted()){
                    log.info("Reboot Command Completed.Adding FileServer and AutoLoad=1 in ini for ipAddress : "+device.getActiveIp());
                    response.append(Device.AUTOLOAD_SET_ONE);		
                }else{                	
                    log.info("Reboot Command is in Progress.Adding AUTOLOAD=0 in ini for device : "+device.getActiveIp());
                    response.append(Device.AUTOLOAD_SET_ZERO);
                }
                
            }else{
                log.info("Command Size is < 0 .Adding FileServer and AutoLoad=1 in ini for ipAddress : "+device.getActiveIp());
                response.append(Device.AUTOLOAD_SET_ONE);
            }
        }else{
            log.info("WTOS Imaging task is not in Progress.Adding AUTOLOAD=0 in ini for device : "+device.getActiveIp());
            response.append(Device.AUTOLOAD_SET_ZERO);
        }
    }

    private void writeIniContents(HttpServletResponse httpServletResponse, String iniContents, String configType) throws IOException {
        PrintWriter writer = httpServletResponse.getWriter();
        writer.write(iniContents);
        writer.close();
    }

    private void changeWtosTaskStatus(String iniContents, DeviceInfo device) {
        if(device!=null){
            if(iniContents.indexOf(Device.AUTOLOAD_SET_ONE)>=0){
                log.info("Setting WTOS AutoloadSent to TRUE");
                device.getCurrentTask().setWtosAutoloadSent(true);
                deviceRepository.update(device);
            }
        }
    }

    private void userConfigurationContents(String userName, HttpServletRequest request, HttpServletResponse servletResponse) throws IOException {
        String hostName = getRequestParameter(request,"tn");
        String ipAddress = getRequestParameter(request,"ip");
        String macAddress = getRequestParameter(request,"mac");

        if(StringUtils.isNotBlank(macAddress) && deviceRepository.findByMac(macAddress) != null){
            DeviceUser currentUser = deviceUserRepository.findUser(userName);
            if(currentUser != null ){
                if(!authenticateUser(request,currentUser)){
                    String msg = "Password mis-match for User <"+userName+">' from device "+hostName+"("+ipAddress+").";
                    systemLogService.warn(msg);
                    log.error(msg);
                    writeIniContents(servletResponse, LEOSTREAM_PREFIX_ERROR, "User Configuration");
                }else{
                    UserGroup userGroup = userGroupRepository.findById(currentUser.getParentUserGroupId());
                    WnomConfiguration configuration = userGroup.getConfiguration();

                    StringBuffer response = new StringBuffer(LEOSTREAM_PREFIX);
                    response.append("\n");
                    /*String modifiedIniContents = configuration.getModifiedIni(currentUser.getPreviousConfigSent());
					String iniWithCustomSettings1 = configuration.iniWithCustomSettings(modifiedIniContents);
					String iniWithCustomSettings = iniWithCustomSettings1;
                     */
                    String modifiedIniContents = configuration.getContentsToView();
//                  String iniWithCustomSettings = configuration.iniWithCustomSettings(modifiedIniContents);
                    if(StringUtils.isNotBlank(modifiedIniContents)) {
                        response.append(modifiedIniContents);
                    }
                    log.info("Sending the "+userName +".ini response :------>\n"+ response);
                    log.info("***************** ");
                    log.info("SENDING INI CONTENT TO USER WITH USER NAME: " + userName + "\n INI CONTENTS ARE : \n" + response);
                    log.info("*******************************************");
                    writeIniContents(servletResponse, response.toString(), "User Configuration");
                    String configIniSent = configuration.getIniContents(configuration.getConfigurationXml());
                    currentUser.setPreviousConfigSent(configIniSent);
                    deviceUserRepository.update(currentUser);			
                    systemLogService.info("'User <"+userName+">' logged in successfully from device "+hostName+"("+ipAddress+").",null);
                }
            }else{
                log.info("User is not managed by WNOM");
                writeIniContents(servletResponse, LEOSTREAM_PREFIX_ERROR, "User Configuration");
            }
        }else{
            log.info("User logged in from a device which is not managed by WNOM");
            writeIniContents(servletResponse, LEOSTREAM_PREFIX_ERROR, "User Configuration");
        }

    }

    private String getRequestParameter(HttpServletRequest request,String parameterName) {
        return request.getParameter(parameterName);
    }



    public static boolean isFileServerRequired(StringBuffer iniContents) {
        for (String attribute : fileServerRequiredAttributes) {
            if(iniContents.indexOf(attribute) >=0){
                return true;
            }
        }
        return false;
    }

    private boolean authenticateUser(HttpServletRequest request, DeviceUser currentUser){
        String userPassword = request.getParameter("password");
        String currentUserPassword = currentUser.getPassword();
        if(StringUtils.isBlank(currentUserPassword)){
            currentUser.setPassword(userPassword);
            deviceUserRepository.update(currentUser);
            return true;
        }
        return currentUserPassword.equals(userPassword);
    }

    public void setDeviceRepository(IDeviceRepository deviceRepository) {
        this.deviceRepository = deviceRepository;
    }

    public void setDeviceUserRepository(IDeviceUserRepository deviceUserRepository) {
        this.deviceUserRepository = deviceUserRepository;
    }

    public void setUserGroupRepository(IUserGroupRepository userGroupRepository) {
        this.userGroupRepository = userGroupRepository;
    }

    public IDeviceGroupRepository getDeviceGroupRepository() {
        return deviceGroupRepository;
    }

    public void setDeviceGroupRepository(IDeviceGroupRepository deviceGroupRepository) {
        this.deviceGroupRepository = deviceGroupRepository;
    }

    public void setSystemLogService(ISystemLogService systemLogService) {
        this.systemLogService = systemLogService;
    }

    public void setWnomConfigurationRepository(IWnomConfigurationRepository wnomConfigurationRepository) {
        this.wnomConfigurationRepository = wnomConfigurationRepository;
    }

    public void setUserPreferencesRepository(IUserPreferencesRepository userPreferencesRepository) {
        this.userPreferencesRepository = userPreferencesRepository;
    }



}
