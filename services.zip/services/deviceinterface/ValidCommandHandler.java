/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 4515 $
 Last Modified: $Date: 2006-01-27 11:36:06 +0530 (Fri, 27 Jan 2006) $
 Last Modified By: $Author: vprahlad $
 */

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;

public class ValidCommandHandler extends AValidEventHandler {
	private static Logger log = Logger.getLogger(ValidCommandHandler.class);
	private String[] RESULTS = new String[]{
			"rebootResult","shutdownResult",
			"rebootNowResult" , "shutdownNowResult",
			"prepareUploadImageToServerResult", "prepareDownloadImageFromServerResult",
			"finalizeUploadImageToServerResult","finalizeDownloadImageFromServerResult"
	};
	private List<String> results = Arrays.asList(RESULTS);
	
	public ValidCommandHandler(IDeviceRepository deviceRepository, IDeviceCommunicationService deviceCommunicationService, ISystemLogService systemLogService, long checkinInterval, String socketAddress) {
		super(deviceRepository, systemLogService, checkinInterval, socketAddress, deviceCommunicationService);
	}
	
	public DeviceInfo handleRequest(Document document, Event event, Writer writer) {
		this.event = event;
		if (parser.hasCommandExecutedSuccessfully(document)) {
			log.info("Executing ValidCommandHandler.....");
			String commandGuid = parser.commandGuid(document);
			DeviceInfo existingDevice = existingDevice(document);
			if (existingDevice != null) {
				if( commandGuid!=null){
					ICommand executedCommand = existingDevice.getCommandByGuid(commandGuid, checkinInterval);
					logInfo(executedCommand.successMessage(document), existingDevice);
					existingDevice.onCommandSuccess(commandGuid);
					deviceRepository.createOrUpdate(existingDevice);
				}
			}
			DeviceInfo device = createOrUpdateDevice(document, event, existingDevice);
			sendResponse(document, device, writer);
			return device;
		}
		return next.handleRequest(document, event, writer);
	}

	DeviceInfo createOrUpdateDevice(Document document, Event event, DeviceInfo existingDevice) {
		DeviceInfo device = createOrUpdateDevice(document, existingDevice);
		if(event.isStartDialogEvent()){
			device.setDialogGuid(parser.getDialogGuid(document));
		}
		return device;
	}
	
	private void sendResponse(Document document, DeviceInfo device, Writer writer) {
		if (results.contains(parser.responseCommand(document))) {
			sendResponse(device, device.onRebootOrShutdownResult(), writer);
		}else {
			sendResponse(device, writer);
		}
	}
	
}
