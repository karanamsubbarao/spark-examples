/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 7454 $
Last Modified: $Date: 2007-05-26 17:42:23 +0530 (Sat, 26 May 2007) $
Last Modified By: $Author: skaranam $
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.common.UUIDGenerator;
import com.wyse.rapport.businesslogic.DeviceRequestParser;
import com.wyse.rapport.command.DiscoverDeviceCommand;
import com.wyse.rapport.command.EndDialogCommand;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.NoCommands;
import com.wyse.rapport.command.SetDeviceGuidCommand;
import com.wyse.rapport.command.SetMonitorServerCommand;
import com.wyse.rapport.command.StartDialogFromDeviceCommand;
import com.wyse.rapport.command.StartDialogFromServerCommand;
import com.wyse.rapport.command.WTOSRebootCommand;
import com.wyse.rapport.command.WTOSShutdownCommand;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.util.WDMUtil;

public abstract class AEventHandler implements IEventHandler {
	private static Logger log = Logger.getLogger(AEventHandler.class);
    private static final List<String> NON_DIALOG_COMMANDS = WDMUtil.asStringList(
    				SetMonitorServerCommand.COMMAND_NAME, 
    				DiscoverDeviceCommand.COMMAND_NAME,
    				SetDeviceGuidCommand.COMMAND_NAME, 
    				StartDialogFromServerCommand.COMMAND_NAME,
    				StartDialogFromDeviceCommand.COMMAND_NAME,
    				WTOSRebootCommand.COMMAND_NAME,
    				WTOSShutdownCommand.COMMAND_NAME);
    					   
    protected IEventHandler next;
    protected DeviceRequestParser parser = new DeviceRequestParser();
    protected IDeviceRepository deviceRepository;
    protected ISystemLogService systemLogService;
    protected IDeviceCommunicationService deviceCommunicationService;
    protected long checkinInterval;
    protected Event event;

    public AEventHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService, long checkinInterval, IDeviceCommunicationService deviceCommunicationService) {
    	this(deviceRepository,systemLogService,deviceCommunicationService);
        this.checkinInterval = checkinInterval;
    }

    public AEventHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService, IDeviceCommunicationService deviceCommunicationService) {
        this.deviceRepository = deviceRepository;
        this.systemLogService = systemLogService;
        this.deviceCommunicationService = deviceCommunicationService;
	}

	public IEventHandler precedes(IEventHandler next) {
        assert next != null : "null EventHandler passed";
        this.next = next;
        return next;
    }

    private boolean hasValidMessage(String message) {
		return message != null && StringUtils.isNotBlank(message) && message.indexOf(NoCommands.COMMAND_NAME) < 0;
	}


    protected DeviceInfo findByMacAddress(Document xmlRequest) {
        Collection<String> macAddresses = parser.macAddressCollection(xmlRequest);
        for (String mac : macAddresses) {
        	DeviceInfo device = deviceRepository.findByMac(mac);
            if (device != null && anyNetworkInterfacesMatch(device, macAddresses)) {
                return device;
            }
        }
        return null;
    }
    
    private boolean anyNetworkInterfacesMatch(DeviceInfo device, Collection<String> macAddresses) {
        for (String mac : macAddresses) {
            for (DeviceNetworkInfo network : device.getDeviceNetworks()) {
                if (network.macMatches(mac)) return true;
            }
        }
        return false;
    }

    protected boolean hasSetGuidResult(Document document) {
        return parser.responseCommand(document).indexOf("setDeviceGuidResult") >= 0;
    }

    protected boolean guidMatches(Document xmlRequest, DeviceInfo device) {
        return device.getDeviceGuid().equals(parser.deviceGuid(xmlRequest));
    }
    
    //********************* Response Construction ************************//

	protected void sendResponse(DeviceInfo device, Writer writer) {
		log.info("inside sendResponse(DeviceInfo device, Writer writer)");
		ICommand command = device.onCheckin(checkinInterval);
		log.info("inside sendResponse(DeviceInfo device, Writer writer) command "+command.displayName());
		ICommand nextCommand = nextCommand(device, command);
		sendResponse(device, nextCommand, writer);
		if(command.equals(nextCommand)){
			device.incrementTaskStatus();
		}
	}
	
	protected void sendResponse(DeviceInfo device, ICommand command, Writer writer) {
		String responseXml = getEventResponse(device, command);
		logResponse(device, command);
		deviceCommunicationService.sendResponse(writer, responseXml);
		if(device != null){
			device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
			deviceRepository.createOrUpdate(device);
		}
	}

	protected ICommand nextCommand(DeviceInfo device, ICommand command) {
		if(!device.inDialog() && !(command instanceof NoCommands) && isDialogCommand(command)){
			command = startDialogFromServerCommand(device);
		} else if(device.inDialog() && command instanceof NoCommands){
			command = endDialogCommand(device);
		}
		return command;
	}
	
    protected ICommand startDialogFromServerCommand(DeviceInfo device) {
		String dialogGuid = new UUIDGenerator().generate();
		device.setDialogGuid(dialogGuid);
		ICommand command = new StartDialogFromServerCommand(dialogGuid);
		command.setCommandGuid(dialogGuid);
		return command;
	}
    
	protected EndDialogCommand endDialogCommand(DeviceInfo device) {
		String dialogGuid = device.getDialogGuid();
		EndDialogCommand command = new EndDialogCommand(dialogGuid);
		command.setCommandGuid(dialogGuid);
		return command;
	}

	boolean isDialogCommand(ICommand command) {
		return (!NON_DIALOG_COMMANDS.contains(command.getCommandName()));
	}

	private String getEventResponse(DeviceInfo device, ICommand command) {
		if(event.isAssetSetEvent()){
			return getResponse(device, command, checkinInterval);
		}
		return getResponse(device, command);
	}
	
	private String getResponse(DeviceInfo device, ICommand command) {
		if(device != null  && device.inDialog() && isDialogCommand(command)){
			return WDMUtil.wdmDialogMessage(command, device.getDialogGuid());
		}
		return WDMUtil.wdmMessage(command);
		
	}

	private String getResponse(DeviceInfo device, ICommand command, long checkinInterval) {
		if(device != null  && device.inDialog() && isDialogCommand(command)){
			return WDMUtil.wdmDialogMessage(event, command, device.getDialogGuid(), checkinInterval);
		}
		return WDMUtil.wdmMessage(event, command, checkinInterval);
	}

	
	//************************ LOGGING ********************//
	protected void logResponse(Device device, ICommand command) {
        String info = "Sent " + command.displayName() + " command to device";
        systemLogService.info(info, device);
    }

    
    protected void logError(String message, DeviceInfo device) {
        if (hasValidMessage(message)){
             systemLogService.error(message, device);
        }
    }

    protected void logInfo(String message, DeviceInfo device) {
        if (hasValidMessage(message)){
             systemLogService.info(message, device);
        }
    }

    protected ICommand monitorServerCommand() {
    	return new SetMonitorServerCommand(WDMUtil.getWDMServerUrl(), "WDM Server", MessageConstants.Values.AssetLevel.FULL, SetMonitorServerCommand.DEFAULT_NEXT_ASSET_REPORT_INTERVAL);	
    }
}

