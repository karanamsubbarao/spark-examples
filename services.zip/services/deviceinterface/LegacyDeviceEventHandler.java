/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 6452 $
Last Modified: $Date: 2006-11-29 12:16:08 +0530 (Wed, 29 Nov 2006) $
Last Modified By: $Author: myadav $
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.net.InetAddress;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.mortbay.http.HttpMessage;
import org.mortbay.http.HttpResponse;
import org.mortbay.jetty.servlet.ServletHttpResponse;

import com.wyse.rapport.command.ELegacyCommand;
import com.wyse.rapport.deviceinterface.LegacyDeviceRequest;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.IThreadPoolService;
import com.wyse.rapport.services.command.LegacyDeviceCommunicationService;
import com.wyse.rapport.services.legacy.LegacyDeviceCheckinService;

/** Understands handling legacy events. */
public class LegacyDeviceEventHandler extends ADeviceEventHandler {
    private static final Logger log = Logger.getLogger(LegacyDeviceEventHandler.class);
    private LegacyDeviceCheckinService legacyDeviceCheckinService;
    private IThreadPoolService threadPoolService;

    public LegacyDeviceEventHandler(IHibernateSessionService sessionPerThreadService, LegacyDeviceCheckinService legacyDeviceCheckinService, IThreadPoolService threadPoolService) {
        super(sessionPerThreadService);
        this.legacyDeviceCheckinService = legacyDeviceCheckinService;
        this.threadPoolService = threadPoolService;
    }

    protected void handleEvent(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        clearHttpVersion(httpServletResponse);
        String remoteAddr = httpServletRequest.getRemoteAddr();
        String response = handleRequest(httpServletRequest, httpServletResponse, remoteAddr);
        log.info("Response to client : " + remoteAddr + " - " + response);
        writeResponse(httpServletResponse, response);
        //TODO - Set the status of the task if any upgrade agent task pending
        if (response.equals(LegacyDeviceCheckinService.INCOMPLETE_INFO)) {
            log.info("Requesting for full asset from legacy device ( " + remoteAddr + " )");
            sendFullAssetRequest(remoteAddr);
        }
    }

    private void clearHttpVersion(HttpServletResponse httpServletResponse) {
        try {
            Field httpResponseField = ServletHttpResponse.class.getDeclaredField("_httpResponse");
            httpResponseField.setAccessible(true);
            HttpResponse response = (HttpResponse) httpResponseField.get(httpServletResponse);
            Field versionField = HttpMessage.class.getDeclaredField("_version");
            versionField.setAccessible(true);
            versionField.set(response, "");
        } catch (Exception e) {
            log.error("Error in clearing the protocol from HTTP Header");
        }
    }

    private void writeResponse(HttpServletResponse httpServletResponse, String response) {
        try {
            PrintWriter out = httpServletResponse.getWriter();
            out.print(response);
            out.close();
        } catch (IOException e) {
            throw new RuntimeException("Unexpected IO Exception: ", e);
        }
    }

    private String handleRequest(HttpServletRequest request, HttpServletResponse httpServletResponse, String remoteAddr) {
        String queryData = request.getQueryString();
        log.info("Got request from device " + remoteAddr + " - " + queryData);
        return (isLegacyRequest(queryData))
               ? handleLegcayRequest(request, httpServletResponse)
               : "";
    }

    private String handleLegcayRequest(HttpServletRequest request, HttpServletResponse response) {
        return new LegacyDeviceRequest(request, response, legacyDeviceCheckinService).handle();
    }

    private void sendFullAssetRequest(String clientAddress) {
        String command = ELegacyCommand.FULL_CHECKIN.command(null);
        try {
            submitJob(new LegacyDeviceCommunicationService(InetAddress.getByName(clientAddress), command));
        } catch (Exception e) {
            log.error("Failed to send getAssets command for legacy device (" + clientAddress + "); Cause " + e);
        }
    }

    private void submitJob(Runnable runnableService) {
        threadPoolService.submitJob(runnableService);
    }

    boolean isLegacyRequest(String queryData) {
        return queryData == null ? false : queryData.toLowerCase().startsWith("&v");
    }
}
