/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 5327 $
Last Modified: $Date: 2006-02-18 13:17:34 +0530 (Sat, 18 Feb 2006) $
Last Modified By: $Author: skaranam $
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.NoCommands;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;

public class CommandErrorHandler extends AEventHandler {
	private static Logger log = Logger.getLogger(CommandErrorHandler.class);
	
    public CommandErrorHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService,
                               long checkinInterval, IDeviceCommunicationService deviceCommunicationService) {
        super(deviceRepository, systemLogService, checkinInterval, deviceCommunicationService);
    }

    public DeviceInfo handleRequest(Document document, Event event, Writer writer) {
    	this.event = event;
    	log.info("Executing CommandErrorHanler.....");
        DeviceInfo device = deviceRepository.findByGuid(event.deviceGuid());
        updateTaskFailure(device, document, event.isCommandNotImplemented());
        sendResponse(device, writer);
        return device;
    }

    ICommand updateTaskFailure(DeviceInfo device, Document document, boolean commandNotImplemented) {
        String commandGuid = parser.commandGuid(document);
        ICommand executedCommand = device.getCommandByGuid(commandGuid, checkinInterval);
        device.getCurrentTask().setErrorMessage(parser.getErrorMessage(document));
        Task task = null;
        if (commandNotImplemented) {
        	logError(executedCommand.unsupported(), device);
            task = device.failCurrentTask();
        } else {
            logError(executedCommand.failureMessage(document), device);
            task = device.onCommandFailure(commandGuid);
        }
        if(task != null && task.isFailed()){
        	logError(task.getName()+" failed; Cause: "+task.getErrorMessage(), device);
        }
        return executedCommand;
    }

    protected void sendResponse(DeviceInfo device, Writer writer) {
    	ICommand command = nextCommand(device, device.onCheckin(checkinInterval));
    	sendResponse(device, command, writer);
    }
    
    protected ICommand nextCommand(DeviceInfo device, ICommand command){
    	if(needDialogEnd(device, command)){
			return endDialogCommand(device);
		}
    	return command;
    }
    
    private boolean needDialogEnd(Device device, ICommand command) {
		return device.inDialog() && command instanceof NoCommands;
	}

    
}