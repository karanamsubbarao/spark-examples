/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 6080 $
Last Modified: $Date: 2006-11-07 19:41:02 +0530 (Tue, 07 Nov 2006) $
Last Modified By: $Author: myadav $
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.rapport.command.DialogErrorCode;
import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.NoCommands;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.util.WDMUtil;

public class DialogResponseHandler extends AEventHandler {
    private static Logger log = Logger.getLogger(DialogResponseHandler.class);
    public DialogResponseHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService,
                               IDeviceCommunicationService deviceCommunicationService, long checkinInterval) {
        super(deviceRepository, systemLogService, checkinInterval,deviceCommunicationService);
    }
    
    public DeviceInfo handleRequest(Document document, Event event, Writer writer) {
    	this.event = event;
        DeviceInfo device = deviceRepository.findByGuid(new Event(document, parser).deviceGuid());
		if(hasDialogResponse(event, device)){
			log.info("Executing dialogResponseHandler.....");
			if(event.hasError() || event.hasEndDialog()){
				device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
				//If the device has not ended the previous dialog with this server, 
				//then server continues to send the pending commands in the same dialog  
				if(event.hasErrorCode(MessageConstants.ErrorCodes.ALREADY_IN_DIALOG)){
	        		String dialogServer = parser.getDialogServer(document);
	        		if(dialogServer.equals(WDMUtil.getWDMServerUrl().toString())){
						device.setDialogGuid(parser.getDialogGuid(document));
						sendResponse(device, writer);
	        			return device;
	        		}
	        	}
//				 Event has StartDialogFromServer error or EndDialog Error/Success response
				logError(event);
	        	device.setDialogGuid(null);
	        	sendResponse(device, new NoCommands(), writer);
	        	if(hasStartDialogError(event)){
	        		//Event has StartDialogFromServer error response
	        		device.setDisplayStatus(DeviceDisplayStatus.BUSY);
	        	}
	        	
	        	return device;
			}
        }
        return next.handleRequest(document, event, writer);
    }

	private void logError(Event event) {
		String errorCode = errorCode(event);
		if(StringUtils.isNotBlank(errorCode)){
			systemLogService.error(DialogErrorCode.getDescription(errorCode));	
		}
	}

    private boolean hasStartDialogError(Event event) {
		return event.hasErrorCode(MessageConstants.ErrorCodes.NO_DIALOG_GUID);
	}
    
    private String errorCode(Event event) {
		return event.errorCode();
	}

	private boolean hasDialogResponse(Event event, DeviceInfo device) {
		return device != null && hasSameCommandGuidAsDialogGuid(device,event.commandGuid());
	}

	private boolean hasSameCommandGuidAsDialogGuid(DeviceInfo device, String commandGuid) {
		return commandGuid != null && commandGuid.equals(device.getDialogGuid());
	}

}