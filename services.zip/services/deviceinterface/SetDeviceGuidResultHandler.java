/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.rapport.command.GetAssetsCommand;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;

public class SetDeviceGuidResultHandler extends AEventHandler {
	private static Logger log = Logger.getLogger(SetDeviceGuidResultHandler.class);
    public SetDeviceGuidResultHandler(IDeviceRepository deviceRepository, IDeviceCommunicationService deviceCommunicationService, ISystemLogService systemLogService, long checkinInterval) {
        super(deviceRepository, systemLogService, checkinInterval, deviceCommunicationService);
    }

    public DeviceInfo handleRequest(Document xmlRequest, Event event, Writer writer) {
    	this.event = event;
    	if (hasSetGuidResult(xmlRequest)) {
        	log.info("Executing SetDeviceGuidResultHandler....");
            DeviceInfo device = deviceRepository.findByGuid(parser.deviceGuid(xmlRequest));
            ICommand command = null;
            if (device != null) {
                command = device.nextCommandOnBoot(checkinInterval);
            	if(device.nextCommand() instanceof GetAssetsCommand){
            		device.incrementTaskStatus();
            	}
            }else{
            	command = monitorServerCommand();
            }
            sendResponse(device, command, writer);
            return device;
        }
        return next.handleRequest(xmlRequest, event, writer);
    }
	
}
