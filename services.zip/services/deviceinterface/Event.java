/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 6755 $
Last Modified: $Date: 2006-12-15 10:33:04 +0530 (Fri, 15 Dec 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.deviceinterface;

import org.dom4j.Document;

import com.wyse.rapport.businesslogic.DeviceRequestParser;
import com.wyse.rapport.command.MessageConstants;

public class Event {
	
    private static final String START_DIALOG = MessageConstants.Events.START_DIALOG;;
    private static final String BOOT = "boot";
    private static final String DETECT = "detect";
	private final Document document;
    private final DeviceRequestParser parser;
    private static final String UPLOAD_IMAGE_TO_SERVER_RESULT="uploadImageToServerResult";
    private static final String UPLOAD_IMAGE_CHECKSUM = "//resultEnvelope/success/uploadImageToServerResult/checksum";

    public Event(Document document, DeviceRequestParser parser) {
        this.document = document;
        this.parser = parser;
    }

    public String deviceGuid() {
        return parser.deviceGuid(document);
    }

    public String commandGuid() {
        return parser.commandGuid(document);
    }

    public String eventGuid() {
        return parser.evaluate("//eventGuid", document);
    }

    public String eventName() {
        return parser.evaluate("//eventName", document);
    }
    
    public boolean isCommandNotImplemented() {
        return parser.isCommandNotImplemented(document);
    }

    public boolean commandSucceeded() {
        return parser.hasCommandExecutedSuccessfully(document);
    }

    public boolean hasUploadImageSuccess() {
    	String responseCommand = parser.responseCommand(document);
    	if(responseCommand.indexOf(UPLOAD_IMAGE_TO_SERVER_RESULT) >= 0){
    		return parser.hasCommandExecutedSuccessfully(document);
    	}
    	return false;
    }
    
    public String checkSumValue(Document document) {
		return parser.evaluate(UPLOAD_IMAGE_CHECKSUM, document);
	}
	

	public boolean hasError() {
		return !parser.hasCommandExecutedSuccessfully(document);
	}

	public boolean hasEndDialog() {
		String responseCommand = parser.responseCommand(document);
		return responseCommand.equals(MessageConstants.Results.END_DIALOG_RESULT);
	}

	public boolean hasStartDialog() {
		String responseCommand = parser.responseCommand(document);
		return responseCommand.equals(MessageConstants.Results.START_DIALOG_FROM_SERVER_RESULT);
	}

	public boolean hasErrorCode(String code) {
		return parser.getErrorCode(document).equals(code);
	}
	
	public String errorCode() {
		return parser.getErrorCode(document);
	}

	public boolean isAssetSetEvent() {
		return document.selectSingleNode("//eventSet/event/assetSet") != null;
	}
	
	public boolean isBootEvent() {
		return BOOT.equals(parser.eventCause(document));
	}
	
	public boolean isDetectEvent() {
		return DETECT.equals(parser.eventCause(document));
	}
	
	public boolean isStartDialogEvent() {
		return START_DIALOG.equals(parser.eventCause(document));
	}

}
