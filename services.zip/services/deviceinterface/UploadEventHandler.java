/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev: 4584 $$
Last Modified: $$Date: 2006-07-18 12:08:19 +0530 (Tue, 18 Jul 2006) $$
Last Modified By: $$Author: skaranam $$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.wyse.common.WDMErrorMessages;
import com.wyse.rapport.businesslogic.WDMFile;
import com.wyse.rapport.services.IHibernateSessionService;

public class UploadEventHandler extends ADeviceEventHandler {
    HttpServletResponse httpServletResponse;
    private static Logger log = Logger.getLogger(UploadEventHandler.class);

    protected UploadEventHandler(IHibernateSessionService sessionPerThreadService) {
        super(sessionPerThreadService);
    }

    protected void handleEvent(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        this.httpServletResponse = httpServletResponse;
        handleRequest(httpServletRequest);
    }

    private void handleRequest(HttpServletRequest request) {
        String fileName = request.getParameter("fileName");
        String range = request.getHeader("Range");
        long restartOffset = 0;
        if (range != null) {
            restartOffset = Long.parseLong(range.substring(0, range.indexOf("-")));
        }
        try {
            BufferedInputStream ins = new BufferedInputStream(request.getInputStream());
            write(ins, new WDMFile(fileName).getAbsolutePath(), restartOffset);
            httpServletResponse.getWriter();
        } catch (Exception e) {
            log.error(WDMErrorMessages.UPLOAD_EVENT_ERROR + fileName + " " + e);
            systemLogService.error(WDMErrorMessages.UPLOAD_EVENT_ERROR + fileName +" from device "+request.getRemoteAddr());
        }
    }

    private static void write(InputStream ins, String fileName, long skiplen) throws IOException {
        byte[] buff = new byte[4096];
        new File(fileName).getParentFile().mkdirs();
        RandomAccessFile raf = new RandomAccessFile(fileName, "rw");
        raf.setLength(skiplen);
        raf.seek(skiplen);
        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(raf.getFD()));
        int count;
        while ((count = ins.read(buff)) != -1) {
            out.write(buff, 0, count);
        }
        ins.close();
        out.flush();
        out.close();
    }
   
}

