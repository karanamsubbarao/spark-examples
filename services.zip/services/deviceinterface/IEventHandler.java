/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;

import org.dom4j.Document;

import com.wyse.rapport.db.tbl.DeviceInfo;

/** Handles device events. */
public interface IEventHandler {
    DeviceInfo handleRequest(Document xmlRequest, Event event, Writer writer);

    IEventHandler precedes(IEventHandler next);
}
