/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 6062 $
Last Modified: $Date: 2006-11-07 09:49:05 +0530 (Tue, 07 Nov 2006) $
Last Modified By: $Author: myadav $
*/
package com.wyse.rapport.services.deviceinterface;

import com.wyse.rapport.servlets.ADeviceRequestServlet;

public class WtosImagingRequestServlet extends ADeviceRequestServlet{

	protected String handlerName() {
		return "wtosImageHandler";
	}

}
