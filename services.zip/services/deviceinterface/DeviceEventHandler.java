/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 6291 $
Last Modified: $Date: 2006-11-20 18:30:19 +0530 (Mon, 20 Nov 2006) $
Last Modified By: $Author: myadav $
 */

package com.wyse.rapport.services.deviceinterface;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import com.wyse.common.WDMErrorMessages;
import com.wyse.rapport.command.NoCommands;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.util.WDMUtil;

/** DeviceInfo event handler for new devices. */
public class DeviceEventHandler extends ADeviceEventHandler {
	private static final Logger log = Logger.getLogger(DeviceEventHandler.class);
	EventProcessingChain eventProcessingChain;
	private IDeviceCommunicationService deviceCommunicationService;
	private IDeviceRepository deviceRepository;
	private IUserPreferencesRepository userPreferencesRepository;
	private String socketAddress;

	public DeviceEventHandler(IHibernateSessionService sessionService, IUserPreferencesRepository userPreferencesRepository, IDeviceRepository deviceRepository, IDeviceCommunicationService deviceCommunicationService) {
		super(sessionService);
		this.userPreferencesRepository = userPreferencesRepository;
		this.deviceRepository = deviceRepository;
		this.deviceCommunicationService = deviceCommunicationService;
	}

	protected void handleEvent(HttpServletRequest request, HttpServletResponse response) {
		String remoteAddr = request.getRemoteAddr();
		try {
			SAXReader reader = new SAXReader();
			reader.setEncoding("UTF-8");
			Document document = reader.read(request.getReader());
			log.info("Received request from device "+remoteAddr + " --> \n"+ document.asXML());
			String deviceGuid = deviceGuid(document);
		    if(userPreferencesRepository.isAutomaticDiscoveryAllowed() ||
		    		(deviceRepository.findByGuid(deviceGuid) != null)){
				handleRequest(document, response.getWriter(), remoteAddr);
			}else{
				if(deviceRepository.isLicenseLimitExceeded()){
					log.info("License Limit of Max number of devices " + RapportServer.licenseLimit() + " exceeded" );
					deviceCommunicationService.sendResponse(response.getWriter(), WDMUtil.wdmMessage(new NoCommands()));					
				}else{
					log.info("Check in recieved from Device " + remoteAddr + " Couldnt proceed because Automatic Discovery is Turned off");
					deviceCommunicationService.sendResponse(response.getWriter(), WDMUtil.wdmMessage(new NoCommands()));
				}
			}
		}catch (Exception e) {
			systemLogService.error(WDMErrorMessages.REQUEST_HANDLING_ERROR + " - from device "+remoteAddr);
			log.info(WDMErrorMessages.REQUEST_HANDLING_ERROR, e);
			throw new RuntimeException(WDMErrorMessages.REQUEST_HANDLING_ERROR, e);
		}
	}

	Device handleRequest(Document xmlDoc, Writer writer, String socketAddress) throws IOException {
		this.socketAddress = socketAddress;
		return handleRequest(xmlDoc, writer);
	}

	DeviceInfo handleRequest(Document document, Writer writer) {
		EventChainFactory eventChainFactory = new EventChainFactory(sessionPerThreadService, deviceRepository, deviceCommunicationService);
		eventChainFactory.setSocketAddress(socketAddress);
		eventProcessingChain = eventChainFactory.createChain();
		eventProcessingChain.setSocketAddress(socketAddress);
		return eventProcessingChain.handleRequest(document, writer);
	}
	

	private String deviceGuid(Document document) {
		Node guidNode = document.selectSingleNode("//deviceGuid");
		return guidNode == null ? null : guidNode.getText();
	}
}
