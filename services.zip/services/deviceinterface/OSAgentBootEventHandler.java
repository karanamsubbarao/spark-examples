/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev: 3462 $$
Last Modified: $$Date: 2005-12-23 09:46:20 +0530 (Fri, 23 Dec 2005) $$
Last Modified By: $$Author: smariswamy $$
 */

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.rapport.command.ECommandStatus;
import com.wyse.rapport.command.ETaskStatus;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.NoCommands;
import com.wyse.rapport.command.TasksFactory;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;

/** Responds to OS agent boot events. */
public class OSAgentBootEventHandler extends AValidEventHandler {
	private static Logger log = Logger.getLogger(OSAgentBootEventHandler.class);

	public OSAgentBootEventHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService, long checkinInterval, String socketAddress, IDeviceCommunicationService deviceCommunicationService) {
		super(deviceRepository, systemLogService, checkinInterval, socketAddress, deviceCommunicationService);
	}

	public DeviceInfo handleRequest(Document document, Event event, Writer writer) {
		this.event = event;
		String eventCause = parser.eventCause(document);
		if ("boot".equals(eventCause)) {
			log.info("Executing OsAgentBootEventHandler..BOOT Event..");
			DeviceInfo device = existingDevice(document);
			if (device != null) {
				device = createOrUpdateDevice(document, device);
				sendResponse(device, writer);
			}else{
				sendResponse(null, monitorServerCommand(), writer);
			}
			return device;
		}else if ("detect".equals(eventCause)) {
			log.info("Executing OsAgentBootEventHandler..DETECT Event..");
			sendResponse(null, new NoCommands(), writer);
			return null;
		}
		return next.handleRequest(document, event, writer);
	}

	protected void sendResponse(DeviceInfo device, Writer writer) {
		ICommand commandOnNextBoot = device.onBoot(checkinInterval);
		Task currentTask = device.getCurrentTask();
		if(device.isWtosDevice() && TasksFactory.WTOS_TASK.equalsIgnoreCase(currentTask.getName())){
			ICommand rebootCommand = currentTask.getCommands().get(0);
			if(rebootCommand.getCmdStatus()!=ECommandStatus.COMPLETE && rebootCommand.getCmdStatus()!=ECommandStatus.FAILED){
				//Ask device to do imaging which is scheduled on Next Reboot
				rebootCommand.setCmdStatus(ECommandStatus.COMPLETE);
				log.info("CHAGNED IMAGING REBOOT COMMAND STATUS TO COMPLETE");
				currentTask.setStatus(ETaskStatus.IN_PROGRESS);
				deviceRepository.createOrUpdate(device);
				sendResponse(device, new NoCommands(), writer);
			}else{
				//Ask for Full Assest After Imaging
				log.info("Asking for Full Asset---- After Imaging");
				sendNextCommand(device, writer);
			}
		}else{
			sendResponse(device, commandOnNextBoot, writer);
			if(commandOnNextBoot.equals(device.nextCommand())){
				device.incrementTaskStatus();
			}
		}
	}

	private void sendNextCommand(DeviceInfo device, Writer writer) {
		ICommand command = device.onBoot(checkinInterval);
		sendResponse(device, command, writer);
		if(command.equals(device.nextCommand())){
			device.incrementTaskStatus();
		}
	}
}
