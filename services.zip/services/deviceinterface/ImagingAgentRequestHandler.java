/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 6290 $
Last Modified: $Date: 2006-11-20 18:29:33 +0530 (Mon, 20 Nov 2006) $
Last Modified By: $Author: myadav $
 */

package com.wyse.rapport.services.deviceinterface;

import java.io.File;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.rapport.businesslogic.BOMCreator;
import com.wyse.rapport.businesslogic.WDMFile;
import com.wyse.rapport.command.FinalizeUploadImageToServerCommand;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.UploadImageToServerCommand;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.util.FileUtil;
import com.wyse.rapport.util.MD5Checksum;
import com.wyse.rapport.util.MasterRepository;
import com.wyse.rapport.util.WDMUtil;
import com.wyse.rapport.util.WordUtils;
import com.wyse.rapport.util.ZipUtil;

/** Understands responding to device agent checkins. */
public class ImagingAgentRequestHandler extends AValidEventHandler {
	private static final String IMAGE_BOM_XML = MessageConstants.Elements.IMAGE_BOM_XML;
	private static Logger log = Logger.getLogger(ImagingAgentRequestHandler.class);
	public ImagingAgentRequestHandler(IDeviceRepository deviceRepository, IDeviceCommunicationService deviceCommunicationService, ISystemLogService systemLogService, long checkinInterval, String socketAddress) {
		super(deviceRepository, systemLogService, checkinInterval, socketAddress, deviceCommunicationService);
	}

	public DeviceInfo handleRequest(Document document, Event event, Writer writer)  {
		this.event = event;
		DeviceInfo device = existingDevice(document);
		if (parser.deviceAgentCheckinEvent(document)) {
			log.info("Executing ImagingAgentRequestHandler....");
			sendResponse(device, writer);
			device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
			deviceRepository.createOrUpdate(device);
			return device;
		}else if(event.hasUploadImageSuccess()){
			log.info("Executing ImagingAgentRequestHandler..");
			ICommand commandExecuted = device.getCommandByGuid(event.commandGuid(), checkinInterval);
			String checkSumOfFile = md5Checksum(commandExecuted);
			
			if(!event.checkSumValue(document).equals(checkSumOfFile)){
				return failUploadImage(device, commandExecuted, writer);
			}
			((UploadImageToServerCommand)commandExecuted).setMd5CheckSum(checkSumOfFile);
			
			deviceRepository.createOrUpdate(device);
			device.onCommandSuccess(event.commandGuid());
			if(device.nextCommand() instanceof FinalizeUploadImageToServerCommand){
				createArchive(device, device.getCurrentTask());
			}
			sendResponse(device, writer);
			return device;
		}
		return next.handleRequest(document, event, writer);
	}

	void createArchive(DeviceInfo device, Task task)  {
		List<UploadImageToServerCommand> commands = fetchUploadCommands(task);
		UploadImageToServerCommand uploadImageCommand = commands.get(0);
		String destination = uploadImageCommand.getDestination();
		destination = destination.substring(0, destination.lastIndexOf("_"));
		WDMFile wdmFile = new WDMFile(WDMUtil.getURL(destination));
		String bomFileName = new File(wdmFile.getParent(),IMAGE_BOM_XML).getAbsolutePath();
		String zipFileName = wdmFile.getParent()+MasterRepository.WIF_EXTN;
		BOMCreator bom = new BOMCreator(commands);
		bom.createBOMFile(device,bomFileName);
		ZipUtil.makeZip(wdmFile.getParent(), zipFileName);
		log.info("Deleting the directory after archiving" + wdmFile.getParent());
		FileUtil.deleteFiles(new File(wdmFile.getParent()));
	}

	private List<UploadImageToServerCommand> fetchUploadCommands(Task task) {
		List<UploadImageToServerCommand> uploadCommands = new ArrayList<UploadImageToServerCommand>();
		List<ICommand> commands = task.getCommands();
		for(ICommand command : commands) {
			ICommand commandFromXML = command.fromXml();
			if(commandFromXML instanceof UploadImageToServerCommand) {
				UploadImageToServerCommand uploadImageToServerCommand = (UploadImageToServerCommand)commandFromXML;
				uploadCommands.add(uploadImageToServerCommand);
			}
		}
		return uploadCommands;
	}
	
	//9945541461

	protected String md5Checksum(ICommand command) {
		UploadImageToServerCommand uploadImageToServerCommand = (UploadImageToServerCommand)command;
		WDMFile wdmFile =  new WDMFile(WDMUtil.getURL(uploadImageToServerCommand.getDestination()));
		return MD5Checksum.getChecksum(wdmFile);

	}
	
	protected DeviceInfo failUploadImage(DeviceInfo device, ICommand command, Writer writer) {
		logError(WordUtils.sentence(command.getCommandName()) + " failed; Cause - Checksum error ", device);
		device.onCommandFailure(command.getCommandGuid());
		sendResponse(device, writer);
		return device;
	}

}
