/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 4809 $
Last Modified: $Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.deviceinterface;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.SystemLogService;

/** Abstract class for all device event handlers */
public abstract class ADeviceEventHandler implements IDeviceEventHandler {
    protected IHibernateSessionService sessionPerThreadService;
    protected ISystemLogService systemLogService;

    protected ADeviceEventHandler(IHibernateSessionService sessionPerThreadService) {
        this.sessionPerThreadService = sessionPerThreadService;
        this.systemLogService = new SystemLogService(sessionPerThreadService);
    }

    public void process(HttpServletRequest request, HttpServletResponse response) {
        try {
            handleEvent(request, response);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            sessionPerThreadService.closeSession();
        }
    }

    protected abstract void handleEvent(HttpServletRequest request, HttpServletResponse response);
}
