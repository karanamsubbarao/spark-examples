/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 4183 $
Last Modified: $Date: 2006-05-26 01:06:44 +0530 (Fri, 26 May 2006) $
Last Modified By: $Author: kquinto $
*/

package com.wyse.rapport.services.deviceinterface;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** Handles device events received from devices */
public interface IDeviceEventHandler {
    void process(HttpServletRequest request, HttpServletResponse response);
}
