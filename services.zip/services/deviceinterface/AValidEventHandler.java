/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev: 6942 $$
Last Modified: $$Date: 2007-01-31 14:08:29 +0530 (Wed, 31 Jan 2007) $$
Last Modified By: $$Author: myadav $$
*/

package com.wyse.rapport.services.deviceinterface;

import java.util.Collection;
import java.util.Date;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.rapport.db.tbl.DeviceGroup;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;

public abstract class AValidEventHandler extends AEventHandler {
    private String socketAddress;

    private Logger log = Logger.getLogger(AValidEventHandler.class);
    public AValidEventHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService, long checkinInterval, String socketAddress, IDeviceCommunicationService deviceCommunicationService) {
        super(deviceRepository, systemLogService, checkinInterval, deviceCommunicationService);
        this.socketAddress = socketAddress;
    }

    protected DeviceInfo createOrUpdateDevice(Document document, DeviceInfo existingDevice) {
        if (existingDevice != null) {
        	log.info("Updating old device");
            existingDevice = updateDevice(existingDevice, document);
        } else {
            log.info("Checkin received from a new device ");
            existingDevice = createDevice(document);
        }
        if (existingDevice != null) {
        	existingDevice.setLegacy(false);
        }
        existingDevice.setManualDevice(false);
        return existingDevice;
    }

    private DeviceInfo updateDevice(DeviceInfo existingDevice, Document document) {
        DeviceInfo device = parser.updateDevice(existingDevice, document);
        device.setCheckIn(new Date());
        device.setActiveNetwork(socketAddress);
        return device;
    }

    private DeviceInfo createDevice(Document xmlString) {
        DeviceInfo device = parser.device(xmlString);
        if (device != null && !parser.isMinimalAsset(xmlString)) {
        	device.setDeviceGroupPath(DeviceGroup.UNASSIGNED_PATH);	
            device.setCheckIn(new Date());
            device.setActiveNetwork(socketAddress);
            deviceRepository.create(device);
            return device;
        }
        return null;
    }

    protected DeviceInfo existingDevice(Document document) {
        DeviceInfo device = findByDeviceGuid(document);
        if(device == null){
			device = findByMacAddress(document);
		}
        return device;
    }

	private DeviceInfo findByDeviceGuid(Document document) {
        String deviceGuid = parser.deviceGuid(document);
        if(deviceGuid == null) return null;
        deleteLegacyDevice(document, deviceGuid);
        return deviceRepository.findByGuid(deviceGuid);
	}
	
	/**
	 *	Delete legacy device with same mac, as legacy device can have only one mac
	 *	and if that mac exist in the xml request, then it is same device checking in sa new device
	 */
   private void deleteLegacyDevice(Document document, String deviceGuid) {
        DeviceInfo legacyDevice = findLegacyByMac(parser.macAddressCollection(document));
        if (legacyDevice != null && !(hasSameGuid(deviceGuid, legacyDevice))) {
            deviceRepository.delete(legacyDevice);
        }
    }

    private boolean hasSameGuid(String deviceGuid, DeviceInfo legacyDevice) {
        return legacyDevice.getDeviceGuid().equals(deviceGuid);
    }

    private DeviceInfo findLegacyByMac(Collection<String> macList) {
        for (String mac : macList) {
            DeviceInfo info = deviceRepository.findLegacyDeviceByMac(mac);
            if (info != null) {
                return info;
            }
        }
        return null;
    }
    

}
