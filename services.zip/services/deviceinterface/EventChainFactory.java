/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 4809 $
Last Modified: $Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.deviceinterface;

import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.SystemLogService;
import com.wyse.rapport.services.persistence.UserPreferencesRepository;

/** Creates Event Processing Chains. */
public class EventChainFactory {
    private final IDeviceRepository deviceRepository;
    private IDeviceCommunicationService deviceCommunicationService;
    private final IHibernateSessionService sessionPerThreadService;
    private long checkinInterval;
    private String socketAddress;

    public EventChainFactory(IHibernateSessionService sessionPerThreadService,
                             IDeviceRepository deviceRepository, IDeviceCommunicationService deviceCommunicationService) {
        this.sessionPerThreadService = sessionPerThreadService;
        this.deviceRepository = deviceRepository;
        this.deviceCommunicationService = deviceCommunicationService;
    }

    public EventProcessingChain createChain() {
        UserPreferencesRepository userPreferencesRepository = new UserPreferencesRepository(sessionPerThreadService);
        this.checkinInterval = new UserPreferences(userPreferencesRepository).getCheckinIntervalInSeconds();
        ISystemLogService systemLogService = new SystemLogService(sessionPerThreadService);
        return new EventProcessingChain(newDeviceHandler(deviceRepository, systemLogService),
        								setDeviceGuidResultHandler(deviceRepository, systemLogService),
        								imagingAgentHandler(deviceRepository, systemLogService),
                                        osAgentBootHandler(deviceRepository, systemLogService),
                                        dialogResponseHandler(deviceRepository, systemLogService),
                                        validCommandHandler(deviceRepository, systemLogService),
                                        commandErrorHandler(deviceRepository, systemLogService));
    }

    private IEventHandler newDeviceHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService) {
        return new NewDeviceHandler(deviceRepository, systemLogService, checkinInterval, deviceCommunicationService);
    }

    private IEventHandler setDeviceGuidResultHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService) {
        return new SetDeviceGuidResultHandler(deviceRepository, deviceCommunicationService, systemLogService, checkinInterval);
    }

    private IEventHandler imagingAgentHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService) {
        return new ImagingAgentRequestHandler(deviceRepository, deviceCommunicationService, systemLogService, checkinInterval, socketAddress);
    }

    private IEventHandler osAgentBootHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService) {
        return new OSAgentBootEventHandler(deviceRepository, systemLogService, checkinInterval, socketAddress, deviceCommunicationService);
    }

    private IEventHandler dialogResponseHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService) {
		return new DialogResponseHandler(deviceRepository, systemLogService, deviceCommunicationService, checkinInterval);
	}

    private IEventHandler validCommandHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService) {
        return new ValidCommandHandler(deviceRepository, deviceCommunicationService, systemLogService, checkinInterval, socketAddress);
    }

    private IEventHandler commandErrorHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService) {
        return new CommandErrorHandler(deviceRepository, systemLogService, checkinInterval, deviceCommunicationService);
    }

    public void setSocketAddress(String socketAddress) {
        this.socketAddress = socketAddress;
    }
}