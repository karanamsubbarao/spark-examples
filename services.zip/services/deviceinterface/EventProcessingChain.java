/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.rapport.businesslogic.DeviceRequestParser;
import com.wyse.rapport.command.AssetSetEventResult;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.util.XmlUtil;

public class EventProcessingChain {
    
	private IEventHandler firstHandler;
	private String socketAddress;
	private static Logger logger = Logger.getLogger(EventProcessingChain.class);
	
    
    public EventProcessingChain(IEventHandler ...eventHandlers) {
        firstHandler = eventHandlers[0];
        IEventHandler handler = firstHandler;
        for (int i = 1; i < eventHandlers.length; i++) {
            handler = handler.precedes(eventHandlers[i]);
        }
    }

    public DeviceInfo handleRequest(Document document, Writer writer){
        try {
        	DeviceRequestParser parser = new DeviceRequestParser();
			Event event = new Event(document,parser);
		  	if(RapportServer.isWNOMProduct() &&  !parser.isMinimalAsset(document) &&  !parser.isWTOSDevice(document)) {
        		logger.error("xml received from device is not from WTOS Device" +socketAddress);
        		return null;
        	}
        	if(XmlUtil.validateWithDebugLog(document,socketAddress)){
        		return firstHandler.handleRequest(document, event, writer);
        	}
    		//construct the xml with malformed
    		logger.error("Failed to validate xml received from device "+socketAddress);
    		writer.write(new AssetSetEventResult(event.eventGuid(), 3600).errorMessage());
		} catch (Exception e) {
			logger.error("Failed to handle request from device "+socketAddress, e);
		}
		return null;
    }

	public void setSocketAddress(String socketAddress) {
		this.socketAddress = socketAddress;
	}
	
}
