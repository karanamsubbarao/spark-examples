/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 7583 $
Last Modified: $Date: 2007-07-20 11:45:32 +0530 (Fri, 20 Jul 2007) $
Last Modified By: $Author: gkanagaraj $
 */
package com.wyse.rapport.services.deviceinterface;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.sun.corba.se.spi.activation.Repository;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceGroup;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.persistence.DeviceGroupRepository;
import com.wyse.rapport.services.persistence.DeviceRepository;
import com.wyse.rapport.services.persistence.IDeviceGroupRepository;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.services.persistence.UserPreferencesRepository;
import com.wyse.rapport.util.MasterRepository;
import com.wyse.rapport.wnom.WnomConfiguration;
import com.wyse.rapport.wnom.connections.WnomUtil;

public class WtosImageHandler extends ADeviceEventHandler{

	private static Logger log = Logger.getLogger(WtosImageHandler.class);
	private IDeviceRepository deviceRepository;
	private IDeviceGroupRepository deviceGroupRepository;
	private IUserPreferencesRepository userPreferencesRepository;
	
	protected WtosImageHandler(IHibernateSessionService sessionPerThreadService) {
		super(sessionPerThreadService);
		deviceRepository=new DeviceRepository(sessionPerThreadService);
		deviceGroupRepository=new DeviceGroupRepository(sessionPerThreadService);
		userPreferencesRepository = new UserPreferencesRepository(sessionPerThreadService);
	}
	
	

	protected void handleEvent(HttpServletRequest request, HttpServletResponse response) {
		String remoteAddr = request.getRemoteAddr();
		String requestURI = request.getRequestURI();
		log.info("HTTP Request UTI : "+requestURI);
		String imageFileName = requestURI.substring(requestURI.lastIndexOf("/")+1);
		log.info("Handling request for WTOSImageHandler : for IPAdress :"+remoteAddr+" for "+imageFileName);
		
		if("wnos.ini".equals(imageFileName)){
			log.info("Requested for wnos.ini " + imageFileName);
			writeIni(response, remoteAddr);
			return;
		}
		
		if(requestURI.indexOf("bitmap/") >=0){
			imageFileName = requestURI.substring(requestURI.lastIndexOf("bitmap/")+"bitmap/".length());
			log.info("Requested for background image " + imageFileName);
			writeBackgroundImage(response, remoteAddr, imageFileName);
			return;
		}
		
		if(isImagingRequest(requestURI)) {
			log.info("Requested for wtos device image" + requestURI);
			writeWtosOrBIOSImage(request, response, remoteAddr, imageFileName);
			return;
		}
				
		if(requestURI.indexOf("cacerts/") >=0){
			String certificateFileName = requestURI.substring(requestURI.lastIndexOf("cacerts/")+"cacerts/".length());
			log.info("Requested for Certificate" + certificateFileName);
			writeCertificate(response, remoteAddr, certificateFileName);
			return;
		}
		
		if(StringUtils.isNotBlank(imageFileName)) {
			log.info("Requested for Notice File " + imageFileName);
			writeNoticeFile(response, remoteAddr, imageFileName);
			return;
		}
	}

	private boolean isImagingRequest(String requestURI) {
		return requestURI.indexOf("RCA_wnos") >= 0  || 
			   requestURI.indexOf("V10L_wnos") >= 0 || 
			   requestURI.indexOf("VL10_wnos") >= 0 || 
			   requestURI.indexOf("xpress.rom") >= 0;
	}
	
	private void writeWtosOrBIOSImage(HttpServletRequest request, HttpServletResponse response, String remoteAddr, String imageFileName) {
		String deviceGuid=request.getHeader("deviceGuid");
		if(StringUtils.isBlank(deviceGuid)) {
			deviceGuid=request.getParameter("deviceGuid");
		}
		log.info("*** device Guid received from GET request :"+ deviceGuid);
		DeviceInfo device = deviceRepository.findByGuid(deviceGuid);
		log.info("***** Imaging Task is In Progress for "  + device.getActiveIp() + " " +device.hasWtosImagingTaskInProgress());
		if(device!=null && device.hasWtosImagingTaskInProgress())
		{
			String imageLocation = device.getCurrentTask().getImagePath();
			File file = new File(imageLocation,imageFileName);
			if (file.exists()) {
				writeStream(response, file);
			}else {
				device.setBiosUpdateNeeded(false);
				device.getCurrentTask().complete();
				device.getCurrentTask().setWtosAutoloadSent(false);
				try {
					response.getOutputStream().print("");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(request.getRequestURI().indexOf("xpress.rom")<0) {
				device.setBiosUpdateNeeded(true);
			}else {
				device.setBiosUpdateNeeded(false);
				device.getCurrentTask().complete();
				device.getCurrentTask().setWtosAutoloadSent(false);
			}
			deviceRepository.update(device);
		}
	}

	private void writeNoticeFile(HttpServletResponse response, String remoteAddr, String imageFileName) {
		File file = new File(MasterRepository.rootDirectory(),imageFileName);
		if(file.exists()) {
			writeStream(response, file);
		}
	}

	private void writeCertificate(HttpServletResponse response, String remoteAddr, String imageFileName) {
		File file = new File(MasterRepository.wtosCertificatesFileDirectory(),imageFileName);
		writeStream(response, file);
	}
	
	private void writeBackgroundImage(HttpServletResponse response, String remoteAddr, String imageFileName) {
		File file = new File(MasterRepository.wtosBackgroundFileDirectory(),imageFileName);
		writeStream(response, file);
	}
	
	private void writeStream(HttpServletResponse response, File file) {
		log.info("Requested for image "+file.getAbsolutePath());
		try {
			FileInputStream stream = new FileInputStream(file);
			writeImage(stream, response.getOutputStream());
		} catch (Exception e) {
			log.error("Error while writing image file "+file.getAbsolutePath()+"; Cause - "+e.getMessage());
		}
	}

	private void writeImage(InputStream inputStream, OutputStream outStream) {
		try {
			byte b[] = new byte[1024];
			int amount;
			while ((amount = inputStream.read(b)) > 0) {
				outStream.write(b, 0, amount);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				outStream.close();
				inputStream.close();
			} catch (IOException e) {

			}
		}
	}

	private void writeIni(HttpServletResponse response, String remoteAddr) {
		PrintWriter writer=null;
		try {
			writer = response.getWriter();
			String responseString = getWnosContent(remoteAddr);
			writer.write(responseString.toString());
		} catch (IOException e) {
			log.info("Error while writing Results=OK to WTOS device "+remoteAddr);
		}finally{
			writer.close();
		}
	}

	private String getWnosContent(String remoteAddr) {
		DeviceInfo device = deviceRepository.findWtosDeviceToImage(remoteAddr);
		StringBuffer iniContents = new StringBuffer();
		addFileServerDetails(iniContents);
		if(device != null){
			addDeviceConfigIni(device, iniContents);
			List<ICommand> commands = device.getCurrentTask().getCommands();
			if(commands.size() > 0){
				ICommand command = commands.get(0);
				if(command.isCompleted()){
					setAutoLoadToOne(device, iniContents);
				}else if(device.isBiosUpdateNeeded()){                	
		            log.info("WTOS BIOS Imaging task is in Progress.Adding AUTOLOAD=1 in ini for device : "+device.getActiveIp());
		            setAutoLoadToOne(device, iniContents);
		        }else{
					log.info("Adding AUTOLOAD=0 in ini for device : "+device.getActiveIp());
					iniContents.append(Device.AUTOLOAD_SET_ZERO);
				}
			}else{
				setAutoLoadToOne(device, iniContents);
			}
		}else{
			iniContents.append(Device.AUTOLOAD_SET_ZERO);
		}
		log.info("WNOS Content for device "+remoteAddr+"\n"+iniContents.toString());
		return iniContents.toString();
	}

	private void setAutoLoadToOne(DeviceInfo device, StringBuffer iniContents) {
		log.info("Adding FileServer and AutoLoad=1 in ini for ipAddress : "+device.getActiveIp());
		iniContents.append(Device.AUTOLOAD_SET_ONE);
		device.getCurrentTask().setWtosAutoloadSent(true);
		deviceRepository.update(device);
	}

	private void addDeviceConfigIni(DeviceInfo device, StringBuffer iniContents) {
		DeviceGroup deviceGroup = getDeviceGroup(device);
		WnomConfiguration configuration = deviceGroup.getConfiguration();
		
		String modifiedIniContents = configuration.getModifiedIni(device.getPreviousConfigSent());
		String iniWithCustomSettings = configuration.iniWithCustomSettings(modifiedIniContents);
		
		iniContents.append(iniWithCustomSettings);
		WnomUtil.suffixNewLine(iniContents);
	}
	
	private DeviceGroup getDeviceGroup(DeviceInfo device) {
		String deviceGroupPath = device.getDeviceGroupPath();
        if(DeviceGroup.UNASSIGNED_PATH.equals(deviceGroupPath)){
    	    return deviceGroupRepository.findDefaultUnassigned();
        }
        int index = deviceGroupPath.lastIndexOf("/");
        Long groupId = Long.parseLong(deviceGroupPath.substring(index+1));
        return deviceGroupRepository.findById(groupId);
	}

	private void addFileServerDetails(StringBuffer iniContents) {
		if(userPreferencesRepository.isHttpsCommunicationAllowed()) {
			iniContents.append("FileServer=\"https://");
			iniContents.append(RapportServer.getServerUrl(true));
		}else {
			iniContents.append("FileServer=\"http://");
			iniContents.append(RapportServer.getServerUrl(false));
		}
		iniContents.append("\"");
		iniContents.append("\n\n");
	}
}
