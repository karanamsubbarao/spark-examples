/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;
import java.util.Date;

import org.apache.log4j.Logger;
import org.dom4j.Document;

import com.wyse.common.UUIDGenerator;
import com.wyse.rapport.command.SetDeviceGuidCommand;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.util.OSTypes;

public class NewDeviceHandler extends AEventHandler {
	Logger log=Logger.getLogger(NewDeviceHandler.class);
    public NewDeviceHandler(IDeviceRepository deviceRepository, ISystemLogService systemLogService, long checkinInterval, IDeviceCommunicationService deviceCommunicationService) {
        super(deviceRepository, systemLogService, checkinInterval, deviceCommunicationService);
    }

    /**
     * Handle if the device does not have any guid, then sends setDeviceGuid commmand and if the full asset
     * is required for the device.
     */
    public DeviceInfo handleRequest(Document document, Event event, Writer writer) {
    	this.event = event;
    	if (!hasGuid(document)) {
            sendSetDeviceGuid(document, writer);
            return null;
        } else if (isFullAssetRequired(document)) {
            sendResponse(null, monitorServerCommand(), writer);
            return null;
        }
        else{
        	DeviceInfo existingDevice = findByMacAddress(document);
        	if(existingDevice != null && !guidMatches(document, existingDevice)){
       			if(OSTypes.WTOS.equalsIgnoreCase(existingDevice.getOsName())){
       				if(hasMinimalAsset(document)){
       					sendResponse(null, monitorServerCommand(), writer);
       					return null;
       				}
       				DeviceInfo newDevice = createNewDevice(existingDevice,document);
       				sendResponse(newDevice, writer);
       				return newDevice;
       			}
       			sendSetDeviceGuid(document, writer);
       	        return null;
        	}
        }
        return next.handleRequest(document, event, writer);
    }
    
    DeviceInfo createNewDevice(DeviceInfo existingDevice, Document document) {
		try {
			DeviceInfo newDevice = parser.device(document);
			newDevice.mergeFullDevice(existingDevice);
			newDevice.setNextAssetReportTime(new Date(), checkinInterval);
			newDevice.setCheckIn(new Date());
			newDevice.setLegacy(false);
		    deviceRepository.delete(existingDevice);
	    	deviceRepository.create(newDevice);
	    	return newDevice;
		} catch (Exception e) {
			log.error("unable to construct the full device object : "+e);
			return null;
		}
	}

	protected boolean isInvalidGuid(Document xmlRequest) {
        DeviceInfo existingDevice = findByMacAddress(xmlRequest);
        return existingDevice != null && !guidMatches(xmlRequest, existingDevice);
    }
    
    boolean hasGuid(Document document) {
        return parser.hasGuid(document);
    }

    boolean isFullAssetRequired(Document document) {
        return (parser.osAgentBootEvent(document) || existingDevice(document))
               ? false
               : hasMinimalAsset(document);
    }

    boolean existingDevice(Document xmlRequest) {
        return hasGuid(xmlRequest) && deviceRepository.findByGuid(parser.deviceGuid(xmlRequest)) != null;
    }

    boolean hasMinimalAsset(Document xmlRequest) {
        return hasSetGuidResult(xmlRequest) ? true : parser.isMinimalAsset(xmlRequest);
    }
    
    private void sendSetDeviceGuid(Document xmlRequest, Writer writer) {
        String deviceGuid = deviceGuid(xmlRequest);
        String invalidGuid = invalidDeviceGuid(xmlRequest, deviceGuid);
        sendResponse(null, new SetDeviceGuidCommand(invalidGuid, deviceGuid), writer);
    }

    private String invalidDeviceGuid(Document xmlRequest, String deviceGuid) {
        String deviceGuidFromParser = parser.deviceGuid(xmlRequest);
        return (deviceGuid.equals(deviceGuidFromParser)) ? null : deviceGuidFromParser;
    }

    private String deviceGuid(Document xmlRequest) {
        DeviceInfo existingDevice = findByMacAddress(xmlRequest);
        return existingDevice != null ? existingDevice.getDeviceGuid() : new UUIDGenerator().generate();
    }


}