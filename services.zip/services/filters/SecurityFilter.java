package com.wyse.rapport.services.filters;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.commons.lang.StringUtils;

import com.wyse.rapport.adminclient.guidedactions.PushImageGuidedActionController;
import com.wyse.rapport.server.RapportServer;

public class SecurityFilter implements Filter {

	private static final String LOGOUT_HTM = "logout.htm";
    private static final String LICENSE_HTM = "importLicense.htm";
    private static final String PUSH_IMAGE_HTM = "pushImage.htm";
	public static final String LICENSE_HTM_SHOW_FORM = "importLicense.htm?action=showLicenseForm";
	public static final String LOGIN_HTM = "login.htm";
	public static final String INVALID_FILE = "invalidFile";
    public static final String LIMIT_EXCEEDED = "limitExceeded";

	//      private FilterConfig config = null;
	public void init(FilterConfig config) throws ServletException {
//		this.config = config;
	}

	public void destroy() {
//		config = null;
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		String action=httpRequest.getRequestURI().substring(httpRequest.getContextPath().length());
		boolean isExpired = RapportServer.isExpired();
		if(!action.contains(PUSH_IMAGE_HTM)){
			httpRequest.getSession().removeAttribute(PushImageGuidedActionController.SELECTED_DEVICES_MAP);
		}
		if(action.contains(LOGIN_HTM) || action.contains(LOGOUT_HTM) || action.contains(LICENSE_HTM)){

		}else if(isExpired && RapportServer.isWNOMProduct()){
			HttpSession session = httpRequest.getSession();
			String invalidFile = (String) session.getAttribute(INVALID_FILE);
			if(StringUtils.isNotBlank(invalidFile)){
				request.setAttribute(INVALID_FILE, invalidFile);
				session.removeAttribute(INVALID_FILE);
			}
			RequestDispatcher rd= request.getRequestDispatcher(LICENSE_HTM_SHOW_FORM);
			rd.forward(request, response);
		}
		chain.doFilter(request, response);

	}

}
