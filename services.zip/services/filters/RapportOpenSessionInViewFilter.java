/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 4183 $
Last Modified: $Date: 2006-05-26 01:06:44 +0530 (Fri, 26 May 2006) $
Last Modified By: $Author: kquinto $
*/

package com.wyse.rapport.services.filters;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.orm.hibernate3.support.OpenSessionInViewFilter;

/** Overrides spring's openSessionInViewFilter to set the hibernate session flush mode. */
public class RapportOpenSessionInViewFilter extends OpenSessionInViewFilter {
    protected Session getSession(SessionFactory sessionFactory) throws DataAccessResourceFailureException {
        Session session = super.getSession(sessionFactory);
        session.setFlushMode(FlushMode.AUTO);
        return session;
    }

    protected void closeSession(Session session, SessionFactory sessionFactory) {
        session.flush();
        super.closeSession(session, sessionFactory);
    }
}
