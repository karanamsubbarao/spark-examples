package com.wyse.rapport.services;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;

import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.persistence.IDeviceRepository;

/**
 *
 */
public class SchedulerJob implements StatefulJob {
	
	public void execute(JobExecutionContext context) throws JobExecutionException {
		IDeviceRepository repository = SpringApplicationContext.repositoryServiceSessionPerThread();
		try {
			JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
			String deviceGuid = jobDataMap.getString("deviceGuid");
			if(deviceGuid!=null){
				DeviceInfo device = repository.findByGuid(deviceGuid);
				device.remindTask(jobDataMap.getString("taskId"));
				repository.update(device);
			}
		} catch (Exception e) {
		}
		finally {
			repository.closeSession();
		}
	}
	
	
}
