/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 4809 $
Last Modified: $Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.server;

import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;

import com.wyse.rapport.db.HypersonicUtil;

public class ShutdownService {
    private SessionFactory sessionFactory;

    public ShutdownService(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void execute() {
        Session session = sessionFactory.openSession();
        new HypersonicUtil().detach(session);
        session.close();
    }
}
