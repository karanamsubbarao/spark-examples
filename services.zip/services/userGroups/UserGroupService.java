package com.wyse.rapport.services.userGroups;

import java.util.List;

import com.wyse.rapport.db.tbl.DeviceUser;
import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.services.persistence.IDeviceUserRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.IUserGroupRepository;
import com.wyse.rapport.services.persistence.IUserRepository;
import com.wyse.rapport.wnom.IWnomConfigurationRepository;
import com.wyse.rapport.wnom.WnomConfiguration;
import com.wyse.rapport.wnom.WnomConstants;

public class UserGroupService implements IUserGroupService {

	private IUserRepository userRepository;
	private ISystemLogService systemLogService;
	private IUserGroupRepository userGroupRepository;
	private IDeviceUserRepository deviceUserRepository;
	private IWnomConfigurationRepository wnomConfigurationRepository;

	public UserGroupService() {
		
	}
	
	public void deleteUserGroup(Long groupId) {
		 UserGroup currentUserGroup = userGroupRepository.findById(groupId);
		 updateUserGroupConfiguration(currentUserGroup);
         userGroupRepository.delete(currentUserGroup);
	}

	private void updateUserGroupConfiguration(UserGroup userGroup) {
		String configurationId = userGroup.getConfiguration().getConfigurationId();
		WnomConfiguration existingConfiguration = 
				wnomConfigurationRepository.findConfigurationById(configurationId);
		if (userGroup.isCustomUserConfiguration()) {
			unAssignExistingConfigurationForUserGroup(userGroup,existingConfiguration);
			wnomConfigurationRepository.delete(existingConfiguration);
		} else if (userGroup.getIsConfigurationPredefined()) {
			unAssignExistingConfigurationForUserGroup(userGroup,existingConfiguration);
			List<UserGroup> groupsForConfiguration = 
					userGroupRepository.findUserGroupsForConfiguration(existingConfiguration);
			if (groupsForConfiguration == null || groupsForConfiguration.isEmpty()) {
				existingConfiguration.setAssignedConfiguration(false);
			}
			wnomConfigurationRepository.update(existingConfiguration);
		}
	}
	
	 private void unAssignExistingConfigurationForUserGroup(UserGroup group,WnomConfiguration existingConfiguration) {
		group.setConfigurationType(WnomConstants.INHERITED);
		group.setConfiguration(wnomConfigurationRepository.getGlobalUserConfiguration());
		userGroupRepository.update(group);
	}
	 
	public void resetDeviceUserPassword(Long userId) {
		DeviceUser user = deviceUserRepository.findUserByUserId(userId);
		user.setPassword("");
		deviceUserRepository.update(user);
	}

	public void moveUsersToGroup(List<DeviceUser> users, UserGroup userGroup) {
		for (DeviceUser user : users) {
			String previousUserGroupName = user.getParentUserGroupName();
			String currentUserGroupName = userGroup.getName();
			user.setParentUserGroupId(userGroup.getGroupId());
			user.setParentUserGroupName(currentUserGroupName);
			if (!user.getParentUserGroupName().equalsIgnoreCase(previousUserGroupName)) {
				systemLogService.info("Device user \"" + user.getDisplayName()
						+ "\" moved from \"" + previousUserGroupName
						+ "\" to \"" + currentUserGroupName + "\" by "
						+ getCurrentAdmin(), null);
			}
			deviceUserRepository.update(user);
		}
	}

	public void deleteUser(Long userId) {
		DeviceUser user = deviceUserRepository.findUserByUserId(userId);
		deviceUserRepository.delete(user);
		systemLogService.info("User \"" + user.getDisplayName()
				+ "\" from group " + user.getParentUserGroupName()
				+ " deleted by " + getCurrentAdmin(), null);
	}

	public void assignConfigurationToUserGroup(UserGroup group,String configurationType, String configurationId) {
		if (WnomConstants.CUSTOM_USER_CONFIGURATION_TYPE.equals(configurationType)) {
			assignCustomConfigurationDetails(group, configurationId);
		} else if (WnomConstants.TEMPLATE.equals(configurationType)) {
			assignPreDefinedTemplateConfigurationDetails(group, configurationId);
		} else if (WnomConstants.INHERITED.equals(configurationType)) {
			assignInheritedConfigurationDetails(group);
		}
	}
	
	private void assignPreDefinedTemplateConfigurationDetails(UserGroup group,String configurationId) {
		if (configurationId == null) {
			assignInheritedConfigurationDetails(group);
			return;
		}
		WnomConfiguration configuration = 
				wnomConfigurationRepository.findConfigurationById(configurationId);
		configuration.setAssignedConfiguration(true);
		group.setConfigurationType(WnomConstants.TEMPLATE);
		group.setConfiguration(configuration);
		updateInheritedChilds(group, configuration);
	}

	private void assignCustomConfigurationDetails(UserGroup group,String configurationId) {
		WnomConfiguration configuration = 
				wnomConfigurationRepository.findConfigurationById(configurationId);
		if (configuration == null) {
			assignInheritedConfigurationDetails(group);
		} else {
			configuration.setAssignedConfiguration(true);
			group.setConfigurationType(WnomConstants.CUSTOM_USER_CONFIGURATION_TYPE);
			group.setConfiguration(configuration);
		}
	}

	private void assignInheritedConfigurationDetails(UserGroup group) {
		WnomConfiguration configuration = 
				userGroupRepository.findParentWnomConfiguration(group);
		if (configuration == null) {
			configuration = wnomConfigurationRepository.getGlobalUserConfiguration();
		}
		configuration.setAssignedConfiguration(true);
		group.setConfigurationType(WnomConstants.INHERITED);
		group.setConfiguration(configuration);
		updateInheritedChilds(group, configuration);
	}

	private void updateInheritedChilds(UserGroup group,WnomConfiguration configuration) {
		List<UserGroup> children = group.getChildren();
		for (UserGroup child : children) {
			if (child.hasInheritedConfiguration()) {
				child.setConfiguration(configuration);
				updateInheritedChilds(child, configuration);
			}
		}
	}

	protected String getCurrentAdmin() {
		return userRepository.getCurrentAdmin();
	}

	public void setDeviceUserRepository(IDeviceUserRepository deviceUserRepository) {
		this.deviceUserRepository = deviceUserRepository;
	}

	public void setSystemLogService(ISystemLogService systemLogService) {
		this.systemLogService = systemLogService;
	}

	public void setUserRepository(IUserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public void setUserGroupRepository(IUserGroupRepository userGroupRepository) {
		this.userGroupRepository = userGroupRepository;
	}

	public void setWnomConfigurationRepository(IWnomConfigurationRepository wnomConfigurationRepository) {
		this.wnomConfigurationRepository = wnomConfigurationRepository;
	}


	

}
