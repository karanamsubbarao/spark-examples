package com.wyse.rapport.services.userGroups;

import java.util.List;

import com.wyse.rapport.db.tbl.DeviceUser;
import com.wyse.rapport.db.tbl.UserGroup;

public interface IUserGroupService {
   
	 void resetDeviceUserPassword(Long userId);
	 
	 void moveUsersToGroup(List<DeviceUser> users, UserGroup userGroup);
	 
	 void deleteUser(Long userId);
	 
	 void assignConfigurationToUserGroup(UserGroup group,String configurationType,String configurationId);
	 
	 void deleteUserGroup(Long groupId);
}
