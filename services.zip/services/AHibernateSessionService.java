/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 7103 $
Last Modified: $Date: 2007-02-17 17:06:32 +0530 (Sat, 17 Feb 2007) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/** Base class for all hibernate session services. */
abstract class AHibernateSessionService implements IHibernateSessionService {
    private static final ThreadLocal<Transaction> transactions = new ThreadLocal<Transaction>();
    private static Logger log = Logger.getLogger(AHibernateSessionService.class);

    protected abstract Session currentSession();

    public void create(Object object) {
        execute(new CreateOperation(object));
    }

    public void createOrUpdate(Object object) {
        execute(new CreateOrUpdateOperation(object));
    }

    public void delete(Object object) {
        execute(new DeleteOperation(object));
    }
    
    public void deleteCollection(Collection collection) {
        execute(new DeleteCollectionOperation(collection));
    }
    
    public void deleteAll(Class cls) {
        execute(new DeleteAllOperation(cls));
    }

    public void deleteWithQuery(String query) {
        execute(new DeleteWithQueryOperation(query));
    }

    public boolean contains(Object object){
    	return currentSession().contains(object);
    }

    private void execute(DatabaseOperation operation) {
        Transaction transaction = beginTransaction();
        try {
            operation.execute(currentSession());
            commitTransaction(transaction);
        } catch (Exception e) {
            log.error("Error executing database operation " + operation.getClass().getSimpleName(), e);
            e.printStackTrace();
            rollbackTransaction(transaction);
            throw new RuntimeException("Error executing database operation " + operation.getClass().getSimpleName(), e);
        }
    }

    private Transaction beginTransaction() {
        if (transactions.get() == null) {
            transactions.set(currentSession().beginTransaction());
        }
        return transactions.get();
    }

    private void commitTransaction(Transaction transaction) {
        transaction.commit();
        transactions.set(null);
    }

    private void rollbackTransaction(Transaction transaction) {
        transaction.rollback();
        transactions.set(null);
    }

    public Query createQuery(String query) {
        return currentSession().createQuery(query);
    }

    public Object find(Class aClass, Serializable id) {
        return currentSession().get(aClass, id);
    }
    
    public Long getCount(Class cls, String[] attributes, Object[] values) {
    	StringBuffer qBuff = new StringBuffer("select count(*) from ");
    	qBuff.append(cls.getName());
    	String query = null; 
    	if(attributes != null && values != null){
    		if(attributes.length != values.length){
    			log.error("Attributes-Values mis-match");
    			return 0l;
    		}
    		query = getQuery(qBuff, attributes, values);
    	}
    	if(query == null){
    		query = qBuff.toString();
    	}
    	return (Long) currentSession().createQuery(query).uniqueResult();
    }

	private String getQuery(StringBuffer qBuff, String[] attributes, Object[] values) {
		if(attributes.length > 0){
			qBuff.append(" where ");
			for (int i=0; i<attributes.length; i++) {
				String attr = attributes[i];
				if(StringUtils.isNotBlank(attr)){
					qBuff.append(attr);
					qBuff.append("='");
					qBuff.append(values[i]);
					qBuff.append("' and ");
				}
			}
			return StringUtils.stripEnd(qBuff.toString().trim(), "and");
		}
		return qBuff.toString();
	}
    

    public void evict(Object obj) {
        currentSession().evict(obj);
    }

    public void flush() {
        currentSession().flush();
    }

    private interface DatabaseOperation {
        void execute(Session session);
    }

    private class CreateOperation implements DatabaseOperation {
        private Object object;

        public CreateOperation(Object object) {
            this.object = object;
        }

        public void execute(Session session) {
            session.save(object);
        }
    }

    private class CreateOrUpdateOperation implements DatabaseOperation {
        private Object object;

        public CreateOrUpdateOperation(Object object) {
            this.object = object;
        }

        public void execute(Session session) {
            session.saveOrUpdate(object);
        }
    }

    private class DeleteOperation implements DatabaseOperation {
        private Object object;

        public DeleteOperation(Object object) {
            this.object = object;
        }

        public void execute(Session session) {
            session.delete(object);
        }
    }

    private class DeleteCollectionOperation implements DatabaseOperation {
        private Collection collection;

        public DeleteCollectionOperation(Collection collection) {
            this.collection = collection;
        }

        public void execute(Session session) {
            for (Object element : collection) {
                session.delete(element);
            }
        }
    }

    private class DeleteAllOperation implements DatabaseOperation {
        private Class cls;

        public DeleteAllOperation(Class cls) {
            this.cls = cls;
        }

        public void execute(Session session) {
        	Criteria criteria = getCriteria(cls);
        	List list = criteria.list();
            for (Object element : list) {
                session.delete(element);
            }
        }
    }

    private class DeleteWithQueryOperation implements DatabaseOperation {
        private String query;

        public DeleteWithQueryOperation(String query) {
            this.query = query;
        }

        public void execute(Session session) {
            createQuery(query).executeUpdate();
        }
    }
    
    public Criteria getCriteria(Class classObj){
        return currentSession().createCriteria(classObj);
    }
}
