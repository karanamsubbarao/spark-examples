package com.wyse.rapport.services.license;

import com.wyse.rapport.db.tbl.WDMLicense;

public interface IWDMLicenseRepository {

	 public void create(WDMLicense license);
	 
	 public void update(WDMLicense license);
	 
	 public void delete(WDMLicense license);
	 
	 public byte[] licenseContents(String productName);
}
