package com.wyse.rapport.services.license;

import java.util.List;

import org.hibernate.Criteria;

import com.wyse.rapport.db.tbl.WDMLicense;
import com.wyse.rapport.services.IHibernateSessionService;

public class WDMLicenseRepository implements IWDMLicenseRepository {

	private IHibernateSessionService sessionService;
    
    public WDMLicenseRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
    }
    
	public void create(WDMLicense license) {
        deleteAllLicense();
		sessionService.create(license);
	}

	public void delete(WDMLicense license) {
		sessionService.delete(license);
	}

	public void update(WDMLicense license) {
		sessionService.createOrUpdate(license);
	}

	public byte[] licenseContents(String name) {
		WDMLicense license = (WDMLicense) sessionService.find(WDMLicense.class, name);
		return license == null ? null :license.getContents();
	}
    
    private List getAllLicense(){
        Criteria criteria = sessionService.getCriteria(WDMLicense.class);
        return criteria.list();
    }

    private void deleteAllLicense(){
        List list = getAllLicense();
        if(list != null){
            for(Object obj:list){
                sessionService.delete(obj);
            }
        }
        list =null;
    }
}
