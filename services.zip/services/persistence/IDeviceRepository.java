/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 3423 $
Last Modified: $Date: 2005-12-22 10:44:21 +0530 (Thu, 22 Dec 2005) $
Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.wyse.rapport.businesslogic.iprange.IPRange;
import com.wyse.rapport.db.tbl.DeviceApplication;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.db.tbl.UserPreferences;

/** Interface for CRUD operations for devices. */
public interface IDeviceRepository {
    DeviceInfo create(DeviceInfo device);

    DeviceInfo createOrUpdate(DeviceInfo device);

    void delete(DeviceInfo device);

    void deleteAll();

    Collection<DeviceInfo> findAll();

    Collection<DeviceInfo> findNewDevices();

    List<DeviceInfo> sortByCriteria(UserPreferences sysSettings, Map<String, Object> data);

    DeviceInfo findByGuid(String deviceGuid);

    DeviceInfo findByMac(String mac);

    DeviceInfo findLegacyDeviceByMac(String macId);

    List<DeviceInfo> devicesByOs(String osName, boolean isLegacy);

    List<DeviceInfo> devicesByOs(String osName);

    DeviceNetworkInfo findDeviceNetworkByDeviceGuid(String deviceGuid);

    Collection<DeviceApplication> findUninstallableApplications(String deviceGuid);

    Map<String, List<String>> findUniqueOsAndModels();

    long getLastLegacyId();

    void closeSession();

    Collection<DeviceInfo> findNewDevicesByOsAndModel(String osName, String model);

    DeviceInfo findByCommandGuid(String commandGuid);

    int findDevicesInRange(IPRange range);

    Collection<DeviceInfo> findDevicesInGroup(UserPreferences userPreferences, String deviceGroupPath, Map<String, Object> dataMap);

    List<DeviceInfo> findSortedDevicesInGroup(String deviceGroupPath);
    
    List<DeviceInfo> findDevicesInGroup(String deviceGroupPath);

    Long findDeviceCountInGroup(String deviceGroupPath);

    Map<String, String> findGuidsAndIps(String deviceGroupPath);

    List<DeviceInfo> findNonAuthenticatedDevices();
    
    Map<String, Object> sortByCriteriaBasedOnOsOrModel(UserPreferences preferences, Map<String, Object> dataMap);

	DeviceInfo findWtosDeviceToImage(String ipAddress);
	
	boolean isLicenseLimitExceeded();
	
	boolean isExistingDevice(DeviceInfo device);
	
	DeviceInfo update(DeviceInfo device);
	
	String getOsVersion(String deviceGuid);
	
	String getImageVersion(String deviceGuid);
}
