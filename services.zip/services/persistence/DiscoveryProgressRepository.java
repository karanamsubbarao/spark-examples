/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.persistence;

import java.util.List;

import org.hibernate.Query;

import com.wyse.rapport.businesslogic.iprange.IPRange;
import com.wyse.rapport.businesslogic.iprange.IPRanges;
import com.wyse.rapport.db.tbl.DiscoveryProgress;
import com.wyse.rapport.db.tbl.Subnet;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.util.IPAddressUtil;

public class DiscoveryProgressRepository implements IDiscoveryProgressRepository {
    private IHibernateSessionService sessionService;
    private IDiscoveryRangesRepository rangesRepository;

    public DiscoveryProgressRepository(IHibernateSessionService sessionService, IDiscoveryRangesRepository rangesRepository) {
        this.sessionService = sessionService;
        this.rangesRepository = rangesRepository;
    }

    public void discovered(String ipAddress) {
        assert ipAddress != null : "NULL ipAddress passed";
        if (rangesRepository.shouldTrack(ipAddress) && findByNetwork(ipAddress) == null) {
            create(new DiscoveryProgress(ipAddress));
        }
    }

    public int deviceCount(IPRange range) {
        return addressList(range).size();
    }

    public int deviceCount(Subnet subnets) {
        return deviceCount(subnets.getIpRange());
    }

    public void trackRanges(IPRanges ranges) {
        deleteAll();
        rangesRepository.deleteAll();
        rangesRepository.create(ranges);
    }

    DiscoveryProgress findById(String ip) {
        return (DiscoveryProgress) sessionService.find(DiscoveryProgress.class, ip);
    }

    public void create(DiscoveryProgress dp) {
        sessionService.createOrUpdate(dp);
    }

    public void deleteAll() {
        sessionService.deleteCollection(findAll());
        //Why doesn't this work???
        //sessionService.deleteWithQuery("delete from DiscoveryProgress");
    }

    private List findAll() {
        return sessionService.createQuery("from DiscoveryProgress c").list();
    }

    private DiscoveryProgress findByNetwork(String ip) {
        Query q = sessionService.createQuery("from DiscoveryProgress dp where dp.ip = :ipAddress");
        q.setString("ipAddress", ip);
        List ipValue = q.list();
        if (ipValue.size() == 0) {
            return null;
        }
        return (DiscoveryProgress) ipValue.get(0);
    }

    private List<String> addressList(IPRange range) {
        Query q = sessionService.createQuery("select dp.ip from DiscoveryProgress dp where dp.longValue >= :startIP and dp.longValue <= :endIP");
        q.setLong("startIP", IPAddressUtil.toLong(range.getStartIP()));
        q.setLong("endIP", IPAddressUtil.toLong(range.getEndIP()));
        return q.list();
    }
}
