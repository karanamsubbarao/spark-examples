package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.List;

import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.wnom.WnomConfiguration;

public interface IUserGroupRepository {

	void create(UserGroup group);
	
	void update(UserGroup group);
	
	UserGroup findById(Long groupId);
	
	UserGroup findRoot();
	
	List<UserGroup> findAll();

	void delete(Long groupId);
	
	void delete(UserGroup group);
	
	void delete(Collection<Long> groupIds);
	
	void deleteAll();

	UserGroup findUserGroupByName(String parentUserGroupName);

    List<UserGroup> findUserGroupsForConfiguration(WnomConfiguration configuration);
    
    WnomConfiguration findParentWnomConfiguration(UserGroup group);

	UserGroup findParent(UserGroup userGroup);
}
