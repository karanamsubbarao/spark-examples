/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev: 7406 $$
Last Modified: $$Date: 2007-05-21 12:30:42 +0530 (Mon, 21 May 2007) $$
Last Modified By: $$Author: gkanagaraj $$
 */
package com.wyse.rapport.services.persistence;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.wyse.common.SystemLogConstant;
import com.wyse.rapport.adminclient.organization.UserGroupController;
import com.wyse.rapport.db.tbl.DeviceUser;
import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.util.WDMConstants;
import com.wyse.rapport.util.WyseNumberUtils;

public class DeviceUserRepository implements IDeviceUserRepository {

    private IHibernateSessionService sessionService;
    private IUserRepository userRepository;
    private static Logger log = Logger.getLogger(DeviceUserRepository.class);

    public DeviceUserRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
        this.userRepository = new UserRepository(sessionService);
    }

    public void create(DeviceUser user) {
        user.setCreatedOn(new Date());
        user.setCreatedBy(userRepository.getCurrentAdmin());
        user.setUserNameInDb(user.getUserName().toLowerCase());
        sessionService.create(user);
    }

    public void update(DeviceUser user) {
    	if(user.getUserId() == null){
        	user.setCreatedOn(new Date());
            user.setCreatedBy(userRepository.getCurrentAdmin());
        }else{
            user.setLastModifiedBy(userRepository.getCurrentAdmin());
            user.setLastModifiedOn(new Date());
        }
    	user.setUserNameInDb(user.getUserName().toLowerCase());
        sessionService.createOrUpdate(user);
    }

    public void deleteAll() {
        sessionService.deleteAll(DeviceUser.class);
    }

    public List<DeviceUser> findAll() {
        Criteria criteria=sessionService.getCriteria(DeviceUser.class);
        criteria.addOrder(Order.asc("firstName").ignoreCase());
        criteria.addOrder(Order.asc("lastName").ignoreCase());
        return (ArrayList<DeviceUser>)criteria.list();
    }
    
    public List<DeviceUser> findUsersInGroup(Long userGroupID) {
        Criteria criteria=sessionService.getCriteria(DeviceUser.class);
        criteria.add(Expression.eq("parentUserGroupId", userGroupID));
        criteria.addOrder(Order.asc("firstName").ignoreCase());
        criteria.addOrder(Order.asc("lastName").ignoreCase());
        return (ArrayList<DeviceUser>)criteria.list();
    }
    

    public void delete(DeviceUser user) {
        sessionService.delete(user);
    }

    public String getUserGroupName(DeviceUser user){
        Long parentGroupId = user.getParentUserGroupId();
        Criteria criteria=sessionService.getCriteria(UserGroup.class);
        criteria.add(Expression.eq("groupId",parentGroupId));
        return criteria.list().isEmpty() ? null : ((UserGroup) criteria.list().iterator().next()).getName();
    }

    public DeviceUser findUser(String name) {
        Criteria criteria=sessionService.getCriteria(DeviceUser.class);
        criteria.add(Restrictions.eq("userNameInDb", name.toLowerCase()));
        return criteria.list().isEmpty() ? null : (DeviceUser) criteria.list().iterator().next();
    }
    
    public boolean isDuplicateUserExists(String userId, String userName) {
		Criteria criteria = sessionService.getCriteria(DeviceUser.class);
		criteria.add(Restrictions.eq("userNameInDb", userName.toLowerCase()));
		if(NumberUtils.isDigits(userId)){
			criteria.add(Restrictions.ne("userId", Long.parseLong(userId)));
		}
		return !(criteria.list().isEmpty());
	}

    public List<DeviceUser> findUsersInGroup(Map<String, Object> dataMap) {
        return fetchRecord(dataMap);
    }

    public DeviceUser findUserByUserId(Long userId){
        Criteria criteria=sessionService.getCriteria(DeviceUser.class);
        criteria.add(Expression.eq("userId",userId));
        return criteria.list().isEmpty() ? null : (DeviceUser) criteria.list().iterator().next();
    }

    public List<DeviceUser> findAllExcludingGivenUserName(Long userId) {
        Criteria criteria=sessionService.getCriteria(DeviceUser.class);
        criteria.add(Restrictions.ne("userId",userId));
        return (ArrayList<DeviceUser>)criteria.list();
    }

    public long findUsersCountInGroup(UserGroup group) {
        Query query=sessionService.createQuery("select count(*) from DeviceUser where parentUserGroupId='"+group.getGroupId()+"'");
        Long uniqueResult = (Long) query.uniqueResult();
        return uniqueResult;
    }
    
    public List<DeviceUser> fetchRecord(Map<String, Object> dataMap) {
        int startRow = (Integer)dataMap.get(SystemLogConstant.START_ROW);
        int endRow = (Integer)dataMap.get(SystemLogConstant.END_ROW);  
        int pageNumber =(Integer)dataMap.get(SystemLogConstant.PAGE_NUMBER);
        List<DeviceUser> databaseList = new ArrayList<DeviceUser>();
        int totalRecords = getRowCountGroupDeviceUsers(dataMap); 
        int rangeFactor=(Integer)dataMap.get(WDMConstants.RANGE_FACTOR);
        Integer totalPages = new Integer(WyseNumberUtils.getPageNumber(totalRecords,rangeFactor));
        dataMap.put(SystemLogConstant.TOTAL_NO_OF_PAGES,totalPages); 
        if(pageNumber>totalPages){
            pageNumber=totalPages;
            startRow=((totalPages-1)*rangeFactor)+1;
        }
        dataMap.put(SystemLogConstant.PAGE_NUMBER,pageNumber);
        if(endRow > totalRecords){
            endRow = totalRecords;
        }        
        if(startRow > totalRecords){
            startRow = 1;
        }

        dataMap.put(SystemLogConstant.END_ROW,endRow);
        dataMap.put(SystemLogConstant.START_ROW,startRow);
        dataMap.put(SystemLogConstant.TOTAL_RECORDS,new Long(totalRecords));

        databaseList=findAllDeviceUser(dataMap);

        if (databaseList.isEmpty()) {
            databaseList=Collections.emptyList();
        } 



        return databaseList;
    }

    int getRowCountGroupDeviceUsers(Map<String, Object> dataMap) { 
        String currentUserGroupId = (String)dataMap.get(UserGroupController.CURRENT_USER_GROUP_ID);
        Long rootUserGroupId = (Long)dataMap.get("rootUserGroupId");
        Object unAssignUserGroupId = dataMap.get("unAssignUserGroupId");
        Criteria criteria=sessionService.getCriteria(DeviceUser.class);
        if(currentUserGroupId.equals( rootUserGroupId.toString())){  

        }else if(unAssignUserGroupId !=null){
            criteria.add(Expression.eq("parentUserGroupId",(Long)unAssignUserGroupId));
        }else{
            criteria.add(Expression.eq("parentUserGroupId",Long.parseLong(currentUserGroupId)));
        }
        criteria.setProjection(Projections.rowCount());          
        return displayObjectList(criteria.list());
    }

    public static int displayObjectList(List list)
    {
        int results=0;
        Iterator iter = list.iterator();
        if (!iter.hasNext())
        {
            log.info("No objects to display.");
            return results;
        }
        while (iter.hasNext()){
            Integer obj = (Integer)iter.next();
            results= obj;
            break;
        }
        return results;
    }

    private List<DeviceUser> findAllDeviceUser(Map<String, Object> dataMap) { 
        String currentUserGroupId = (String)dataMap.get(UserGroupController.CURRENT_USER_GROUP_ID);
        Long rootUserGroupId = (Long)dataMap.get("rootUserGroupId");
        Object unAssignUserGroupId = dataMap.get("unAssignUserGroupId");
        int startRow = (Integer)dataMap.get(SystemLogConstant.START_ROW);
        int rangeFactor=(Integer)dataMap.get(WDMConstants.RANGE_FACTOR);
        Criteria criteria=sessionService.getCriteria(DeviceUser.class);
        criteria.addOrder(Order.asc("firstName").ignoreCase());
        criteria.addOrder(Order.asc("lastName").ignoreCase());
        if(currentUserGroupId.equals( rootUserGroupId.toString())){  

        }else if(unAssignUserGroupId !=null){
            criteria.add(Expression.eq("parentUserGroupId",(Long)unAssignUserGroupId));
        }else{
            criteria.add(Expression.eq("parentUserGroupId",Long.parseLong(currentUserGroupId)));
        }
        criteria.setFirstResult(startRow-1);
        criteria.setMaxResults(rangeFactor); 
        return (ArrayList<DeviceUser>)criteria.list();
    }
	
}
