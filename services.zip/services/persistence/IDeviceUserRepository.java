/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev: 7406 $$
Last Modified: $$Date: 2007-05-21 12:30:42 +0530 (Mon, 21 May 2007) $$
Last Modified By: $$Author: gkanagaraj $$
*/

package com.wyse.rapport.services.persistence;

import java.util.List;
import java.util.Map;

import com.wyse.rapport.db.tbl.DeviceUser;
import com.wyse.rapport.db.tbl.UserGroup;

public interface IDeviceUserRepository {
	
    void create(DeviceUser user);
	
	void update(DeviceUser user);
	
	List<DeviceUser> findAll();

	void delete(DeviceUser user);
	
	void deleteAll();
	
	String getUserGroupName(DeviceUser user);

	DeviceUser findUser(String userName);

	DeviceUser findUserByUserId(Long userId);

	List<DeviceUser> findAllExcludingGivenUserName(Long userId);
	
	List<DeviceUser> findUsersInGroup(Map<String, Object> dataMap);

	long findUsersCountInGroup(UserGroup group);
	
	List<DeviceUser> findUsersInGroup(Long userGroupID);

	boolean isDuplicateUserExists(String userId, String userName);
	
}
