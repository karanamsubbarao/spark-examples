/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev: 5067 $$
Last Modified: $$Date: 2006-08-29 14:35:24 +0530 (Tue, 29 Aug 2006) $$
Last Modified By: $$Author: smariswamy $$
*/

package com.wyse.rapport.services.persistence;

import com.wyse.rapport.db.tbl.User;

/**
 *
 */
public interface IUserRepository {
	
    User getAdministrator();

    User findUser(String userName);

	String getCurrentAdmin();
}
