/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 3119 $
 Last Modified: $Date: 2005-12-09 19:21:58 +0530 (Fri, 09 Dec 2005) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.List;

import com.wyse.rapport.businesslogic.iprange.IPRange;

/** @author smariswamy */
public interface IIPRangeRepository {
    public boolean create(IPRange iprange);

    public boolean update(IPRange ipRange);

    public void delete(IPRange iprange);

    public void deleteAll();

    public IPRange findById(long iprangeID);

    public List<IPRange> findAll();

    public boolean exists(IPRange range);

    public IPRange existingRange(String startIP, String endIP);

    public void deleteAll(Collection<Long> ids);
}