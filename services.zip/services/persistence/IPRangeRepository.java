/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;

import com.wyse.rapport.businesslogic.iprange.IPRange;
import com.wyse.rapport.services.IHibernateSessionService;

/** @author brichter */
public class IPRangeRepository implements IIPRangeRepository {
    private Logger log = Logger.getLogger(IPRangeRepository.class);
    private IHibernateSessionService sessionService;

    public IPRangeRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
    }

    public boolean create(IPRange iprange) {
        assert iprange != null : "null iprange in addIPRange";
        if (ipRangeExists(iprange)) {
            log.info("IPRange (" + iprange + ") already exists");
            return false;
        }
        sessionService.create(iprange);
        return true;
    }

    public boolean update(IPRange ipRange) {
        if (ipRangeExists(ipRange)) {
            log.info("IPRange (" + ipRange + ") already exists");
            return false;
        }
        sessionService.createOrUpdate(ipRange);
        return true;
    }

    public void delete(IPRange iprange) {
        assert iprange != null : "null iprange in deleteIPRange";
        sessionService.delete(iprange);
        log.info("Successfully deleted IPRange");
    }

    public void deleteAll() {
        sessionService.deleteWithQuery("delete from IPRange");
    }

    public void deleteAll(Collection<Long> ids) {
        String query = "delete from IPRange where ipRangeId in (" + getIds(ids) + ")";
        sessionService.deleteWithQuery(query);
    }

    private String getIds(Collection<Long> ids) {
        String idsStr = "";
        for (Long id : ids) {
            idsStr += id + ",";
        }
        return StringUtils.chomp(idsStr, ",");
    }

    public IPRange findById(long iprangeID) {
        IPRange iprange = (IPRange) sessionService.find(IPRange.class, iprangeID);
        if (iprange != null) {
            log.info("Retrieved IPRange with ID: " + iprangeID);
        } else {
            log.info("No IPRange with ID : " + iprangeID + " found");
        }
        return iprange;
    }

    public List<IPRange> findAll() {
        String query = "from IPRange iprange";
        Query q = sessionService.createQuery(query);
        return q.list();
    }

    public boolean exists(IPRange ipRange) {
        IPRange existingRange = existingRange(ipRange.getStartIP(), ipRange.getEndIP());
        if (existingRange != null && isNotEqual(existingRange.getIPRangeId(), ipRange.getIPRangeId())) {
            return true;
        }
        return false;
    }

    public IPRange existingRange(String startIP, String endIP) {
        List<IPRange> ranges = existingRanges(startIP, endIP);
        return ranges.isEmpty() ? null : ranges.get(0);
    }

    private List<IPRange> existingRanges(String startIP, String endIP) {
        String query = "from IPRange ipRange where ipRange.startIP=:start and ipRange.endIP=:end";
        Query q = sessionService.createQuery(query).setString("start", startIP).setString("end", endIP);
        return q.list();
    }

    private boolean isNotEqual(long rangeId, long id) {
        return rangeId != id;
    }

    private boolean ipRangeExists(IPRange ip) {
        List<IPRange> ipRanges = findAll();
        for (IPRange ipRange : ipRanges) {
            if (ip.getStartIP().equals(ipRange.getStartIP()) && ip.getEndIP().equals(ipRange.getEndIP())) {
                return true;
            }
        }
        return false;
    }
}

