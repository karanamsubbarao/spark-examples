/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 3600 $
 Last Modified: $Date: 2005-12-29 11:17:16 +0530 (Thu, 29 Dec 2005) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.persistence;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;

import com.wyse.common.SystemLogConstant;
import com.wyse.common.UUIDGenerator;
import com.wyse.rapport.adminclient.guidedactions.AGuidedActionController;
import com.wyse.rapport.adminclient.organization.OrganizationController;
import com.wyse.rapport.businesslogic.comparator.EGASortCriteria;
import com.wyse.rapport.businesslogic.comparator.ESortCriteria;
import com.wyse.rapport.businesslogic.comparator.HostNameComparator;
import com.wyse.rapport.businesslogic.iprange.IPRange;
import com.wyse.rapport.db.tbl.DeviceApplication;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.util.MacAddress;
import com.wyse.rapport.util.WyseNumberUtils;
import com.wyse.rapport.util.OSTypes;
import com.wyse.rapport.util.WDMConstants;
import com.wyse.rapport.util.WDMUtil;

public class DeviceRepository implements IDeviceRepository {

	private static Logger log = Logger.getLogger(DeviceRepository.class);
	private IHibernateSessionService sessionService;

	public DeviceRepository(IHibernateSessionService sessionService) {
		this.sessionService = sessionService;
	}

	public DeviceInfo create(DeviceInfo device) {
		assert device != null : "null device passed to addDevice";
		setGuid(device);
		device.setDisplayStatus(DeviceDisplayStatus.ACTIVE);
		if(!isLicenseLimitExceeded()){
			sessionService.create(device);
		}else{
			log.info("License Limit of Max number of devices " + RapportServer.licenseLimit() + " exceeded" );	
		}
		return device;
	}

	public DeviceInfo createOrUpdate(DeviceInfo device) {
		assert device != null : "null item in saveOrUpdate";
		setGuid(device);
		if(StringUtils.isBlank(device.getDeviceGuid())){
			if(isLicenseLimitExceeded()){
				log.info("License Limit of Max number of devices " + RapportServer.licenseLimit() + " exceeded" );
				return device;
			}
		}else{
			if(isExistingDevice(device)){
				sessionService.createOrUpdate(device);
			}else{
				if(isLicenseLimitExceeded()){
					log.info("License Limit of Max number of devices " + RapportServer.licenseLimit() + " exceeded" );
				}else{
					sessionService.createOrUpdate(device);
				}
			}
		}

		return device;
	}

	public DeviceInfo update(DeviceInfo device) {
		assert device != null : "null item in update";
		setGuid(device);
		sessionService.createOrUpdate(device);
		return device;
	}

	public boolean isExistingDevice(DeviceInfo device) {
		if(sessionService.contains(device)){
			sessionService.evict(device);
		}
		if(getTotalDeviceCountWithMac(device.getActiveMac()) > 0){
			return true; 
		}
		if(StringUtils.isNotBlank(device.getDeviceGuid()) && findByGuid(device.getDeviceGuid()) != null){
			return true;
		}
		return false;
	}

	public long getLastLegacyId() {
		Query query = sessionService.createQuery("Select max(d.legacyId) from DeviceInfo d where d.legacy=:legacy");
		query.setBoolean("legacy", true);
		Object legacyId = query.uniqueResult();
		return (legacyId != null) ? (Long) legacyId : 0;
	}

	public void delete(DeviceInfo device) {
		assert device != null : "null device passed to deleteDevice";
		sessionService.delete(device);
		log.info("Successfully deleted the Device");
	}

	public void deleteAll() {
		sessionService.deleteCollection(findAll());
	}

	public Collection<DeviceInfo> findAll() {
		return sessionService.createQuery("from DeviceInfo c").list();
	}

	//used in GA controller
	public Map<String, Object> sortByCriteriaBasedOnOsOrModel(UserPreferences preferences, Map<String, Object> dataMap) {
		int startRow = (Integer)dataMap.get(SystemLogConstant.START_ROW);
		int endRow = (Integer)dataMap.get(SystemLogConstant.END_ROW);  
		List<DeviceInfo> databaseList = new ArrayList<DeviceInfo>();
		int totalFilteredRecords = getRowCount(dataMap); 
		int rangeFactor=(Integer)dataMap.get(WDMConstants.RANGE_FACTOR);

		if(endRow > totalFilteredRecords){
			endRow = totalFilteredRecords;
		}        
		if(startRow > totalFilteredRecords){
			startRow = 1;
		}

		dataMap.put(SystemLogConstant.END_ROW,endRow);
		dataMap.put(SystemLogConstant.START_ROW,startRow);
		dataMap.put(SystemLogConstant.TOTAL_RECORDS,new Integer(totalFilteredRecords));

		databaseList=findDevices(dataMap);

		if (databaseList.isEmpty()) {
			databaseList=Collections.emptyList();
		} 
		dataMap.put(AGuidedActionController.DEVICE_LIST, databaseList);
		dataMap.put(SystemLogConstant.TOTAL_NO_OF_PAGES,new Integer(WyseNumberUtils.getPageNumber(totalFilteredRecords,rangeFactor)));      
		return dataMap;
	}

	int getRowCount(Map<String, Object> dataMap) {
		boolean isLegacy=(Boolean)dataMap.get(WDMConstants.IS_LEGACY);
		
		Criteria criteria = sessionService.getCriteria(DeviceInfo.class);
		if(!isLegacy){
			criteria.add(Expression.ne("legacy", true));
		}
		addFilterCriterias(dataMap, criteria);
		criteria.setProjection(Projections.rowCount());          
		return displayObjectList(criteria.list());
	}

	private List<DeviceInfo> findDevices(Map<String, Object> dataMap) {
		boolean isLegacy=(Boolean)dataMap.get(WDMConstants.IS_LEGACY);
		int startRow = (Integer)dataMap.get(SystemLogConstant.START_ROW);
		int rangeFactor=(Integer)dataMap.get(WDMConstants.RANGE_FACTOR);
		EGASortCriteria sortCriteria=(EGASortCriteria)dataMap.get(WDMUtil.GA_SORT_CRITERIA);
		String sortOrder=(String)dataMap.get(WDMUtil.GA_SORT_ORDER);        
		Criteria criteria=sessionService.getCriteria(DeviceInfo.class);
		criteria.setFirstResult(startRow-1);
		criteria.setMaxResults(rangeFactor);
		if(!isLegacy){
			criteria.add(Expression.ne("legacy", true));
		}
		addFilterCriterias(dataMap, criteria);
		sortCriteria.sort(criteria,sortOrder);
		return (ArrayList<DeviceInfo>)criteria.list();
	}

	private void addFilterCriterias(Map<String, Object> dataMap, Criteria criteria) {
		String osName = (String)dataMap.get(WDMConstants.OSNAME);
		String model = (String)dataMap.get(WDMConstants.MODEL);

		Conjunction conjunction=Expression.conjunction();
		if(osName!=null){
			osName=OSTypes.osNameMapped(osName);
			conjunction.add(Expression.ilike(WDMConstants.OSNAME, osName,MatchMode.ANYWHERE));
		}
		if(model!=null){
			conjunction.add(Expression.eq(WDMConstants.MODEL, model));
		}
		criteria.add(conjunction);
	}
	
	public List<DeviceInfo> sortByCriteria(UserPreferences preferences, Map<String, Object> dataMap) {
		return (List<DeviceInfo>) sortedDevices(preferences, null, dataMap);
	}
	
	public Collection<DeviceInfo> findDevicesInGroup(UserPreferences preferences, String deviceGroupPath, Map<String, Object> dataMap) {
		dataMap.put(WDMUtil.SORT_CRITERIA, dataMap.get(OrganizationController.DEVICE_SORT_CRITERIA));
		dataMap.put(WDMUtil.SORT_ORDER, dataMap.get(OrganizationController.DEVICE_SORT_ORDER));
		return sortedDevices(preferences, deviceGroupPath, dataMap);
	}

	public List<DeviceInfo> findSortedDevicesInGroup(String deviceGroupPath) {
		List devices = findDevicesInGroup(deviceGroupPath);
		Collections.sort(devices, new HostNameComparator());
		return devices; 
	}

	public List<DeviceInfo> findDevicesInGroup(String deviceGroupPath) {
		Criteria criteria = sessionService.getCriteria(DeviceInfo.class);
		if(StringUtils.isNotBlank(deviceGroupPath)){
			criteria.add(Expression.eq("deviceGroupPath", deviceGroupPath));
		}
		return criteria.list();
	}

	private Collection<DeviceInfo> sortedDevices(UserPreferences preferences, String deviceGroupPath, Map<String, Object> dataMap) {
		ESortCriteria sortCriteria = (ESortCriteria) dataMap.get(WDMUtil.SORT_CRITERIA);
		if(sortCriteria == null){
			dataMap.put(WDMUtil.SORT_CRITERIA,ESortCriteria.HOSTNAME);
		}
		dataMap.put(WDMUtil.DEVICE_GROUP_PATH,deviceGroupPath);
		return fetchRecord(preferences,dataMap);
	}

	public DeviceInfo findByGuid(String deviceGuid) {
		if(StringUtils.isBlank(deviceGuid)){
			log.info("null or blank deviceGuid passed into findByGuid");
			return null;
		}
		return (DeviceInfo) sessionService.find(DeviceInfo.class, deviceGuid);
	}

	public DeviceInfo findByMac(String mac) {
		if(StringUtils.isBlank(mac))return null;
		String query = "select d from DeviceInfo d join d.networks dn where dn.macAddress = :mac";
		Object device = sessionService.createQuery(query)
		.setString("mac", MacAddress.format(mac))
		.uniqueResult();
		return (device != null) ? (DeviceInfo) device : null;
	}

	public DeviceInfo findLegacyDeviceByMac(String mac) {
		if(StringUtils.isBlank(mac))return null;
		String query = "select d from DeviceInfo d join d.networks dn where dn.macAddress = :mac and d.legacy=:legacy";
		Object device = sessionService.createQuery(query)
		.setString("mac", MacAddress.format(mac))
		.setBoolean("legacy", true)
		.uniqueResult();
		return (device != null) ? (DeviceInfo) device : null;
	}

	public DeviceNetworkInfo findDeviceNetworkByDeviceGuid(String deviceGuid) {
		DeviceInfo device = findByGuid(deviceGuid);
		return device == null ? null : device.getActiveNetwork();
	}

	public void closeSession() {
		sessionService.closeSession();
	}

	public List<DeviceInfo> devicesByOs(String osName, boolean isLegacy) {

		String query = "from DeviceInfo d where d.osName like '%" + OSTypes.osNameMapped(osName) + "%' and d.legacy=:legacy";
		return sessionService.createQuery(query)
		.setBoolean("legacy", isLegacy)
		.list();
	}

	public List<DeviceInfo> devicesByOs(String osName) {
		String query = "from DeviceInfo d where d.osName like '%" + OSTypes.osNameMapped(osName) + "%'";
		return sessionService.createQuery(query)
		.list();
	}

	public List<DeviceInfo> findNewDevices() {
		String query = "from DeviceInfo d where d.legacy=:legacy";
		return sessionService.createQuery(query)
		.setBoolean("legacy", false)
		.list();
	}

	public Collection<DeviceApplication> findUninstallableApplications(String deviceGuid) {
		String query = "select apps from DeviceInfo d join d.applications apps where d.deviceGuid =:deviceGuid and apps.canUninstall='true'";
		Query q = sessionService.createQuery(query);
		q.setString("deviceGuid", deviceGuid);
		return q.list();
	}

	private DeviceInfo setGuid(DeviceInfo device) {
		if (device.getDeviceGuid() == null || device.getDeviceGuid().equals("")) {
			device.setDeviceGuid(new UUIDGenerator().generate());
		}
		return device;
	}

	public Map<String, List<String>> findUniqueOsAndModels() {
		String query = "select distinct d.osName, d.model from DeviceInfo d where d.legacy='false' and d.isManualDevice='false'";
		Query q = sessionService.createQuery(query);
		List<Object[]> results = q.list();
		Map<String, List<String>> osModels = new HashMap<String, List<String>>();
		for (Object[] row : results) {
			if (!osModels.containsKey(row[0])) {
				osModels.put(row[0].toString(), new ArrayList<String>());
			}
			osModels.get(row[0]).add(row[1] == null ? "UnknownModel" : row[1].toString());
		}
		return osModels;
	}

	public Collection<DeviceInfo> findNewDevicesByOsAndModel(String osName, String model) {
		String query = "from DeviceInfo d where d.osName = :osName and d.model = :model  and d.legacy=:legacy";
		return sessionService.createQuery(query)
		.setString(WDMConstants.OSNAME, osName)
		.setString(WDMConstants.MODEL, model)
		.setBoolean("legacy", false)
		.list();
	}

	public DeviceInfo findByCommandGuid(String commandGuid) {
		String taskId = getTaskId(commandGuid);
		return (taskId == null) ? null : deviceFromTaskId(taskId);
	}

	public DeviceInfo deviceFromTaskId(String taskId) {
		String query = "select d from DeviceInfo d join d.tasks t where t.taskId = :taskId";
		return (DeviceInfo) sessionService.createQuery(query).setString("taskId", taskId).uniqueResult();
	}

	public String getTaskId(String commandGuid) {
		String query = "select d from Task d join d.commands t where t.commandGuid = :commandGuid";
		Task task = (Task) sessionService.createQuery(query).setString("commandGuid", commandGuid).uniqueResult();
		return (task != null) ? task.getTaskId() : null;
	}

	public int findDevicesInRange(IPRange range) {
		int deviceCount = 0;
		List<IPRange> splittedRange = IPRange.split(range);
		for (IPRange ipRange : splittedRange) {
			deviceCount += devicesInRange(ipRange).size();
		}
		return deviceCount;
	}

	List<String> devicesInRange(IPRange ipRange) {
		String startIp = ipRange.getStartIP();
		String ipAddress = startIp.substring(0, startIp.lastIndexOf(".") + 1);
		String query = "select dn.ipAddress from DeviceNetworkInfo dn where dn.ipAddress like '" + ipAddress + "%'";
		List<String> deviceIps = (List<String>) sessionService.createQuery(query).list();
		List<String> devicesInRange = new ArrayList<String>();
		for (String ip : deviceIps) {
			if (IPRange.inRange(ipRange, ip)) {
				devicesInRange.add(ip);
			}
		}
		return devicesInRange;
	}

	public Long findDeviceCountInGroup(String deviceGroupPath) {
		return sessionService.getCount(DeviceInfo.class, new String[]{"deviceGroupPath"}, new Object[]{deviceGroupPath});
	}

	public Map<String, String> findGuidsAndIps(String deviceGroupPath){
		Map<String,String> devices=new HashMap<String, String>();
		Criteria criteria = sessionService.getCriteria(DeviceInfo.class);
		if(deviceGroupPath!=null){
			criteria.add(Expression.eq("deviceGroupPath", deviceGroupPath));
		}
		criteria.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List retrievedDevices = criteria.list();

		Iterator iter = retrievedDevices.iterator();
		while ( iter.hasNext() ) {
			Map map = (Map) iter.next();
			DeviceInfo device = (DeviceInfo) map.get(Criteria.ROOT_ALIAS);
			devices.put(device.getDeviceGuid(),device.getActiveIp());
		}
		return devices;
	}


	public static int displayObjectList(List list)
	{
		int results=0;
		Iterator iter = list.iterator();
		if (!iter.hasNext())
		{
			log.info("No objects to display.");
			return results;
		}
		while (iter.hasNext()){
			Integer obj = (Integer)iter.next();
			results= obj;
			break;
		}
		return results;
	}

	public List<DeviceInfo> fetchRecord(UserPreferences preferences, Map<String, Object> dataMap) {
		int startRow = (Integer)dataMap.get(SystemLogConstant.START_ROW);
		int endRow = (Integer)dataMap.get(SystemLogConstant.END_ROW);  
		List<DeviceInfo> databaseList = new ArrayList<DeviceInfo>();
		int totalFilteredRecords = getRowCountGroupDevices(dataMap); 
		int totalRecords = getRowCountAllDevices(dataMap); 
		int totalRecordsInGroup = getRowCountGroupDevices(dataMap);//Fix for #721
		int rangeFactor=(Integer)dataMap.get(WDMConstants.RANGE_FACTOR);

		if(endRow > totalFilteredRecords){
			endRow = totalFilteredRecords;
		}        
		if(startRow > totalFilteredRecords){
			startRow = 1;
		}

		dataMap.put(SystemLogConstant.END_ROW,endRow);
		dataMap.put(SystemLogConstant.START_ROW,startRow);
		dataMap.put(SystemLogConstant.TOTAL_RECORDS,new Long(totalRecords));
		dataMap.put(SystemLogConstant.TOTAL_RECORDS_IN_GROUP,new Long(totalRecordsInGroup));//Fix for #721

		databaseList=findAllDevice(dataMap);

		if (databaseList.isEmpty()) {
			databaseList=Collections.emptyList();
		} 
		dataMap.put(AGuidedActionController.DEVICE_LIST, databaseList);
		dataMap.put(SystemLogConstant.TOTAL_NO_OF_PAGES,new Integer(WyseNumberUtils.getPageNumber(totalFilteredRecords,rangeFactor)));         
		return databaseList;
	}

	private List<DeviceInfo> findAllDevice(Map<String, Object> dataMap) { 

		String deviceGroupPath = (String)dataMap.get(WDMUtil.DEVICE_GROUP_PATH);
		int startRow = (Integer)dataMap.get(SystemLogConstant.START_ROW);
		int rangeFactor=(Integer)dataMap.get(WDMConstants.RANGE_FACTOR);
		ESortCriteria sortCriteria=(ESortCriteria)dataMap.get(WDMUtil.SORT_CRITERIA);
		String sortOrder=(String)dataMap.get(WDMUtil.SORT_ORDER);        
		Criteria criteria=sessionService.getCriteria(DeviceInfo.class);
		if(deviceGroupPath.indexOf('/') != -1){
			criteria.add(Expression.eq(WDMUtil.DEVICE_GROUP_PATH, deviceGroupPath));
		}
		criteria.setFirstResult(startRow-1);
		criteria.setMaxResults(rangeFactor);  
		sortCriteria.sort(criteria,sortOrder);
		return (ArrayList<DeviceInfo>)criteria.list();
	}

	int getRowCountGroupDevices(Map<String, Object> dataMap) {
		String deviceGroupPath = (String)dataMap.get(WDMUtil.DEVICE_GROUP_PATH);
		Criteria criteriaRowCount=sessionService.getCriteria(DeviceInfo.class);
		if(deviceGroupPath.indexOf('/') != -1){
			criteriaRowCount.add(Expression.eq(WDMUtil.DEVICE_GROUP_PATH, deviceGroupPath));
		}
		criteriaRowCount.setProjection(Projections.rowCount());          
		return displayObjectList(criteriaRowCount.list());
	}

	int getRowCountAllDevices(Map<String, Object> dataMap) {
		Criteria criteriaRowCount=sessionService.getCriteria(DeviceInfo.class);    
		criteriaRowCount.setProjection(Projections.rowCount());          
		return displayObjectList(criteriaRowCount.list());
	}

	public List<DeviceInfo> findNonAuthenticatedDevices() {
		Criteria criteria=sessionService.getCriteria(DeviceInfo.class);
		criteria.add(Expression.eq("osName", OSTypes.WTOS));
		criteria.add(Expression.eq("authenticated", false));
		return criteria.list();
	}

	public DeviceInfo findWtosDeviceToImage(String ipAddress) {
		List<DeviceInfo> devices = findByIpAddress(ipAddress);
		log.info("Devices with IP "+ipAddress+" --> "+devices.size());
		for (DeviceInfo device : devices) {
			if(device.hasWtosImagingTaskInProgress()){
				return device;
			}else if(device.isBiosUpdateNeeded()){
				return device;
			}
		}
		return null;
	}

	public List<DeviceInfo> findByIpAddress(String ipAddress) {
		String query = "select d from DeviceInfo d join d.networks dn where dn.ipAddress = :ip";
		Query createQuery = sessionService.createQuery(query);
		createQuery.setString("ip", ipAddress);
		return (List<DeviceInfo>)createQuery.list();
	}

	public boolean isLicenseLimitExceeded() {
		long totalDeviceDiscovered = getTotalDeviceCount();
		return totalDeviceDiscovered >= RapportServer.licenseLimit() ;
	}

	private Long getTotalDeviceCount() {
		return sessionService.getCount(DeviceInfo.class, null, null);
	}

	private Long getTotalDeviceCountWithMac(String mac) {
		return sessionService.getCount(DeviceNetworkInfo.class, new String[]{"macAddress"}, new Object[]{mac});
	}

	public String getOsVersion(String deviceGuid){
		Query query=sessionService.createQuery("select d.osVersion from DeviceInfo d where d.deviceGuid='"+deviceGuid+"'");
		String osVersion = (String)query.uniqueResult();
		return osVersion;
	}
	
	public String getImageVersion(String deviceGuid){
		Query query=sessionService.createQuery("select d.imageName from DeviceInfo d where d.deviceGuid='"+deviceGuid+"'");
		String imageVersion = (String)query.uniqueResult();
		return imageVersion;
	}
}
