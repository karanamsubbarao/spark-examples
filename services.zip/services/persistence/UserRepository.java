/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev: 6092 $$
Last Modified: $$Date: 2006-11-08 13:01:21 +0530 (Wed, 08 Nov 2006) $$
Last Modified By: $$Author: smariswamy $$
*/

package com.wyse.rapport.services.persistence;

import org.apache.commons.lang.StringUtils;

import com.wyse.rapport.db.tbl.User;
import com.wyse.rapport.services.IHibernateSessionService;

/** Understands retreiving/saving users and their credentials(encrypted using MD5) */
public class UserRepository implements IUserRepository {
    public static final String ADMINISTRATOR = "admin";
    private IHibernateSessionService sessionService;

    public UserRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
    }

    public User getAdministrator() {
        return (User) sessionService.find(User.class, ADMINISTRATOR);
    }

    public User findUser(String userName) {
        assert !StringUtils.isBlank(userName) : "User name cannot be empty/null";
        return (User) sessionService.find(User.class, userName);
    }

	public String getCurrentAdmin() {
		User administrator = getAdministrator();
		return administrator == null ? "Admin" :administrator.getUserName();
	}
}