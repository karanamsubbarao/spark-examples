/**
 * Copyright (c) Wyse Technology, Inc.
 * Current Revision: $Rev: 7137 $
 * Last Modified: $Date: 2007-02-21 12:14:19 +0530 (Wed, 21 Feb 2007) $
 * Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.persistence;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Projections;

import com.wyse.common.SystemLogConstant;
import com.wyse.rapport.businesslogic.comparator.ELogFilterCriteria;
import com.wyse.rapport.businesslogic.comparator.ELogSortCriteria;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.SystemLog;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.util.WyseNumberUtils;

public class SystemLogService implements ISystemLogService {
   
    private static Logger logger = Logger.getLogger(SystemLogService.class);
    private IHibernateSessionService sessionService;
    private IUserPreferencesRepository userPreferenceRepository;
    
    public SystemLogService(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
    }
    
    public void setUserPreferenceRepository(IUserPreferencesRepository userPreferenceRepository) {
        this.userPreferenceRepository = userPreferenceRepository;
    }
    
    public int getRangeFactor(){
        return userPreferenceRepository.getRangeFactorFromUserPreference();
    }
    
    public void deleteAll() {
        sessionService.deleteWithQuery("delete from SystemLog");
    }
    
    public void delete(Collection<Long> systemLogIds) {
        for (Long systemLogId : systemLogIds) {
            SystemLog log = findSystemLogById(systemLogId);
            if (log != null) {
                sessionService.delete(log);
            }
        }
    }
    
    public List<SystemLog> findAll() {
        Query q = sessionService.createQuery("from SystemLog c order by logTime desc");
        if (q.list().isEmpty()) {
            return Collections.emptyList();
        }
        return q.list();
    }
    
    public Map<String, Object> findAll( Map<String, Object> dataMap) {	
        int startRow = (Integer)dataMap.get(SystemLogConstant.START_ROW);
        int endRow = (Integer)dataMap.get(SystemLogConstant.END_ROW);
        int pageNumber = (Integer)dataMap.get(SystemLogConstant.PAGE_NUMBER);
        List<SystemLog> databaseList = new ArrayList<SystemLog>();
        int totalFilteredRecords = getRowCount(dataMap); 
        int totalRecords = getTotalRowCount();
        
        if(endRow > totalFilteredRecords){
            endRow = totalFilteredRecords;
        }        
        if(startRow > totalFilteredRecords){
            startRow = 1;
        }
        
        dataMap.put(SystemLogConstant.END_ROW,endRow);
        dataMap.put(SystemLogConstant.START_ROW,startRow);
        dataMap.put(SystemLogConstant.TOTAL_RECORDS,new Integer(totalFilteredRecords));
        dataMap.put(SystemLogConstant.GRAND_TOTAL_RECORDS,new Integer(totalRecords));
        
        databaseList=findLogs(dataMap);
        
        if (databaseList.isEmpty()) {
            databaseList=Collections.emptyList();
        } 
        dataMap.put(SystemLogConstant.SYSTEM_LOG_SUMMARY, databaseList);
        int totalNoOfPages=WyseNumberUtils.getPageNumber(totalFilteredRecords,getRangeFactor());
        dataMap.put(SystemLogConstant.TOTAL_NO_OF_PAGES,new Integer(totalNoOfPages)); 
        if(totalNoOfPages == 1 || pageNumber > totalNoOfPages){
            dataMap.put(SystemLogConstant.PAGE_NUMBER,new Integer(totalNoOfPages));
        }
        return dataMap;
    }
    
    private int getTotalRowCount() {
        Criteria criteriaRowCount=sessionService.getCriteria(SystemLog.class);
        Criterion criterion=Expression.ne("level",new Integer(SystemLogConstant.FATAL));
        criteriaRowCount.add(criterion);
        criteriaRowCount.setProjection(Projections.rowCount());          
        int totalRecords=displayObjectList(criteriaRowCount.list()); 
        return totalRecords;
    }

    int getRowCount(Map<String, Object> dataMap) {
        Criteria criteriaRowCount=sessionService.getCriteria(SystemLog.class);
        addFilterCriterias(dataMap, criteriaRowCount);
        criteriaRowCount.setProjection(Projections.rowCount());          
        int totalRecords=displayObjectList(criteriaRowCount.list()); 
        return totalRecords;
    }
    
    private List<SystemLog> findLogs(Map<String, Object> dataMap) {
        int startRow = (Integer)dataMap.get(SystemLogConstant.START_ROW); 
        ELogSortCriteria sortCriteria=(ELogSortCriteria)dataMap.get(SystemLogConstant.SORT_CRITERIA);
        String sortOrder=(String)dataMap.get(SystemLogConstant.SORT_ORDER);        
        Criteria criteria=sessionService.getCriteria(SystemLog.class);
        criteria.setFirstResult(startRow-1);
        criteria.setMaxResults(getRangeFactor());
        addFilterCriterias(dataMap, criteria);
        sortCriteria.sort(sortOrder, criteria);
        return (ArrayList<SystemLog>)criteria.list();
    }
    
    public void error(String message) {
        log(SystemLogConstant.ERROR, message, "NA", "NA");
    }
    
    public void warn(String message) {
        log(SystemLogConstant.WARNING, message, "NA", "NA");
    }
    
    public void error(String msg, Device device) {
        log(SystemLogConstant.ERROR, msg, device);
    }
    
    public void fatal(String message) {
        log(SystemLogConstant.FATAL, message, null, null);
    }
    
    public void info(String msg, Device device) {
        log(SystemLogConstant.INFO, msg, device);
    }
    
    public void info(String msg) {
        log(SystemLogConstant.INFO, msg, null);
    }
    
    public void create(SystemLog systemlog) {
        sessionService.createOrUpdate(systemlog);
    }
    
    private void log(int level, String msg, String ip, String mac) {
        create(new SystemLog(level, ip, mac, msg, new Date()));
    }
    
    private SystemLog findSystemLogById(long systemLogId) {
        return (SystemLog) sessionService.find(SystemLog.class, systemLogId);
    }
    
    private void log(int error, String msg, Device device) {
        log(error, msg, networkAddress(device), physicalAddress(device));
    }
    
    private String networkAddress(Device device) {
        String ip = (device == null) ? "NA" : device.getActiveIp();
        return ip == null ? "NA" : ip;
    }
    
    private String physicalAddress(Device device) {
        String mac = (device == null) ? "NA" : device.getActiveMac();
        return mac == null ? "NA" : mac;
    }
    
    public int displayObjectList(List list)
    {
        int results=0;
        Iterator iter = list.iterator();
        if (!iter.hasNext())
        {
        	logger.info("No objects to display.");
            return results;
        }
        while (iter.hasNext()){
            Integer obj = (Integer)iter.next();
            results= obj;
            break;
        }
        
        return results;
    }
    
    private void addFilterCriterias(Map<String, Object> dataMap, Criteria criteria){
        List<ELogFilterCriteria> filterList=(List<ELogFilterCriteria>)dataMap.get(SystemLogConstant.FILTER_CRITERIA);
        ELogFilterCriteria dateFiletrCriteria=(ELogFilterCriteria)dataMap.get(SystemLogConstant.DATE_FILTER_CRITERIA);
        Disjunction disjunction=Expression.disjunction();
        String startDateString=(String) dataMap.get(SystemLogConstant.START_DATE);
        String endDateString=(String) dataMap.get(SystemLogConstant.END_DATE);
        Date startDate=parseStringToDate(startDateString);
        Date endDate=parseStringToDate(endDateString);
        for(ELogFilterCriteria filterCriteria : filterList){
            disjunction.add(filterCriteria.filter(startDate,endDate));
        }
        Conjunction conjunction=Expression.conjunction();
        Criterion criterion = dateFiletrCriteria.filter(startDate,endDate);
        if(criterion !=null){
            conjunction.add(dateFiletrCriteria.filter(startDate,endDate));
            conjunction.add(disjunction);
            criteria.add(conjunction);
        }else{
            criteria.add(disjunction);
        }
        disjunction = null;
        conjunction = null;
    }
    
    private Date parseStringToDate(String dateString) {
        if(StringUtils.isNotBlank(dateString)){
            DateFormat dateFormat=DateFormat.getDateInstance(1);
            try {
                return dateFormat.parse(dateString);
            } catch (ParseException e) {
                return new Date();
            }
        }
        return new Date();
    }   
}