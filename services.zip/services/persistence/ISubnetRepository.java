/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 3119 $
 Last Modified: $Date: 2005-12-09 19:21:58 +0530 (Fri, 09 Dec 2005) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.persistence;

import java.util.Collection;

import com.wyse.rapport.db.tbl.Subnet;

/** @author smariswamy */
public interface ISubnetRepository {
    public void create(Subnet subnet);

    public void update(Subnet subnet);

    public Subnet findById(long subnetID);

    public Collection<Subnet> findAll();

    public boolean exists(Subnet subnet);

    public Subnet existingSubnet(Subnet subnet);

    public int deleteSubnetsWithNoDevices(Collection<Long> subnetIds);

    public void deleteAll();

    public Subnet find(String subnetMask, String networkAddress);
}