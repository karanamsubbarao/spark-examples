/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 7236 $
 Last Modified: $Date: 2007-04-17 12:54:11 +0530 (Tue, 17 Apr 2007) $
 Last Modified By: $Author: ijibanandaray $
 */

package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;

import com.wyse.rapport.businesslogic.comparator.GroupComparator;
import com.wyse.rapport.db.tbl.DeviceGroup;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.wnom.WnomConfiguration;

/** CRUD operations for DeviceGroup */
public class DeviceGroupRepository implements IDeviceGroupRepository {
	private IHibernateSessionService sessionService;
	private IUserRepository userRepository;
	private ISystemLogService systemLogService;

    public DeviceGroupRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
        this.userRepository = new UserRepository(sessionService);
        this.systemLogService = new SystemLogService(sessionService);
    }

	public void create(DeviceGroup group) {
		group.setCreatedOn(new Date());
		group.setCreatedBy(getAdministrator());
		sessionService.create(group);
	}

	public void update(DeviceGroup group) {
		if(group.getGroupId() == null){
			group.setCreatedOn(new Date());
			group.setCreatedBy(getAdministrator());
		}else{
			group.setLastModifiedBy(getAdministrator());
			group.setLastModifiedOn(new Date());
		}
		sessionService.createOrUpdate(group);
	}

	public String getAdministrator() {
		return userRepository.getCurrentAdmin();
	}

	public DeviceGroup findById(Long groupId) {
		return (DeviceGroup) sessionService.find(DeviceGroup.class, groupId);
	}

	public Collection<DeviceGroup> findAll() {
		Criteria criteria = sessionService.getCriteria(DeviceGroup.class);
		List<DeviceGroup> list = criteria.list();
		Collections.sort(list, new GroupComparator());
		return list;
	}

	public void deleteAll() {
		sessionService.deleteCollection(findAll());
	}
	
	public void delete(DeviceGroup group) {
		sessionService.delete(group);
	}

	public DeviceGroup findDefaultGroup() {
		Criteria criteria = sessionService.getCriteria(DeviceGroup.class);
		criteria.add(Expression.eq("parentPath", ""));
		 if(criteria.list().isEmpty()){
			return null;
		}
		 return (DeviceGroup)criteria.list().iterator().next();
	}

	public DeviceGroup findByParentPath(String parentPath, String groupName) {
		Criteria criteria = sessionService.getCriteria(DeviceGroup.class);
		criteria.add(Expression.eq("parentPath", parentPath));
		criteria.add(Expression.eq("name", groupName));
		 if(criteria.list().isEmpty()){
			return null;
		}
		 return (DeviceGroup)criteria.list().iterator().next();
	}
	
	public WnomConfiguration findParentWnomConfiguration(DeviceGroup group) {
		if(group.isRootNode()){
			return group.getConfiguration();
		}
		DeviceGroup parentGroup = findById(group.getParentGroupId());
		return parentGroup.getConfiguration();
	}

	public List<DeviceGroup> findDeviceGroupsForConfiguration(WnomConfiguration configuration) {
		Criteria criteria = sessionService.getCriteria(DeviceGroup.class);
		criteria.add(Expression.eq("configuration", configuration));
		 return criteria.list();
	}
    
    public DeviceGroup findDefaultUnassigned() {
        Criteria criteria = sessionService.getCriteria(DeviceGroup.class);
        criteria.add(Expression.eq("isDefaultUnassigned", true));
        return (DeviceGroup) criteria.uniqueResult();
    }
	
	public WnomConfiguration getDeviceConfiguration(DeviceInfo device) {
		DeviceGroup group = getDeviceGroup(device);
        if(group != null){
			return group.getConfiguration();
	    }
        return null;
	}

	private DeviceGroup getDeviceGroup(DeviceInfo device) {
		DeviceGroup group = null;
	    String deviceGroupPath = device.getDeviceGroupPath();
        
        if(DeviceGroup.UNASSIGNED_PATH.equals(deviceGroupPath)){
    	    group = findDefaultUnassigned();
        }else{
            int index = deviceGroupPath.lastIndexOf("/");
            Long groupId = Long.parseLong(deviceGroupPath.substring(index+1));
            group = findById(groupId);
        }
		return group;
	}

	public void moveGroup(DeviceGroup destinationGroup, DeviceGroup groupToMove) {
		updateSourceGroup(groupToMove);
		updateDestination(destinationGroup, groupToMove);
	}

	private DeviceGroup updateDestination(DeviceGroup destinationGroup, DeviceGroup groupToMove) {
		DeviceGroup newGroup = DeviceGroup.createNewGroup(groupToMove, destinationGroup);
		destinationGroup.addChild(newGroup);
        update(destinationGroup);
		updateDevices(groupToMove.getAbsoluteIdPath(), newGroup);		
		systemLogService.info("\""+groupToMove.getName()+"\" is moved from \""+groupToMove.getParentTreePath()+"\" is moved to \""+newGroup.getParentTreePath()+"\"", null);
		updateChildren(newGroup, groupToMove);
		return newGroup;
	}

	private void updateDevices(String absoluteIdPath, DeviceGroup newGroup) {
		IDeviceRepository deviceRepository = new DeviceRepository(sessionService);
		List<DeviceInfo> devicesInGroup = deviceRepository.findDevicesInGroup(absoluteIdPath);
		newGroup.setDeviceCount(Long.valueOf(devicesInGroup.size()));
		for (DeviceInfo device : devicesInGroup) {
			device.setDeviceGroupPath(newGroup.getAbsoluteIdPath());
			deviceRepository.update(device);
		}
	}

	private void updateChildren(DeviceGroup parent, DeviceGroup source) {
		List<DeviceGroup> childGroups = source.getChildren();
		for (DeviceGroup group : childGroups) {
			updateDestination(parent, group);
		}
	}

	private void updateSourceGroup(DeviceGroup groupToMove) {
		DeviceGroup sourceGroup = findById(groupToMove.getParentGroupId());
		sourceGroup.removeChild(groupToMove);
		update(sourceGroup);
	}

	public DeviceGroup findParent(DeviceGroup deviceGroup) {
		return findById(deviceGroup.getParentGroupId());
	}

}
