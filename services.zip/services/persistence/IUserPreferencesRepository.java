/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 7205 $
Last Modified: $Date: 2007-04-10 12:43:22 +0530 (Tue, 10 Apr 2007) $
Last Modified By: $Author: skaranam $
*/

package com.wyse.rapport.services.persistence;

import com.wyse.rapport.db.tbl.UserPreferences;

public interface IUserPreferencesRepository {
	
    UserPreferences findAll();

    void createOrUpdate(UserPreferences settings);

	int getTaskRetryCount();
	
	int getRangeFactorFromUserPreference();
	
	boolean isAutomaticDiscoveryAllowed();
    
	boolean isHttpsCommunicationAllowed();
	
    String getFilterString();
}