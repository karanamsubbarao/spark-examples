/*
 Copyright (c) Wyse Technology, Inc.
 
 Current Revision: $Rev: 7205 $
 Last Modified: $Date: 2007-04-10 12:43:22 +0530 (Tue, 10 Apr 2007) $
 Last Modified By: $Author: skaranam $
 */

package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.List;

import com.wyse.rapport.configuration.UserPreference;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.services.IHibernateSessionService;

public class UserPreferencesRepository implements IUserPreferencesRepository {
    private IHibernateSessionService sessionService;

    public UserPreferencesRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
    }

    public void createOrUpdate(UserPreferences settings) {
        Collection<UserPreference> preferences = settings.getUserPreferences().values();
        for (UserPreference setting : preferences) {
            createOrUpdate(setting);
        }
    }

    public UserPreferences findAll() {
        List<UserPreference> userPreferences = (List<UserPreference>) sessionService.createQuery(" from UserPreference").list();
        UserPreferences preferences = new UserPreferences();
        for (UserPreference setting : userPreferences) {
            preferences.setUserPreference(setting);
        }
        return preferences;
    }

    private void createOrUpdate(UserPreference preference) {
        UserPreference currentPreference = (UserPreference) sessionService.find(UserPreference.class, preference.getName());
        currentPreference = (currentPreference != null) ? currentPreference.merge(preference) : preference;
        sessionService.createOrUpdate(currentPreference);
    }

	public int getTaskRetryCount() {
		String taskRetries = findAll().getValue(UserPreferences.TASK_RETRIES);
		String retryCount = (taskRetries == null)  ? UserPreferences.DEFAULT_TASK_RETRIES : taskRetries;
		return Integer.parseInt(retryCount);
	}
	
	public boolean isAutomaticDiscoveryAllowed() {
		String isAutomaticDiscoveryAllowed = (findAll().getValue(UserPreferences.ALLOW_AUTOMATIC_DISCOVERY));
		isAutomaticDiscoveryAllowed = (isAutomaticDiscoveryAllowed == null) ? UserPreferences.DEFAULT_ALLOW_AUTOMATIC_DISCOVERY : isAutomaticDiscoveryAllowed;
		return Boolean.parseBoolean(isAutomaticDiscoveryAllowed);
	}

	public int getRangeFactorFromUserPreference() {
		String rangeFactor = findAll().getValue(UserPreferences.SYSTEM_LOGS_PER_PAGE);
		String systemLogsPerPage = (rangeFactor == null)  ? UserPreferences.DEFAULT_SYSTEM_LOGS_PER_PAGE : rangeFactor;
		return Integer.parseInt(systemLogsPerPage);
	}
    
    public String getFilterString() {
        return findAll().getValue(UserPreferences.FILTER_STRING_LIST);
    }

	public boolean isHttpsCommunicationAllowed() {
		String isHttpsCommunicationAllowed = (findAll().getValue(UserPreferences.ACTIVATE_HTTPS));
		isHttpsCommunicationAllowed = (isHttpsCommunicationAllowed == null) ? UserPreferences.DEFAULT_HTTPS_SECURITY_PROTOCOL : isHttpsCommunicationAllowed;
		return Boolean.parseBoolean(isHttpsCommunicationAllowed);
	}
}