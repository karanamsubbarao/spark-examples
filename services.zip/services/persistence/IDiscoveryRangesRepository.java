/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 5248 $
 Last Modified: $Date: 2006-02-15 18:19:10 +0530 (Wed, 15 Feb 2006) $
 Last Modified By: $Author: suneetha $
 */

package com.wyse.rapport.services.persistence;

import com.wyse.rapport.businesslogic.iprange.IPRanges;

public interface IDiscoveryRangesRepository {
    void create(IPRanges ranges);

    boolean shouldTrack(String ipAddress);

    void deleteAll();
}
