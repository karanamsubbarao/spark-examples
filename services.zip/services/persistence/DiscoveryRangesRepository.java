/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 5248 $
 Last Modified: $Date: 2006-02-15 18:19:10 +0530 (Wed, 15 Feb 2006) $
 Last Modified By: $Author: suneetha $
 */

package com.wyse.rapport.services.persistence;

import java.util.List;

import com.wyse.rapport.businesslogic.iprange.IPRange;
import com.wyse.rapport.businesslogic.iprange.IPRanges;
import com.wyse.rapport.db.tbl.DiscoveryRanges;
import com.wyse.rapport.services.IHibernateSessionService;

public class DiscoveryRangesRepository implements IDiscoveryRangesRepository {
    private IHibernateSessionService sessionService;

    public DiscoveryRangesRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
    }

    public boolean shouldTrack(String ipAddress) {
        List<DiscoveryRanges> discoveryRanges = findAll();
        for (DiscoveryRanges range : discoveryRanges) {
            IPRange ipRange = new IPRange(range.getStartIP(), range.getEndIP());
            if (ipRange.inRange(ipAddress)) return true;
        }
        return false;
    }

    public void deleteAll() {
        sessionService.deleteCollection(findAll());
    }

    public void create(IPRanges ranges) {
        List<IPRange> ipRanges = ranges.getIpRanges();
        for (IPRange range : ipRanges) {
            sessionService.createOrUpdate(new DiscoveryRanges(range.getStartIP(), range.getEndIP()));
        }
    }

    private List<DiscoveryRanges> findAll() {
        return sessionService.createQuery("from DiscoveryRanges ranges").list();
    }
}
