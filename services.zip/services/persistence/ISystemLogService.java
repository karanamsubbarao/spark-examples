/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 7137 $
 Last Modified: $Date: 2007-02-21 12:14:19 +0530 (Wed, 21 Feb 2007) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.SystemLog;

/** @author smariswamy */
public interface ISystemLogService {

    void deleteAll();

    void delete(Collection<Long> systemLogIds);
    
    List<SystemLog> findAll();
    
    Map<String, Object> findAll( Map<String, Object> dataMap);

    void info(String msg, Device device);

    void info(String message);
    
    void error(String msg, Device device);

    void fatal(String message);

	void error(String message);
	
	void warn(String message);

    int getRangeFactor();
    
    void create(SystemLog systemlog);

	

}