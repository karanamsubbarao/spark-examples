package com.wyse.rapport.services.persistence;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;

import com.wyse.rapport.businesslogic.comparator.GroupComparator;
import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.wnom.WnomConfiguration;


public class UserGroupRepository implements IUserGroupRepository{

    private IHibernateSessionService sessionService;
    private ISystemLogService systemLogService;
    private IUserRepository userRepository;

    public UserGroupRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
        this.userRepository = new UserRepository(sessionService);
        this.systemLogService = new SystemLogService(sessionService);
    }

    public void create(UserGroup group) {
        group.setCreatedOn(new Date());
        group.setCreatedBy(userRepository.getCurrentAdmin());
        sessionService.create(group);
    }

    public void update(UserGroup group) {
        if(group.getGroupId() == null){
            group.setCreatedOn(new Date());
            group.setCreatedBy(userRepository.getCurrentAdmin());
        }else{
            group.setLastModifiedBy(userRepository.getCurrentAdmin());
            group.setLastModifiedOn(new Date());
        }
        sessionService.createOrUpdate(group);
    }

    public UserGroup findById(Long groupId) {
        return (UserGroup) sessionService.find(UserGroup.class, groupId);
    }

    public List<UserGroup> findAll() {
        Criteria criteria = sessionService.getCriteria(UserGroup.class);
        List<UserGroup> list = criteria.list();
        Collections.sort(list, new GroupComparator());
        int index = getRootIndex(list);
        if(index !=0){
            setRootGroupAsFirst(list,index);
        }
        return list;
    }

    private void setRootGroupAsFirst(List<UserGroup> list, int index) {
        List<UserGroup> newlist =new ArrayList<UserGroup>();
        newlist.add(list.get(index));
        for(int loop=0;loop<list.size();loop++){
            UserGroup group = list.get(loop);
            if(loop != index){
                newlist.add(list.get(loop));
            }
        }
        list.clear();
        list.addAll(newlist);
        newlist.clear();
    }

    private int getRootIndex(List<UserGroup> list) {
        if(list!=null && list.size()>0){
            for(int loop=0;loop<list.size();loop++){
                UserGroup group = list.get(loop);
                if(group.isRootNode()){
                    return loop;
                }
            }
        }
        return 0;
    }

    public void deleteAll() {
        sessionService.deleteCollection(findAll());
    }

    public void delete(UserGroup group) {
        sessionService.delete(group);}


    public UserGroup findRoot() {
        Criteria criteria = sessionService.getCriteria(UserGroup.class);
        criteria.add(Expression.eq("isRootNode",true));
        if(criteria.list().isEmpty()){
            return null;
        }
        return (UserGroup)criteria.list().iterator().next();
    }

    public UserGroup findUserGroupByName(String groupName) {
        Criteria criteria=sessionService.getCriteria(UserGroup.class);
        criteria.add(Expression.eq("name",groupName));
        if(criteria.list().isEmpty()){
            return null;
        }
        return (UserGroup)criteria.list().iterator().next();
    }

    public List<UserGroup> findUserGroupsForConfiguration(WnomConfiguration configuration) {
        Criteria criteria = sessionService.getCriteria(UserGroup.class);
        criteria.add(Expression.eq("configuration", configuration));
        return criteria.list();
    }

    public WnomConfiguration findParentWnomConfiguration(UserGroup group) {
    	if(!group.isRootNode()){
            UserGroup parentGroup = findById(group.getParentGroupId());
            return parentGroup.getConfiguration();
        }
        return group.getConfiguration();
    }

    public void delete(Long groupId) {
        UserGroup userGroup = findById(groupId);
        sessionService.delete(userGroup);
        systemLogService.info("UserGroup \""+userGroup.getName()+"\" deleted by "+"\""+userRepository.getCurrentAdmin()+"\"", null);
    }

    public void delete(Collection<Long> groupIds) {
        for(Long groupId : groupIds){
            delete(groupId);
        }

    }

	public UserGroup findParent(UserGroup userGroup) {
		return findById(userGroup.getParentGroupId());
	}

}
