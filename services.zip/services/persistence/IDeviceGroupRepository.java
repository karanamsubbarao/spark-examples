/*
 Copyright (c) 2005 Wyse Technology, Inc.
 
 Current Revision: $Rev: 6595 $
 Last Modified: $Date: 2006-12-07 12:48:32 +0530 (Thu, 07 Dec 2006) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.List;

import com.wyse.rapport.db.tbl.DeviceGroup;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.wnom.WnomConfiguration;

/**
 * Interface for CRUD operations of DeviceGroups
 */
public interface IDeviceGroupRepository {
	
    void create(DeviceGroup deviceGroup);

    void update(DeviceGroup deviceGroup);

    DeviceGroup findById(Long groupId);
    
    Collection<DeviceGroup> findAll();

	void deleteAll();
	
	DeviceGroup findDefaultGroup();

	DeviceGroup findByParentPath(String parentPath, String groupName);

	void delete(DeviceGroup group);
	
	WnomConfiguration findParentWnomConfiguration(DeviceGroup group);
	
	List<DeviceGroup> findDeviceGroupsForConfiguration(WnomConfiguration configuration);
	
	WnomConfiguration getDeviceConfiguration(DeviceInfo device);
	
	DeviceGroup findDefaultUnassigned();

	void moveGroup(DeviceGroup destinationGroup, DeviceGroup groupToMove);

	DeviceGroup findParent(DeviceGroup deviceGroup);
}
