/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.persistence;

import com.wyse.rapport.businesslogic.iprange.IPRange;
import com.wyse.rapport.businesslogic.iprange.IPRanges;
import com.wyse.rapport.db.tbl.DiscoveryProgress;
import com.wyse.rapport.db.tbl.Subnet;

public interface IDiscoveryProgressRepository {
    public int deviceCount(IPRange range);

    public int deviceCount(Subnet subnets);

    public void create(DiscoveryProgress progress);

    public void deleteAll();

    public void discovered(String ipAddress);

    public void trackRanges(IPRanges ranges);
}
