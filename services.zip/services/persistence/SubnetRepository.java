/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 3119 $
 Last Modified: $Date: 2005-12-09 19:21:58 +0530 (Fri, 09 Dec 2005) $
 Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;

import com.wyse.rapport.db.tbl.Subnet;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.discovery.IPSubnetCalculator;

/** CRUD operations for Subnets */
public class SubnetRepository implements ISubnetRepository {
    private Logger log = Logger.getLogger(SubnetRepository.class);
    private IHibernateSessionService sessionService;

    public SubnetRepository(IHibernateSessionService sessionService) {
        this.sessionService = sessionService;
    }

    public void create(Subnet subnet) {
        assert subnet != null : "null subnet in addSubnet";
        updateSubnet(subnet);
        if (!subnetExists(subnet)) {
            sessionService.create(subnet);
            log.info("Successfully added Subnet");
        }
    }

    public void update(Subnet subnet) {
        assert subnet != null : "null subnet in addSubnet";
        updateSubnet(subnet);
        if (!subnetExists(subnet)) {
            sessionService.createOrUpdate(subnet);
            log.info("Successfully updated Subnet");
        }
    }

    private void updateSubnet(Subnet subnet) {
        String subnetMask = subnet.getSubnetMask();
        String ipAddress = subnet.getIpAddress();
        assert StringUtils.isNotBlank(ipAddress) && StringUtils.isNotBlank(subnetMask);

        IPSubnetCalculator calculator = new IPSubnetCalculator(subnetMask, ipAddress);
        subnet.setBroadcastAddress(calculator.broadcastAddress());
        subnet.setSubnetAddress(calculator.subnetAddress());
    }

    public Subnet findById(long subnetID) {
        Subnet subnet = (Subnet) sessionService.find(Subnet.class, subnetID);
        if (subnet != null) {
            log.info("Retrieved Subnet with ID: " + subnetID);
        } else {
            log.info("No Subnet with ID : " + subnetID + " found");
        }
        return subnet;
    }

    public Collection<Subnet> findAll() {
        Query q = sessionService.createQuery("Select subnet from Subnet subnet");

        if (q.list().isEmpty()) {
            log.debug("No Subnet records found.");
            return Collections.emptyList();
        }
        return q.list();
    }

    public boolean exists(Subnet subnet) {
        return subnetExists(subnet);
    }

    public Subnet existingSubnet(Subnet subnet) {
        List<Subnet> nets = existingSubnets(subnet);
        return nets.isEmpty() ? null : nets.get(0);
    }

    /** Returns the actual number of subnets deleted */
    public int deleteSubnetsWithNoDevices(Collection<Long> ids) {
        List<Subnet> subnets = sessionService.createQuery("from Subnet where subnetId in (" + getIdsString(ids) + ")").list();
        List<String> existingIps = sessionService.createQuery("Select distinct dn.ipAddress from DeviceNetworkInfo dn").list();
        int deletedSubnets = 0;
        for (Subnet subnet : subnets) {
            if (!isDevicePresentInSubnet(existingIps, subnet)) {
                sessionService.delete(subnet);
                deletedSubnets++;
            }
        }
        return deletedSubnets;
    }

    private boolean isDevicePresentInSubnet(List<String> existingIps, Subnet subnet) {
        for (String ip : existingIps) {
            if (subnet.getIpRange().inRange(ip)) {
                return true;
            }
        }
        return false;
    }

    private String getIdsString(Collection<Long> ids) {
        String idsStr = "";
        for (Long id : ids) {
            idsStr += id + ",";
        }
        return StringUtils.chomp(idsStr, ",");
    }

    private boolean subnetExists(Subnet subnet) {
        return !(existingSubnets(subnet).isEmpty());
    }

    private List<Subnet> existingSubnets(Subnet subnet) {
        String query = "from Subnet sub where sub.subnetMask=:mask and sub.subnetAddress=:subnetAddress";
        Query q = sessionService.createQuery(query);
        q.setString("mask", subnet.getSubnetMask());
        q.setString("subnetAddress", new IPSubnetCalculator(subnet).subnetAddress());
        return q.list();
    }

    public Subnet find(String mask, String networkAddress) {
        Query q = sessionService.createQuery("Select subnet from Subnet subnet where subnetMask= :mask");
        q.setString("mask", mask);
        List<Subnet> subnets = q.list();
        for (Subnet subnet : subnets) {
            if (subnet.getIpRange().inRange(networkAddress)) {
                return subnet;
            }
        }
        return null;
    }

    public void deleteAll() {
        sessionService.deleteWithQuery("delete from Subnet");
    }
}
