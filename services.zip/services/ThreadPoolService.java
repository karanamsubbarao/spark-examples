/*
 * Copyright (c) 2005 Wyse Technology, Inc. Current Revision: $Rev: 4809 $ Last
 * Modified: $Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $ Last Modified By: $Author: smariswamy $
 */

package com.wyse.rapport.services;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.wyse.rapport.server.RapportServer;

/** @author smariswamy */
public class ThreadPoolService implements IThreadPoolService {
    private static final int THREAD_PRIORITY = 3;
    private static Logger log = Logger
            .getLogger(ThreadPoolService.class);
    private ThreadPoolExecutor threadPool = null;
    private int poolSize;
    private int maxSizeBeforeReject;
    private int threadKeepAliveTime;
    private LinkedBlockingQueue<Runnable> threadQueue;

    public ThreadPoolService(int poolSize) {
        initialize();
        this.poolSize = poolSize;
    }

    public ThreadPoolService() {
        initialize();
    }

    void initialize() {
        poolSize = RapportServer.threadPoolSettings().poolSize();
        maxSizeBeforeReject = RapportServer.threadPoolSettings().maxSizeBeforeReject();
        threadKeepAliveTime = RapportServer.threadPoolSettings().threadKeepAliveTimeInSecs(); // seconds
        threadQueue = new LinkedBlockingQueue<Runnable>();
        threadPool = new ThreadPoolExecutor(poolSize, maxSizeBeforeReject,
                                            threadKeepAliveTime, TimeUnit.SECONDS, threadQueue, threadFactory());
    }

    private ThreadFactory threadFactory() {
        return new ThreadFactory() {
            public Thread newThread(Runnable r) {
                Thread thread = new Thread(r);
                thread.setPriority(THREAD_PRIORITY);
                return thread;
            }
        };
    }

    public long isIdle() {
        // This is a HACK. Need a better way of knowing if the discovery is complete.
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            // do nothing
        }
        if (threadPool.getTaskCount() == 0) {
            return -1;
        }
        return (threadPool.getTaskCount() - threadPool.getCompletedTaskCount());
    }

    /* (non-Javadoc)
    * @see com.wyse.rapport.services.IThreadPoolService#shutdown()
    */
    public void shutdown() {
        if (threadPool != null) {
            log.info("The active Thread in pool : " + threadPool.getActiveCount());
            log.info("whether pool is shoutdown : " + threadPool.isShutdown());
            threadPool.shutdown();
            log.info("Thread Pool is shutdown....");
            log.info("The no. of threads in the pool are : " + threadPool.getPoolSize());
            threadQueue.clear();
            log.info("whether pool is shutdown : " + threadPool.isShutdown());
        }
        threadPool = null;
    }

    /* (non-Javadoc)
    * @see com.wyse.rapport.services.IThreadPoolService#submitJob(java.lang.Runnable)
    */
    public void submitJob(Runnable job) {
        threadPool.execute(job);
    }
}
