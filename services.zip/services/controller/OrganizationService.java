package com.wyse.rapport.services.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.StringTokenizer;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.wyse.common.SystemLogConstant;
import com.wyse.rapport.adminclient.DeviceSummaryController;
import com.wyse.rapport.adminclient.organization.OrganizationController;
import com.wyse.rapport.adminclient.organization.UserGroupController;
import com.wyse.rapport.db.tbl.DeviceGroup;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.db.tbl.DeviceUser;
import com.wyse.rapport.db.tbl.Subnet;
import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.services.persistence.IDeviceGroupRepository;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IDeviceUserRepository;
import com.wyse.rapport.services.persistence.ISubnetRepository;
import com.wyse.rapport.services.persistence.IUserGroupRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.wnom.IWnomConfigurationRepository;
import com.wyse.rapport.wnom.WnomConfiguration;
import com.wyse.rapport.wnom.WnomConstants;

public class OrganizationService {
	
	private static final String USER_SUMMARY = "userSummary";
	public static final String CURRENT_DEVICE_GROUP_ID = OrganizationController.CURRENT_DEVICE_GROUP_ID;
	public static final String CURRENT_USER_GROUP_ID = OrganizationController.CURRENT_USER_GROUP_ID;
	public static final String CURRENT_USER_GROUP = "currentUserGroup";
	static final String ROOT_USER_GROUP = "rootUserGroup";

	public static final String DEVICE_SUMMARY = "deviceSummary";
	private static final Integer START_ROW = new Integer(1);

	private IDeviceRepository deviceRepository;
	private IDeviceGroupRepository deviceGroupRepository;
	private IUserPreferencesRepository userPreferenceRepository;
	private IUserGroupRepository userGroupRepository;
	private IDeviceUserRepository deviceUserRepository;
    private ISubnetRepository subnetRepository;
	private IWnomConfigurationRepository wnomConfigurationRepository;
	
	private static Logger log = Logger.getLogger(OrganizationService.class);

	public Map<String, Object> getDeviceGroupDetails(HttpServletRequest request, String currentGroupId, Map<String, Object> sortingData) {
		UserPreferences preferences = new UserPreferences(userPreferenceRepository);
		Map<String, Object> deviceGroupMap = getPaginationDetails(request,sortingData);
		addDefaultDeviceConfigurationIfRequired();
		addDefaultGroupIfRequired(request, deviceGroupMap);
		DeviceGroup deviceGroup = currentDeviceGroup(currentGroupId);
		if(deviceGroup==null){
			deviceGroup=deviceGroupRepository.findDefaultGroup();
		}
		//This creates the default groups when not exist in db
		deviceGroupMap.put("currentGroup", deviceGroup);
		deviceGroupMap.put(DEVICE_SUMMARY, getDevices(preferences, deviceGroupMap, deviceGroup));
		updateDeviceCount(null, deviceGroupMap);
		deviceGroupMap.put("parentsIdAndName", getParentsDetails(deviceGroup));
		return deviceGroupMap;
	}

	private Collection<DeviceInfo> getDevices(UserPreferences preferences, Map<String, Object> deviceGroupMap, DeviceGroup deviceGroup) {
		
		Collection<DeviceInfo> devices = deviceRepository.findDevicesInGroup(preferences, deviceGroup.getAbsoluteIdPath(), deviceGroupMap);
		updateDeviceStatus(devices,new UserPreferences(userPreferenceRepository));
		return devices;
	}

    private void updateDeviceStatus(Collection<DeviceInfo> csd, UserPreferences settings) {
        for (DeviceInfo info : csd) {
        	info.setDisplayStatus(settings);
            updateSubnetAddress(info);
        }
    }

    private void updateSubnetAddress(DeviceInfo device) {
        Collection<DeviceNetworkInfo> networks = device.getDeviceNetworks();
        for (DeviceNetworkInfo network : networks) {
            Subnet subnet = subnetRepository.find(network.getSubnetMask(), network.getIpAddress());
            if (subnet != null) {
                String subnetAddress = subnetAddress(subnet);
                String description = subnet.getDescription();
                if (StringUtils.isNotBlank(description)) {
                    network.setSubnetAddress(description + " (" + subnetAddress + ")");
                } else {
                    network.setSubnetAddress(subnetAddress);
                }
            } else {
                network.setSubnetAddress();
            }
        }
    }
    
    private String subnetAddress(Subnet subnet) {
        String mask = subnet.getSubnetAddress();
        int index = mask.indexOf("(");
        return index < 0 ? mask : mask.substring(index + 1, mask.indexOf(")")).trim();
    }

	public Map<String, Object> getUserGroupAndDeviceUserDetails(HttpServletRequest request) {
		Map<String, Object> userGroupDetails = getUserGroupDetails(request);
		userGroupDetails.putAll(getDeviceUserDetails(request));
		return userGroupDetails;
	}

	public Map<String,Object> getPaginationDetails(HttpServletRequest request, Map<String, Object> sortingData) {
		Map<String,Object> data=sortingData;
		Integer rangeFactor= userPreferenceRepository.getRangeFactorFromUserPreference();
		Integer startRow=START_ROW;
		Integer endRow=rangeFactor;
		String pageNumberValue = request.getParameter("pageNumber");
		int pageNumber =1;
		if(pageNumberValue != null){
			pageNumber =Integer.parseInt(pageNumberValue);
		}        
		startRow= new Integer(((pageNumber-1)*rangeFactor)+1);
		endRow = new Integer(pageNumber * rangeFactor);
		data.put("rangeFactor", rangeFactor);
		data.put("pageNumber",pageNumber);
		data.put("startRow",startRow);
		data.put("endRow",endRow);
		return data;
	}
	
	public String getCurrentDeviceGroupId(HttpServletRequest request, HttpSession session, String attributeName) {
		String currentGroupId = request.getParameter(attributeName);
		if(currentGroupId==null){
			currentGroupId=(String) session.getAttribute(attributeName);
		}
		session.setAttribute(attributeName,currentGroupId);
		return currentGroupId == null ? "" :currentGroupId;
	}

	public String getCurrentUserGroupId(HttpServletRequest request, HttpSession session) {
		String currentUserGroupId = request.getParameter(CURRENT_USER_GROUP_ID);
		if(StringUtils.isBlank(currentUserGroupId)){
			currentUserGroupId=(String) session.getAttribute(CURRENT_USER_GROUP_ID);
		}
		if(StringUtils.isBlank(currentUserGroupId)) {
			currentUserGroupId = userGroupRepository.findRoot().getGroupId().toString();	
		}
		session.setAttribute(CURRENT_USER_GROUP_ID,currentUserGroupId);
		return currentUserGroupId ;
	}

	
	public SortedMap<Long, String> getParentsDetails(DeviceGroup currentGroup) {
		SortedMap<Long, String> parentDetails = new TreeMap<Long, String>();
		String parentPath = currentGroup.getParentPath();
		if(StringUtils.isBlank(parentPath))return parentDetails;
		if(parentPath.indexOf("/") >= 0 ){
			StringTokenizer parents = new StringTokenizer(parentPath, "/");
			while(parents.hasMoreElements()){
				Long parentGroupId = Long.valueOf(parents.nextToken());
				parentDetails.put(parentGroupId, deviceGroupRepository.findById(parentGroupId).getName());
			}
		}else{
			Long parentGroupId = Long.valueOf(parentPath);
			parentDetails.put(parentGroupId, deviceGroupRepository.findById(parentGroupId).getName());
		}
		return parentDetails;
	}
	
	public DeviceGroup currentDeviceGroup(String currentGroupId) {
		if(StringUtils.isBlank(currentGroupId)){
			return deviceGroupRepository.findDefaultGroup();
		}
		return deviceGroupRepository.findById(Long.valueOf(currentGroupId));
	}

	public Map<String,String> findGuidAndIPs(String deviceGroupPath){
		return deviceRepository.findGuidsAndIps(deviceGroupPath);
	}

	private Map<String, Object> getDeviceUserDetails(HttpServletRequest request) {
		Map<String, Object> deviceUserGroupMap = new HashMap<String, Object>();
		String userGroupId = getCurrentUserGroupId(request, request.getSession());
        deviceUserGroupMap.put(UserGroupController.CURRENT_USER_GROUP_ID, userGroupId);
        UserGroup userGroup = userGroupRepository.findById(Long.parseLong(userGroupId));
        UserGroup rootUserGroup = userGroupRepository.findRoot();
        deviceUserGroupMap.put("rootUserGroupId", rootUserGroup.getGroupId());
        log.info("Current User Group id "+userGroupId);
        if(userGroup != null && userGroup.isDefaultUnassigned()){
            deviceUserGroupMap.put("unAssignUserGroupId", userGroup.getGroupId());
        }
        deviceUserGroupMap = getPaginationDetails(request, deviceUserGroupMap);
		List<DeviceUser> users = findDeviceUsers(deviceUserGroupMap);
		deviceUserGroupMap.put(USER_SUMMARY,users);
		return deviceUserGroupMap;
	}

	private List<DeviceUser> findDeviceUsers(Map<String, Object> deviceUserGroupMap) {
		List<DeviceUser> users = deviceUserRepository.findUsersInGroup(deviceUserGroupMap);
		return users;
	}

	public Map<String, Object> getUserGroupDetails(HttpServletRequest request) {
		Map<String, Object> userGroupMap =  new HashMap<String, Object>();
		UserGroup root = userGroupRepository.findRoot();
		addDefaultUserConfigurationIfRequired();
		if(root == null){
			root = getDefaultUserGroup();
			userGroupMap.put(CURRENT_USER_GROUP, root);
			userGroupMap.put(CURRENT_USER_GROUP_ID, root.getGroupId());
		} else{
			String currentUserGroupId =getCurrentUserGroupId(request, request.getSession());
			if(StringUtils.isNotBlank(currentUserGroupId)){
				UserGroup currentGroup = userGroupRepository.findById(Long.valueOf(currentUserGroupId));
				if(currentGroup!=null){
					userGroupMap.put(CURRENT_USER_GROUP, currentGroup);
					userGroupMap.put(CURRENT_USER_GROUP_ID, currentUserGroupId);
				}else{
					userGroupMap.put(CURRENT_USER_GROUP, root);
					userGroupMap.put(CURRENT_USER_GROUP_ID, root.getGroupId());
				}
			}else{
				userGroupMap.put(CURRENT_USER_GROUP, root);
				userGroupMap.put(CURRENT_USER_GROUP_ID, root.getGroupId());
			}
		}
		userGroupMap.put(ROOT_USER_GROUP, root);
		updateUserCount(root);
		return userGroupMap;
	}

	private void addDefaultUserConfigurationIfRequired() {
		WnomConfiguration globalConfiguration = wnomConfigurationRepository.getGlobalUserConfiguration();
		if(globalConfiguration == null){
			globalConfiguration = new WnomConfiguration(WnomConfiguration.DEFAULT, WnomConfiguration.USER_CONFIGURATION_TYPE);
			globalConfiguration.setDescription(WnomConfiguration.DEFAULT_USER_CONFIGURATION);
            globalConfiguration.setName(WnomConfiguration.DEFAULT);
			globalConfiguration.setGlobal(true);
			wnomConfigurationRepository.update(globalConfiguration);
		}
	}

	void updateUserCount(UserGroup userGroup) {
		long totalCount = 0;
		List<UserGroup> children = userGroup.getChildren();
		for (UserGroup group : children) {
			long usersCount = deviceUserRepository.findUsersCountInGroup(group);
			group.setUserCount(usersCount);
			totalCount += usersCount;
		}
		userGroup.setUserCount(totalCount);
	}

	private UserGroup getDefaultUserGroup() {
		UserGroup root = UserGroup.getRootGroup();
		assignGlobalUserConfigurationToUserGroup(root);
		userGroupRepository.create(root);
		UserGroup defaultUnassignedGroup = UserGroup.defaultUnassignedGroup();
        assignGlobalUserConfigurationToUserGroup(defaultUnassignedGroup);
        root.addChild(defaultUnassignedGroup);
		userGroupRepository.update(root);
		return root;
	}

	private DeviceGroup getDefaultDeviceGroup() {
		DeviceGroup root = DeviceGroup.getRootGroup();
		deviceGroupRepository.create(root);
		DeviceGroup defaultUnassignedGroup = DeviceGroup.defaultUnassignedGroup();
		assignGlobalDeviceConfigurationToDeviceGroup(defaultUnassignedGroup);
		root.addChild(defaultUnassignedGroup);
		deviceGroupRepository.update(root);
		return root;
	}

	private void addDefaultGroupIfRequired(HttpServletRequest request, Map<String, Object> deviceGroupMap) {
        List<DeviceGroup> groupList = new ArrayList<DeviceGroup>();
        groupList = (List<DeviceGroup>)deviceGroupRepository.findAll();
        if(groupList.isEmpty()){
        	DeviceGroup rootGroup = getDefaultDeviceGroup();
			groupList.add(rootGroup);
			groupList.addAll(rootGroup.getChildren());
			assignGlobalDeviceConfigurationToDeviceGroup(rootGroup);
			HttpSession session = request.getSession();
			String groupId = String.valueOf(rootGroup.getGroupId());
			session.setAttribute(CURRENT_DEVICE_GROUP_ID, groupId);
			session.setAttribute(DeviceSummaryController.DEVICE_SUMAMRY_CURRENT_GROUP_ID, groupId);
		}
		deviceGroupMap.put("childGroupCount",groupList.size() - 1);
        deviceGroupMap.put("deviceGroupsSummary", groupList);
	}


	private void assignGlobalDeviceConfigurationToDeviceGroup(DeviceGroup group) {
		WnomConfiguration globalDeviceConfiguration = wnomConfigurationRepository.getGlobalDeviceConfiguration();
		if(globalDeviceConfiguration != null) {
			group.setConfigurationType(WnomConstants.TEMPLATE);
			group.setConfiguration(globalDeviceConfiguration);
		}
	}

	private void assignGlobalUserConfigurationToUserGroup(UserGroup group) {
		WnomConfiguration globalUserConfiguration = wnomConfigurationRepository.getGlobalUserConfiguration();
		if(globalUserConfiguration != null) {
			group.setConfigurationType(WnomConstants.TEMPLATE);
			group.setConfiguration(globalUserConfiguration);
		}
	}

	private void addDefaultDeviceConfigurationIfRequired() {
		WnomConfiguration globalConfiguration = wnomConfigurationRepository.getGlobalDeviceConfiguration();
		if(globalConfiguration == null){
			globalConfiguration = new WnomConfiguration(WnomConfiguration.DEFAULT, WnomConfiguration.DEVICE_CONFIGURATION_TYPE);
			globalConfiguration.setDescription(WnomConfiguration.DEFAULT_DEVICE_CONFIGURATION);
            globalConfiguration.setName(WnomConfiguration.DEFAULT);
			globalConfiguration.setGlobal(true);
			wnomConfigurationRepository.update(globalConfiguration);
		}
	}
	
	private void updateDeviceCount(Collection<DeviceInfo> allDevices, Map<String, Object> dataMap) {
		DeviceGroup defaultGroup = deviceGroupRepository.findDefaultGroup();
		defaultGroup.setDeviceCount((Long)dataMap.get(SystemLogConstant.TOTAL_RECORDS));
		updateDeviceCountProperties(defaultGroup);
		DeviceGroup unAssigned = deviceGroupRepository.findByParentPath(String.valueOf(defaultGroup.getGroupId()),DeviceGroup.DEFAULT_UNASSIGNED);
		unAssigned.setDeviceCount(deviceRepository.findDeviceCountInGroup(DeviceGroup.UNASSIGNED_PATH));
		dataMap.put("defaultGroupId", defaultGroup.getGroupId());
	}

	private void updateDeviceCountProperties(DeviceGroup group) {
		List<DeviceGroup> children = group.getChildren();
		for (DeviceGroup childGroup : children) {
			childGroup.setDeviceCount(deviceRepository.findDeviceCountInGroup(childGroup.getAbsoluteIdPath()));
			updateDeviceCountProperties(childGroup);
		}
	}

	//Setter Injection
	public void setDeviceGroupRepository(IDeviceGroupRepository deviceGroupRepository) {
		this.deviceGroupRepository = deviceGroupRepository;
	}

	public void setDeviceRepository(IDeviceRepository deviceRepository) {
		this.deviceRepository = deviceRepository;
	}

	public void setUserPreferenceRepository(IUserPreferencesRepository userPreferenceRepository) {
		this.userPreferenceRepository = userPreferenceRepository;
	}

	public void setUserGroupRepository(IUserGroupRepository userGroupRepository) {
		this.userGroupRepository = userGroupRepository;
	}

	public void setDeviceUserRepository(IDeviceUserRepository deviceUserRepository) {
		this.deviceUserRepository = deviceUserRepository;
	}

    public void setSubnetRepository(ISubnetRepository subnetRepository) {
        this.subnetRepository = subnetRepository;
    }

	public UserGroup getCurrentUserGroup(HttpServletRequest request) {
		String currentUserGroupId = getCurrentUserGroupId(request, request.getSession());
		return userGroupRepository.findById(Long.valueOf(currentUserGroupId));
	}

	public void setWnomConfigurationRepository(
			IWnomConfigurationRepository wnomConfigurationRepository) {
		this.wnomConfigurationRepository = wnomConfigurationRepository;
	}

}
