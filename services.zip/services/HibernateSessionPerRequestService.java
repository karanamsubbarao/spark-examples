/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 6246 $
Last Modified: $Date: 2006-11-18 14:59:57 +0530 (Sat, 18 Nov 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

/**
 * The default hibernate session service. Obtains a session bound with a request. To be
 * used in conjunction with OpenSessionInViewFilter / OpenSessionInViewInterceptor.
 */
public class HibernateSessionPerRequestService extends AHibernateSessionService {
    private SessionFactory sessionFactory;

    public HibernateSessionPerRequestService(SessionFactory factory) {
        sessionFactory = factory;
    }
    
    protected Session currentSession() {
        return SessionFactoryUtils.getSession(sessionFactory, false);
    }

    public void closeSession() {
        //Do nothing. The OpenSessionInViewFilter / Interceptor closes the session.
    }

	public void closeSessionWithoutFlush() {
		// TODO Do nothing.		
	}

	public void clear() {
		currentSession().clear();
	}
   
}
