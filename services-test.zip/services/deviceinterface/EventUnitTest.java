package com.wyse.rapport.services.deviceinterface;

import org.dom4j.Document;

import com.wyse.rapport.businesslogic.DeviceRequestParser;
import com.wyse.rapport.command.XMLEventFixture;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.UUIDTestCase;
import com.wyse.rapport.util.XmlUtil;

public class EventUnitTest extends UUIDTestCase {

	private DeviceRequestParser parser;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		parser = new DeviceRequestParser();
	}
	
	public void testIsAssetSetEventWhenXmlHasAssetSetEvent() throws Exception {
		Document document = XmlUtil.document(XMLEventFixture.ASSET_REPORT_EVENT);
		assertTrue(new Event(document, parser).isAssetSetEvent());
	}
	
	public void testIsAssetSetEventWhenXmlHasCommandResponse() throws Exception {
		Document document = XmlUtil.document(XMLResultsFixture.responseForUploadImageToServer("123333","454454","1212sdsadasdas"));
		assertFalse(new Event(document, parser).isAssetSetEvent());
		
		document = XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT);
		assertFalse(new Event(document, parser).isAssetSetEvent());
	}
	
}
