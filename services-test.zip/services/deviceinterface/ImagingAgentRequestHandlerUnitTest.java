package com.wyse.rapport.services.deviceinterface;

import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

import org.dom4j.Document;
import org.junit.Before;
import org.junit.Test;

import com.wyse.common.UUIDGenerator;
import com.wyse.rapport.command.ECommandStatus;
import com.wyse.rapport.command.FinalizeUploadImageToServerCommand;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.UploadImageToServerCommand;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.BiosMediaType;
import com.wyse.rapport.db.tbl.CMOSMediaType;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.util.Assertions;
import com.wyse.rapport.util.XmlUtil;

public class ImagingAgentRequestHandlerUnitTest extends EventHandlerTestCase {

	private static final String CHECKSUM = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
	private ImagingAgentRequestHandler handler;
	private Boolean failUploadInvoked = false;
	private Boolean createArchiveInvoked = false;
	@Before
	public void setUp() throws Exception {
		super.setUp();
		handler = new ImagingAgentRequestHandler(deviceRepository, deviceCommunicationService, systemLogService, 3600, "192.168.1.2"){
			@Override
			protected String md5Checksum(ICommand command) {
				return CHECKSUM;
			}
			
			@Override
			protected DeviceInfo failUploadImage(DeviceInfo device, ICommand command, Writer writer) {
				failUploadInvoked = true;
				return device;
			}
			
			@Override
			void createArchive(DeviceInfo device, Task task) {
				createArchiveInvoked = true;
			}
		};
	}
	
	@Test
	public void testUploadImageCommandIsFailedWhenChecksumNotMatching() throws Exception {
		DeviceInfo device = createDeviceWithUploadImageCommands();
		List<ICommand> commands = device.getCurrentTask().getCommands();
		Document document = XmlUtil.document(XMLResultsFixture.responseForUploadImageToServer(device.getDeviceGuid(), commands.get(0).getCommandGuid(), "Invalid"+CHECKSUM));
		Event event = event(document);
		StringWriter writer = new StringWriter();
		
		handler.handleRequest(document, event, writer);
		evict();
		
		assertTrue(failUploadInvoked);
	}

	@Test
	public void testCreateArchiveIsInovkedOnlyWhenNextCommandIsFinalizeUploadImageCommand() throws Exception {
		DeviceInfo device = createDeviceWithUploadImageCommands();
		List<ICommand> commands = device.getCurrentTask().getCommands();
		Document document = XmlUtil.document(XMLResultsFixture.responseForUploadImageToServer(device.getDeviceGuid(), commands.get(0).getCommandGuid(), CHECKSUM));
		Event event = event(document);
		StringWriter writer = new StringWriter();
		
		handler.handleRequest(document, event, writer);
		assertFalse(failUploadInvoked);
		assertFalse(createArchiveInvoked);
		evict();
		
		document = XmlUtil.document(XMLResultsFixture.responseForUploadImageToServer(device.getDeviceGuid(), commands.get(1).getCommandGuid(), CHECKSUM));
		event = event(document);		
		writer = new StringWriter();
		handler.handleRequest(document, event, writer);
		evict();
		assertFalse(failUploadInvoked);
		assertTrue(createArchiveInvoked);
	}

	@Test
	public void testCommandCompletionInTaskAfterSuccessFullExecution() throws Exception {
		DeviceInfo device = createDeviceWithUploadImageCommands();
		
		List<ICommand> commands = device.getCurrentTask().getCommands();
		Document document = XmlUtil.document(XMLResultsFixture.responseForUploadImageToServer(device.getDeviceGuid(), commands.get(0).getCommandGuid(), CHECKSUM));

		Event event = event(document);
		StringWriter writer = new StringWriter();
		
		handler.handleRequest(document, event, writer);
		evict();
		 
		DeviceInfo retrieved = deviceRepository.findByGuid(device.getDeviceGuid());
		
		List<ICommand> retrievedCommands = retrieved.getCurrentTask().getCommands();
		assertEquals(3, retrievedCommands.size());
		assertEquals(ECommandStatus.COMPLETE, retrievedCommands.get(0).getCmdStatus());
		Assertions.assertHasString(UploadImageToServerCommand.COMMAND_NAME, writer.toString());
		
		document = XmlUtil.document(XMLResultsFixture.responseForUploadImageToServer(device.getDeviceGuid(), commands.get(1).getCommandGuid(), CHECKSUM));

		event = event(document);
		writer = new StringWriter();
		
		handler.handleRequest(document, event, writer);
		evict();
		 
		retrieved = deviceRepository.findByGuid(device.getDeviceGuid());
		assertEquals(3, retrievedCommands.size());
		assertEquals(ECommandStatus.COMPLETE, retrievedCommands.get(0).getCmdStatus());
		assertEquals(ECommandStatus.COMPLETE, retrievedCommands.get(1).getCmdStatus());
		Assertions.assertHasString(FinalizeUploadImageToServerCommand.COMMAND_NAME, writer.toString());
	}

	private DeviceInfo createDeviceWithUploadImageCommands() {
		DeviceInfo device = device("xxx");
		device.setDialogGuid(new UUIDGenerator().generate());
		Task task = new Task("Upload Command Task");
		task.addCommand(new UploadImageToServerCommand("http://localhost:8080/test_bios.img", BiosMediaType.TYPE));
		task.addCommand(new UploadImageToServerCommand("http://localhost:8080/test_cmos.img", CMOSMediaType.TYPE));
		task.addCommand(new FinalizeUploadImageToServerCommand());
		device.addTask(task, 0);
		deviceRepository.createOrUpdate(device);
		evict();
		return device;
	}
}
