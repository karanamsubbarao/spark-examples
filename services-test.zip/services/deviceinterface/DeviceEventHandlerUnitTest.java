/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
 */

package com.wyse.rapport.services.deviceinterface;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;

import com.wyse.common.MacIDGenerator;
import com.wyse.rapport.command.GetAssetsCommand;
import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.XMLCommandsFixture;
import com.wyse.rapport.command.XMLEventFixture;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.configuration.UserPreference;
import com.wyse.rapport.db.tbl.BiosMediaType;
import com.wyse.rapport.db.tbl.CMOSMediaType;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.db.tbl.EERomMediaType;
import com.wyse.rapport.db.tbl.IDEMediaType;
import com.wyse.rapport.db.tbl.PartitionInfo;
import com.wyse.rapport.db.tbl.Schedule;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.util.Assertions;
import com.wyse.rapport.util.WDMConstants;
import com.wyse.rapport.util.XmlUtil;

public class DeviceEventHandlerUnitTest extends EventHandlerTestCase {
	private DeviceEventHandler deviceEventHandler;

	protected void setUp() throws Exception {
		super.setUp();
		deviceEventHandler = new DeviceEventHandler(sessionService, userPreferencesRepository, deviceRepository,deviceCommunicationService);
		UserPreferences preferences = new UserPreferences();
		userPreferencesRepository.createOrUpdate(preferences);
		evict();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		UserPreferences preferences = new UserPreferences();
		userPreferencesRepository.createOrUpdate(preferences);
		evict();
	}

	public void testEventWithNoGuid() throws Exception {
		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLResultsFixture.RESULT_WITHOUT_GUID), writer);

		Assertions.assertHasString(XMLCommandsFixture.SET_DEVICE_GUID, writer.toString());
	}

	public void testEventWithGuidWithNoDeviceWhenDeviceNotInDB() throws Exception {
		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(GET_ASSETS_RESULT_NO_ERROR), writer);
		Assertions.assertHasString(XMLCommandsFixture.SET_MONITOR_SERVER_COMMAND, writer.toString());
	}

	public void testEventWithMinimalAssetWithGuidWhenDeviceNotInDB() throws Exception {
		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLResultsFixture.minimalAsset(MessageConstants.Values.BOGUS_GUID)), writer);

		Assertions.assertHasString(XMLCommandsFixture.SET_MONITOR_SERVER_COMMAND, writer.toString());
	}

	public void testEventWithMinimalAssetWithGuidWhenDeviceInDB() throws Exception {
		String minimalAsset = XMLResultsFixture.minimalAsset(MessageConstants.Values.BOGUS_GUID);

		DeviceInfo deviceInfo = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.fullAsset(MessageConstants.Values.BOGUS_GUID,WDMConstants.BOGUS_MAC,"1.2.2.3",1));
		deviceRepository.create(deviceInfo);
		evict();

		StringWriter writer = new StringWriter();

		deviceEventHandler.handleRequest(XmlUtil.document(minimalAsset), writer);

		Assertions.assertNotHasString(XMLCommandsFixture.SET_SERVER_COMMAND, writer.toString());
		Assertions.assertHasString(XMLCommandsFixture.NO_COMMANDS, writer.toString());
	}

	public void testEventWithFullAssetWithGuidWhenDeviceNotInDB() throws Exception {
		StringWriter writer = new StringWriter();
		String fullAssetReport = XMLResultsFixture.fullAssetReport(MessageConstants.Values.BOGUS_GUID, MacIDGenerator.nextMacID(), "192.168.1.2");
		deviceEventHandler.handleRequest(XmlUtil.document(fullAssetReport), writer);

		Assertions.assertHasString(XMLCommandsFixture.NO_COMMANDS, writer.toString());
	}

	public void testEventWithBootAssetReport() throws Exception {
		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLEventFixture.BOOT_ASSET_REPORT_EVENT), writer);

		Assertions.assertHasString(GetAssetsCommand.FULL, writer.toString());
	}

	public void testEventWithGuidAndDeviceWhenNoPendingCommands() throws Exception {
		DeviceInfo device = new DeviceFixture().createDeviceWithCommand(
				XMLResultsFixture.fullAsset(EventHandlerTestCase.GUID,EventHandlerTestCase.MAC,"1.1.1.1",1), new GetAssetsCommand("minimal"));
		deviceRepository.createOrUpdate(device);
		evict();

		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLResultsFixture.RESULT_WITH_NO_ERROR_WITH_DEVICE), writer);
		String commandWritten = writer.toString();

		Assertions.assertHasString(XMLCommandsFixture.START_DIALOG_FROM_SERVER, commandWritten);

		writer = reset(writer);

		deviceEventHandler.handleRequest(XmlUtil.document(commandExecutionResult(commandWritten)), writer);
		Assertions.assertHasString(XMLCommandsFixture.GET_ASSETS_COMMAND, writer.toString());
	}


	public void testSendsNextCommandWhenCurrentCommandSucceeds() throws Exception {
		//Create a device with two tasks - a minimal checkin, followed by a reboot.
		DeviceInfo device = new DeviceFixture().createDeviceWithCommand(
				XMLResultsFixture.fullAsset(EventHandlerTestCase.GUID,EventHandlerTestCase.MAC,"1.1.1.1",1), new GetAssetsCommand("minimal"));
		device.reboot(0);
		deviceRepository.createOrUpdate(device);
		evict();

		StringWriter writer = new StringWriter();
		//simulate handling the minimal checkin.
		deviceEventHandler.handleRequest(XmlUtil.document(XMLEventFixture.minimalAssetReportEvent(device.getDeviceGuid(), device.getActiveMac(), device.getActiveIp())), writer);
		String commandWritten = writer.toString();

		Assertions.assertHasString(XMLCommandsFixture.START_DIALOG_FROM_SERVER, commandWritten);

		writer.flush();
		writer.getBuffer().setLength(0);
		//Check whether the event handler sends the next task in the queue - ie, a GET_ASSETS_COMMAND command.
		deviceEventHandler.handleRequest(XmlUtil.document(commandExecutionResult(device.getDeviceGuid(), commandWritten)), writer);
		Assertions.assertHasString(XMLCommandsFixture.GET_ASSETS_COMMAND, writer.toString());

		commandWritten = writer.toString();

		writer.flush();
		writer.getBuffer().setLength(0);
		//Check whether the event handler sends the next task in the queue - ie, a reboot command.
		deviceEventHandler.handleRequest(XmlUtil.document(commandExecutionResult(device.getDeviceGuid(), commandWritten)), writer);
		Assertions.assertHasString(XMLCommandsFixture.REBOOT_COMMAND, writer.toString());
	}

	public void testEventWithCommandError() throws Exception {
		DeviceInfo device = new DeviceFixture().createDeviceWithCommand(
				XMLResultsFixture.FULL_ASSET_REPORT, rebootCommand());
		deviceRepository.createOrUpdate(device);
		evict();

		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(GET_ASSETS_RESULT_WITH_ERROR), writer);
		Assertions.assertHasString(XMLCommandsFixture.REBOOT_COMMAND, writer.toString());
	}

	public void testHandleRequestSendsGetAssetCommandForAssetEventWithEmpltyDevice() throws IOException, DocumentException {
		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLEventFixture.EMPTY_DEVICE_EVENT), writer);
		Assertions.assertHasString(XMLCommandsFixture.SET_MONITOR_SERVER_COMMAND, writer.toString());
	}

	public void testHandlerSendsNextAssetReportIfDeviceHasNoCommands() throws Exception {
		DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.FULL_ASSET_REPORT);
		deviceRepository.createOrUpdate(device);
		evict();
		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLEventFixture.ASSET_REPORT_EVENT), writer);
		Assertions.assertHasString(XMLCommandsFixture.NO_COMMANDS, writer.toString());
	}

	public void testCheckinIntervalConfiguration() throws Exception {
		UserPreferences settings = new UserPreferences();
		settings.setUserPreference(new UserPreference(UserPreferences.CHECKIN_INTERVAL, "12", "Minutes"));
		userPreferencesRepository.createOrUpdate(settings);
		deviceEventHandler = new DeviceEventHandler(sessionService, userPreferencesRepository, deviceRepository,deviceCommunicationService);
		DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.FULL_ASSET_REPORT);
		deviceRepository.createOrUpdate(device);
		evict();
		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLEventFixture.ASSET_REPORT_EVENT), writer);
		Assertions.assertHasString("720", writer.toString());
	}

	public void testCheckinFromANewDeviceFormatsMac() throws Exception {
		String mac = "A3B3CCD34D12".toLowerCase();
		String deviceGuid = MessageConstants.Values.BOGUS_GUID;
		String ip = "192.168.1.2";
		deviceEventHandler.handleRequest(DocumentHelper.parseText(XMLResultsFixture.deviceWithMac(mac, ip, deviceGuid)), new StringWriter(), ip);
		evict();

		DeviceInfo retrievedDevice = deviceRepository.findByGuid(deviceGuid);
		assertEquals("A3:B3:CC:D3:4D:12".toLowerCase(), retrievedDevice.getActiveMac());
	}

	public void testCheckinForSameMacWithDifferentFormat() throws Exception {
		String mac = "A3B3CCD34D12".toLowerCase();
		String deviceGuid = MessageConstants.Values.BOGUS_GUID;
		String ip = "192.168.1.2";
		DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.deviceWithMac(mac.toUpperCase(), ip, deviceGuid));
		deviceRepository.create(device);
		evict();

		deviceEventHandler.handleRequest(DocumentHelper.parseText(XMLResultsFixture.deviceWithMac(mac.toLowerCase(), ip, deviceGuid)), new StringWriter(), ip);
		evict();

		List<DeviceInfo> devices = (List<DeviceInfo>) deviceRepository.findAll();
		assertEquals(1, devices.size());
		assertEquals("A3:B3:CC:D3:4D:12".toLowerCase(), devices.get(0).getActiveMac());
	}

	public void testUpdateActiveNetwork() throws Exception {
		String deviceGuid = MessageConstants.Values.BOGUS_GUID;
		String mac = MacIDGenerator.nextMacID();
		String ip = "192.168.1.2";
		Device device = deviceEventHandler.handleRequest(DocumentHelper.parseText(XMLResultsFixture.fullAssetReport(deviceGuid, mac, ip)), new StringWriter(), ip);
		evict();
		assertEquals(ip, device.getActiveIp());

		mac = MacIDGenerator.nextMacID();
		ip = "192.168.1.3";
		device = deviceEventHandler.handleRequest(DocumentHelper.parseText(XMLResultsFixture.deviceWithMac(mac, ip, deviceGuid)), new StringWriter(), ip);
		evict();
		assertEquals(ip, device.getActiveIp());
	}

	public void testHandlerUpdatesActiveNetworkOnDeviceOnEveryEvent() throws Exception {
		String firstIp = "192.168.1.2";
		Device device = deviceEventHandler.handleRequest(XmlUtil.document(XMLResultsFixture.fullAssetReport(MessageConstants.Values.BOGUS_GUID, MacIDGenerator.nextMacID(), "192.168.1.2")), new StringWriter(), firstIp);
		assertEquals(firstIp, device.getActiveIp());
	}

//	TODO : XSD validation fails for nonAscii hostName

//	public void testCheckinFromAComputerWithNonAsciiUnicodeHostName() throws Exception {
//	Device device = deviceEventHandler.handleRequest(XmlUtil.document(XMLResultsFixture.FULL_ASSET_XP_WITH_UNICODE_COMPUTER_NAME), new StringWriter());
//	assertEquals(XMLResultsFixture.CHINKI_NAME, device.getHostName());
//	}

	public void testCreateOrUpdatesTheLegacyFlagToFalse() throws Exception {
		String macId = MacIDGenerator.nextMacID();
		DeviceInfo device = new DeviceFixture().createDeviceWithNetworks("10.150.5.1", macId);
		device.setLegacy(true);
		deviceRepository.createOrUpdate(device);
		evict();

		assertTrue(deviceRepository.findByGuid(device.getDeviceGuid()).isLegacy());

		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLResultsFixture.fullAssetReport(device.getDeviceGuid(), macId, "10.150.2.20")), writer, "10.150.2.20");

		assertFalse(deviceRepository.findByGuid(device.getDeviceGuid()).isLegacy());
	}

	public void testUpdatesDeviceWithTasksExistingInDBWhenDeviceChecksInWithFullAsset() throws DocumentException {
		String macId = MacIDGenerator.nextMacID();
		String ip = "10.150.5.1";
		DeviceInfo device = new DeviceFixture().createDeviceWithNetworks(ip, macId);
		device.installOnDevice("testApplication", Schedule.now(), 0, false);
		deviceRepository.createOrUpdate(device);
		evict();
		StringWriter writer = new StringWriter();
		deviceEventHandler.handleRequest(XmlUtil.document(XMLResultsFixture.fullAssetReport(device.getDeviceGuid(), macId, ip)), writer);
		evict();

		assertEquals(deviceRepository.findByGuid(device.getDeviceGuid()), device);
	}

	public void testFullAssetReportWithWriteableMediaStatus() throws Exception {
		DeviceInfo device = new DeviceInfo();
		device.setDeviceGuid(MessageConstants.Values.BOGUS_GUID);
		DeviceNetworkInfo network=new DeviceNetworkInfo();
		network.setMacAddress(WDMConstants.BOGUS_MAC);
		device.addDeviceNetwork(network);
		device.getActiveNetwork().setIpAddress("10.150.2.2");
		deviceRepository.createOrUpdate(device);
		evict();

		StringWriter writer = new StringWriter();
		String mac=StringUtils.remove(device.getActiveMac(),":").toLowerCase();
		DeviceInfo retrievedDevice = deviceEventHandler.handleRequest(XmlUtil.document(XMLResultsFixture.fullAssetReport(device.getDeviceGuid(),mac,device.getActiveIp())),writer);
		assertNotNull(retrievedDevice);
		IDEMediaType ide=device.getActiveIDEMediaType();
		CMOSMediaType cmos=device.getCMOSMediaType();
		BiosMediaType bios=device.getBiosMediaType();
		EERomMediaType eerom=device.getEERomMediaType();

		assertMediaType(ide,2, 1, 0, "wysefs", true,"configuration",100,1000);

		assertEquals(10020,bios.getSize());
		assertEquals(10021,cmos.getSize());
		assertEquals(10022,eerom.getSize());
	}

	private void assertMediaType(IDEMediaType mediaType, int channel, int drive, int number, String fileSystem, boolean active, String partitionDataType, long start, long extent) {
		assertNotNull(mediaType);
		assertEquals(channel,mediaType.getChannel());
		assertEquals(drive,mediaType.getActiveDriveNumber());
		PartitionInfo partitionInfo=mediaType.getPartitionInfoCollection().iterator().next();
		assertEquals(number,partitionInfo.getNumber());
		assertEquals(active,partitionInfo.isActive());
		assertEquals(fileSystem,partitionInfo.getFileSystem());
		assertEquals(partitionDataType,partitionInfo.getPartitionDataType());
		assertEquals(start,partitionInfo.getStart());
		assertEquals(extent,partitionInfo.getExtent());
	}

	private String commandExecutionResult(String commandWritten) {
		String commandGuid = XMLCommandsFixture.commandGuid(commandWritten);
		return XMLResultsFixture.successForCommand(GUID, "getAssets", commandGuid);
	}

	private String commandExecutionResult(String deviceGuid, String commandWritten) {
		String commandGuid = XMLCommandsFixture.commandGuid(commandWritten);
		return XMLResultsFixture.successForCommand(deviceGuid, "getAssets", commandGuid);
	}
	private StringWriter reset(StringWriter writer) throws IOException {
		writer.flush();
		writer.close();
		writer = new StringWriter();
		return writer;
	}

}
