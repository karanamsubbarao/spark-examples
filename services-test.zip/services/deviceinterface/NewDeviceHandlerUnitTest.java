/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.StringWriter;
import java.util.Collection;

import org.dom4j.Document;

import com.wyse.common.MacIDGenerator;
import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.RebootCommand;
import com.wyse.rapport.command.XMLCommandsFixture;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.util.Assertions;
import com.wyse.rapport.util.XmlUtil;

public class NewDeviceHandlerUnitTest extends EventHandlerTestCase {
    NewDeviceHandler newDeviceHandler;
    private String deviceGuid = MessageConstants.Values.BOGUS_GUID;

    protected void setUp() throws Exception {
        super.setUp();
        newDeviceHandler = new NewDeviceHandler(deviceRepository, systemLogService, 60, deviceCommunicationService);
    }

    public void testHasGuid() throws Exception {
        assertFalse(newDeviceHandler.hasGuid(XmlUtil.document(XMLResultsFixture.RESULT_WITHOUT_GUID)));
        assertTrue(newDeviceHandler.hasGuid(XmlUtil.document(GET_ASSETS_RESULT_NO_ERROR)));
    }

    public void testHasMinimalAsset() throws Exception {
        assertTrue(newDeviceHandler.hasMinimalAsset(XmlUtil.document(XMLResultsFixture.EMPTY_DEVICE_EVENT)));
        assertTrue(newDeviceHandler.hasMinimalAsset(XmlUtil.document(XMLResultsFixture.result("deviceGuid1234", "someCommand", "comGuid123", "no_error", null))));
        assertTrue(newDeviceHandler.hasMinimalAsset(XmlUtil.document(GET_ASSETS_RESULT_NO_ERROR)));
        assertFalse(newDeviceHandler.hasMinimalAsset(XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT)));
    }

    public void testHasSetServerResultWithDevice() throws Exception {
        assertFalse(newDeviceHandler.hasSetGuidResult(XmlUtil.document(XMLResultsFixture.minimalAsset("1111111111"))));
        assertTrue(newDeviceHandler.hasSetGuidResult(XmlUtil.document(XMLResultsFixture.setDeviceGuidResult("12121", "xxxxxxx"))));
    }

    public void testExistingDevice() throws Exception {
        assertFalse(newDeviceHandler.existingDevice(XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT)));

        DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.FULL_ASSET_REPORT);
        deviceRepository.create(device);
        evict();

        assertTrue(newDeviceHandler.existingDevice(XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT)));
    }

    public void testIsFullAssetRequired() throws Exception {
        assertFalse(newDeviceHandler.isFullAssetRequired(XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT)));
        assertTrue(newDeviceHandler.isFullAssetRequired(XmlUtil.document(XMLResultsFixture.minimalAsset(deviceGuid))));

        DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.fullAssetReport(deviceGuid, "00:12:13:80:88:12", "192.168.1.2"));
        deviceRepository.create(device);
        evict();

        assertFalse(newDeviceHandler.isFullAssetRequired(XmlUtil.document(XMLResultsFixture.minimalAsset(deviceGuid))));
    }

    public void testHandleRequestSendsSetServerForXMLWithNoGuid() throws Exception {
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.RESULT_WITHOUT_GUID);
		newDeviceHandler.handleRequest(document, event(document), writer);

        Assertions.assertHasString(XMLCommandsFixture.SET_DEVICE_GUID, writer.toString());
        Assertions.assertHasString("<deviceGuid>", writer.toString());
    }

    public void testHandleRequestRequestsForFullAssetForSetDEviceGuidResult() throws Exception {
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.setDeviceGuidResult("12121", "yyyyyyyyy"));
		newDeviceHandler.handleRequest(document, event(document), writer);

        Assertions.assertHasString(XMLCommandsFixture.SET_MONITOR_SERVER_COMMAND, writer.toString());
    }

    public void testHandleRequestSendsGetAssetsWithFullForXmlWithMinimalAssetWhenDeviceNotInDb() throws Exception {
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.minimalAsset(deviceGuid));
		newDeviceHandler.handleRequest(document, event(document), writer);

        Assertions.assertHasString(XMLCommandsFixture.SET_MONITOR_SERVER_COMMAND, writer.toString());
        Assertions.assertHasString("<assetLevel>full</assetLevel>", writer.toString());
    }

    public void testHandleRequestCallNextHandlerForXmlHasMinimalAssetAndDeviceExistsInDb() throws Exception {
        StringWriter writer = new StringWriter();
        
        DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.fullAsset(deviceGuid,MAC,"1.1.1.1",1));
        deviceRepository.create(device);
        evict();

        Document document = XmlUtil.document(XMLResultsFixture.minimalAsset(deviceGuid));
        Event event = event(document);
        mockNextHandler(newDeviceHandler, document, event, writer);
		newDeviceHandler.handleRequest(document, event, writer);
        Assertions.assertNotHasString(XMLCommandsFixture.SET_SERVER_COMMAND, writer.toString());
    }

    public void testHandleRequestCallNextHandlerForXmlHasFullAssetAndNoDeviceExistsInDb() throws Exception {
        StringWriter writer = new StringWriter();
        
        Document document = XmlUtil.document(XMLResultsFixture.fullAssetReport(deviceGuid, MacIDGenerator.nextMacID(), "192.168.1.2"));
        Event event = event(document);
        mockNextHandler(newDeviceHandler, document, event, writer);
		newDeviceHandler.handleRequest(document, event, writer);
		
        Assertions.assertNotHasString(XMLCommandsFixture.SET_SERVER_COMMAND, writer.toString());
    }

    public void testHandleRequestIfXmlHasFullAssetAndDeviceExistsInDB() throws Exception {
        StringWriter writer = new StringWriter();
        String fullAsset = XMLResultsFixture.fullAssetReport(deviceGuid, MacIDGenerator.nextMacID(), "192.168.1.2");

        DeviceInfo device = new DeviceFixture().createDeviceFromXml(fullAsset);
        deviceRepository.create(device);
        evict();

        Document document = XmlUtil.document(fullAsset);
        Event event = event(document);
        mockNextHandler(newDeviceHandler, document, event, writer);
		newDeviceHandler.handleRequest(document, event, writer);
		
        Assertions.assertNotHasString(XMLCommandsFixture.SET_SERVER_COMMAND, writer.toString());
    }

    public void testHandleRequestSetsTheExistingDeviceGuidForSetServerWhenDeviceWithSameMacAlreadyExistsInDB() throws Exception {
        String macId = MacIDGenerator.nextMacID();
        DeviceInfo device1 = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.fullAssetReport(deviceGuid, macId, "192.168.1.2"));
        deviceRepository.create(device1);
        evict();

        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.fullAssetReport("", macId, "192.168.1.2"));
		DeviceInfo device2 = newDeviceHandler.handleRequest(document, event(document), writer);
        assertNull(device2);
        Assertions.assertHasString(XMLCommandsFixture.SET_DEVICE_GUID, writer.toString());
        Assertions.assertHasString(device1.getDeviceGuid(), writer.toString());
    }

	public void testDeepCloningOfDevice() throws Exception {
		assertEquals(0, deviceRepository.findAll().size());
        DeviceInfo existingDevice = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.fullAssetReport(deviceGuid, MacIDGenerator.nextMacID(), "192.168.1.2"));
        Task task=new Task("Reboot");
        task.addCommand(new RebootCommand());
        existingDevice.addTask(task, 1);
        deviceRepository.create(existingDevice);
        
        Document document = XmlUtil.document(XMLResultsFixture.fullAssetReport(MessageConstants.Values.BOGUS_DIALOG_GUID, MacIDGenerator.nextMacID(), "192.168.1.2"));
        DeviceInfo newDevice = newDeviceHandler.createNewDevice(existingDevice, document);
        Collection<DeviceInfo> devices = deviceRepository.findAll();
		assertEquals(1, devices.size());
        assertNull(deviceRepository.findByGuid(deviceGuid));
        assertEquals("Reboot", newDevice.getTasks().get(0).getName());
        assertNotSame(deviceGuid,newDevice.getDeviceGuid());
	}
 
    
}