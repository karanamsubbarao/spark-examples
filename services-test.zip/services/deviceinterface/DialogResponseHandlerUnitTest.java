/*
 Copyright (c) Wyse Technology, Inc.
 
 Current Revision: $Rev: 5382 $
 Last Modified: $Date: 2006-09-19 17:33:17 +0530 (Tue, 19 Sep 2006) $
 Last Modified By: $Author: smariswamy $
 */
package com.wyse.rapport.services.deviceinterface;

import java.io.StringWriter;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;

import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.util.XmlUtil;


public class DialogResponseHandlerUnitTest extends EventHandlerTestCase{

	private static final String DIALOG_COMMAND_GUID = "12345";
	private DialogResponseHandler handler;
	
	protected void setUp() throws Exception {
		super.setUp();
		handler=new DialogResponseHandler(deviceRepository,systemLogService,deviceCommunicationService, 60);
	}
	
	public void testDialogGuidIsNullOnReceiveOfErrorResultWithDifferentDialogAndCommandGuid() throws Exception {
		DeviceInfo device=createDeviceWithIPAndMac();
		device.setDialogGuid(DIALOG_COMMAND_GUID);
		StringWriter writer = new StringWriter();
		Document document = XmlUtil.document(XMLResultsFixture.errorResult(device.getDeviceGuid(),"some different guid","error","error message"));
		Event event = event(document);
		mockNextHandler(handler,document,event, writer);
		
		handler.handleRequest(document,event, writer);
		assertTrue(StringUtils.isBlank(writer.toString()));
	}
	
	public void testDialogGuidIsNullOnReceiveOfEndDialogSuccess() throws Exception {
		DeviceInfo device=createDeviceWithIPAndMac();
		device.setDialogGuid(DIALOG_COMMAND_GUID);
		StringWriter writer = new StringWriter();
		Document document = XmlUtil.document(XMLResultsFixture.successResult(device.getDeviceGuid(),MessageConstants.Commands.END_DIALOG,DIALOG_COMMAND_GUID));
		DeviceInfo retrievedDevice = handler.handleRequest(document,event(document), writer);
		assertNull(retrievedDevice.getDialogGuid());
	}
	
	public void testDeviceStatusWhenXMLHasNo_Dialog_guid_ErrorCode() throws Exception {
		DeviceInfo device=createDeviceWithIPAndMac();
		device.setDialogGuid(DIALOG_COMMAND_GUID);
		StringWriter writer = new StringWriter();
		Document document = XmlUtil.document(XMLResultsFixture.errorResult(device.getDeviceGuid(), DIALOG_COMMAND_GUID, MessageConstants.ErrorCodes.NO_DIALOG_GUID, MessageConstants.ErrorCodes.NO_DIALOG_GUID));
		DeviceInfo retrievedDevice = handler.handleRequest(document,event(document), writer);
		assertEquals(DeviceDisplayStatus.BUSY, retrievedDevice.getStatus(null));
	}
	
	
	public void testDialogGuidIsNullOnReceiveOfErrorResultWithSameDialogAndCommandGuid() throws Exception {
		DeviceInfo device=createDeviceWithIPAndMac();
		device.setDialogGuid(DIALOG_COMMAND_GUID);
		StringWriter writer = new StringWriter();
		Document document = XmlUtil.document(XMLResultsFixture.errorResult(device.getDeviceGuid(),DIALOG_COMMAND_GUID,"error","error message"));
		DeviceInfo retrievedDevice = handler.handleRequest(document,event(document), writer);
		assertEquals(DeviceDisplayStatus.ACTIVE.toString(), retrievedDevice.getDisplayStatus());
		assertNull(retrievedDevice.getDialogGuid());
	}
	
}
