/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import junit.framework.TestCase;

public class LegacyDeviceEventHandlerUnitTest extends TestCase {
    public void testIsLegacyRequestForValidRequest() {
        LegacyDeviceEventHandler ldeh = new LegacyDeviceEventHandler(null, null, null);
        assertTrue(ldeh.isLegacyRequest("&v01|whatever"));
        assertTrue(ldeh.isLegacyRequest("&V01|whatever"));
    }

    public void testIsLegacyRequestForInvalidRequest() {
        LegacyDeviceEventHandler ldeh = new LegacyDeviceEventHandler(null, null, null);
        assertFalse(ldeh.isLegacyRequest("&u01|whatever"));
    }
}
