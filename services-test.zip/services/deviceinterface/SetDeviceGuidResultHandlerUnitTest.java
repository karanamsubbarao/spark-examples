/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.StringWriter;

import org.dom4j.Document;

import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.RebootCommand;
import com.wyse.rapport.command.SetMonitorServerCommand;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.persistence.DeviceRepository;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.util.Assertions;
import com.wyse.rapport.util.XmlUtil;

public class SetDeviceGuidResultHandlerUnitTest extends EventHandlerTestCase {
    private static final String COMMAND_GUID = "xxxxxxxxxxx";
    private static final String DEVICE_GUID = "deviceGuid12345";
    private SetDeviceGuidResultHandler handler;
    private IDeviceRepository deviceRepository;

    protected void setUp() throws Exception {
        super.setUp();
        deviceRepository = new DeviceRepository(sessionService);
        handler = new SetDeviceGuidResultHandler(deviceRepository, deviceCommunicationService,
                                                 systemLogService, 9999);
    }

    public void testDeviceSendsValidGuidAfterSuccessfullySetOnDevice() throws Exception {
        createDevice();
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.setDeviceGuidResult(DEVICE_GUID, COMMAND_GUID));
		handler.handleRequest(document, event(document), writer);
        Assertions.assertHasString(SetMonitorServerCommand.COMMAND_NAME, writer.toString());
    }

    public void testHandleRequestWhenDeviceSendsBackInvalidGuidBackInTheREsult() throws Exception {
        DeviceInfo device = createDevice();
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.setDeviceGuidResult("invalid12345", COMMAND_GUID));
		handler.handleRequest(document, event(document), writer);
        ICommand nextCommand = device.nextCommand();
        assertEquals(nextCommand.getCommandName(), RebootCommand.COMMAND_NAME);
        Assertions.assertHasString(SetMonitorServerCommand.COMMAND_NAME, writer.toString());
    }

    private DeviceInfo createDevice() {
        DeviceInfo device = new DeviceFixture().createDeviceWithNetworks("10.150.2.10", "11:22:33:44:55:66");
        device.setDeviceGuid(DEVICE_GUID);
        device.reboot(0);
        deviceRepository.createOrUpdate(device);
        evict();
        return device;
    }
}
