/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 2440 $
Last Modified: $Date: 2005-11-15 17:57:51 +0530 (Tue, 15 Nov 2005) $
Last Modified By: $Author: myadav $
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.Writer;

import org.dom4j.Document;
import org.jmock.Mock;

import com.wyse.common.MacIDGenerator;
import com.wyse.rapport.businesslogic.DeviceRequestParser;
import com.wyse.rapport.command.DeleteDirectoryCommand;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.RebootCommand;
import com.wyse.rapport.command.XMLCommandsFixture;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.RapportDBTestCase;
import com.wyse.rapport.services.command.DeviceCommunicationService;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.persistence.DeviceRepository;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.services.persistence.SystemLogService;
import com.wyse.rapport.services.persistence.UserPreferencesRepository;

public class EventHandlerTestCase extends RapportDBTestCase {
    protected IDeviceCommunicationService deviceCommunicationService;
    protected Mock mockNextEventHandler;
    protected IDeviceRepository deviceRepository;
    protected ISystemLogService systemLogService;
    protected IHibernateSessionService hibernateSessionPerThreadService;
    protected IUserPreferencesRepository userPreferencesRepository;
    public final static String GUID = MessageConstants.Values.BOGUS_GUID;
    public static String COMMAND_GUID = "200";
    public static String RESULT_CODE = "";
    protected static final String MAC = "112233445500";
    static final String MAC_ID = MacIDGenerator.nextMacID();
    public static final String REBOOT_RESULT = XMLResultsFixture.result(GUID, "reboot", COMMAND_GUID, "success", null);
    public static final String GET_ASSETS_RESULT_NO_ERROR = XMLResultsFixture.successForCommand(GUID, "getAssets", "9ef47a00395011da8d86000f1ff8e5aa");
    public static final String GET_ASSETS_RESULT_WITH_ERROR = XMLResultsFixture.errorForCommand(GUID, "getAssets", "9ef47a00395011da8d86000f1ff8e5aa");
    public static final String DELETE_DIRECTORY_COMMAND = XMLCommandsFixture.deleteDirectory("bc6699e05b2111dab84d112233445566", "test");

    protected void setUp() throws Exception {
        super.setUp();
        this.hibernateSessionPerThreadService = sessionService;
        deviceCommunicationService = new DeviceCommunicationService();
        
        deviceRepository = new DeviceRepository(sessionService);
        userPreferencesRepository = new UserPreferencesRepository(sessionService);
        systemLogService = new SystemLogService(sessionService);
        
        systemLogService.deleteAll();
        evict();
        
        mockNextEventHandler = mock(IEventHandler.class);
    }
    
    @Override
    protected void tearDown() throws Exception {
    	super.tearDown();
        systemLogService.deleteAll();
        evict();
    }

    public ICommand rebootCommand() {
        return new RebootCommand();
    }

    protected ICommand deleteDirectoryCommand() {
        return new DeleteDirectoryCommand();
    }

    protected String commandGuid(Document document) {
        return new DeviceRequestParser().commandGuid(document);
    }

    protected String commandResult(String commandGuid, String resultCode) {
        return XMLResultsFixture.result(GUID, "XXXX", commandGuid, resultCode, "");
    }
    
	public DeviceInfo createDeviceWithIPAndMac() {
		DeviceInfo device=new DeviceFixture().createDeviceWithNetworks("10.150.2.1","11:44:33:44:55:66");
    	device.setDeviceGuid("EventHandlerDeviceGuid");
    	deviceRepository.create(device);
    	evict();
    	return device;
	}

	protected void mockNextHandler(IEventHandler handler, Document document, Event event, Writer writer) {
	    handler.precedes((IEventHandler) mockNextEventHandler.proxy());
	    mockNextEventHandler.expects(once()).method("handleRequest").with(eq(document), eq(event), eq(writer));
	}
    
	protected Event event(Document document) {
		return new Event(document, new DeviceRequestParser());
	}

}
