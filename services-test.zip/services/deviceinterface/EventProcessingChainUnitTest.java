/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

public class EventProcessingChainUnitTest extends MockObjectTestCase {
    private Mock mockNewDeviceHandler;
    private Mock mockDeviceBootHandler;
    private Mock mockValidCommandHandler;
    private Mock mockCommandErrorHandler;
    private Mock mockUserConfirmationHandler;
    private Mock mockExecuteOnDeviceHandler;
    private IEventHandler newDeviceHandler;
    private IEventHandler validCommandHandler;
    private IEventHandler commandErrorHandler;
    private IEventHandler deviceBootHandler;
    private IEventHandler userConfirmationHandler;
    private IEventHandler executeOnDeviceHandler;

    protected void setUp() throws Exception {
        super.setUp();
        mockNewDeviceHandler = mock(IEventHandler.class);
        mockDeviceBootHandler = mock(IEventHandler.class);
        mockUserConfirmationHandler = mock(IEventHandler.class);
        mockExecuteOnDeviceHandler = mock(IEventHandler.class);
        mockValidCommandHandler = mock(IEventHandler.class);
        mockCommandErrorHandler = mock(IEventHandler.class);

        newDeviceHandler = (IEventHandler) mockNewDeviceHandler.proxy();
        deviceBootHandler = (IEventHandler) mockDeviceBootHandler.proxy();
        userConfirmationHandler = (IEventHandler) mockUserConfirmationHandler.proxy();
        executeOnDeviceHandler = (IEventHandler) mockExecuteOnDeviceHandler.proxy();
        validCommandHandler = (IEventHandler) mockValidCommandHandler.proxy();
        commandErrorHandler = (IEventHandler) mockCommandErrorHandler.proxy();
    }

    public void testCreatesEventProcessingChain() {
        mockNewDeviceHandler.expects(once()).method("precedes").with(eq(deviceBootHandler)).will(returnValue(deviceBootHandler));
        mockDeviceBootHandler.expects(once()).method("precedes").with(eq(userConfirmationHandler)).will(returnValue(userConfirmationHandler));
        mockUserConfirmationHandler.expects(once()).method("precedes").with(eq(executeOnDeviceHandler)).will(returnValue(executeOnDeviceHandler));
        mockExecuteOnDeviceHandler.expects(once()).method("precedes").with(eq(validCommandHandler)).will(returnValue(validCommandHandler));
        mockValidCommandHandler.expects(once()).method("precedes").with(eq(commandErrorHandler)).will(returnValue(commandErrorHandler));
        new EventProcessingChain(newDeviceHandler, deviceBootHandler, userConfirmationHandler, executeOnDeviceHandler,
                                 validCommandHandler, commandErrorHandler);
    }
}
