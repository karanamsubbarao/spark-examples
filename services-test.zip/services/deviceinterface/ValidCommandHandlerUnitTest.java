/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.StringWriter;
import java.util.Date;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.junit.Test;

import com.wyse.common.MacIDGenerator;
import com.wyse.rapport.businesslogic.DeviceRequestParser;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.TasksFactory;
import com.wyse.rapport.command.UninstallFromDeviceCommand;
import com.wyse.rapport.command.XMLCommandsFixture;
import com.wyse.rapport.command.XMLEventFixture;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.util.Assertions;
import com.wyse.rapport.util.WDMConstants;
import com.wyse.rapport.util.XmlUtil;

public class ValidCommandHandlerUnitTest extends EventHandlerTestCase {
    private ValidCommandHandler validCommandHandler;
    
    protected void setUp() throws Exception {
        super.setUp();
        validCommandHandler = new ValidCommandHandler(deviceRepository, deviceCommunicationService, systemLogService, 3600, "192.168.1.2");
    }

    public void testExistingDeviceWhenDeviceWithGivenGuidDoesNotExist() throws DocumentException {
        assertNull(validCommandHandler.existingDevice(XmlUtil.document(XMLResultsFixture.RESULT_WITH_NO_ERROR_WITH_DEVICE)));
    }

    public void testCreateOrUpdateDeviceForMultipleAssertReports() {
        try {
            DeviceInfo device = validCommandHandler.createOrUpdateDevice(XmlUtil.document(XMLResultsFixture.fullAsset(EventHandlerTestCase.GUID,MAC,"1.1.1.1",1)), null);
            validCommandHandler.createOrUpdateDevice(XmlUtil.document(XMLEventFixture.ASSET_REPORT_EVENT), device);
        } catch (Exception e) {
            fail();
        }
    }

    public void testResultWithNoDeviceDoesNotOverwriteDevice() throws Exception {
        DeviceInfo device = validCommandHandler.createOrUpdateDevice(XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT), null);

        evict();
        device = deviceRepository.findByGuid(device.getDeviceGuid());

        validCommandHandler.createOrUpdateDevice(XmlUtil.document(GET_ASSETS_RESULT_NO_ERROR), device);

        DeviceInfo deviceAfterError = deviceRepository.findByGuid(device.getDeviceGuid());
        assertEquals(device, deviceAfterError);
    }

    public void testHandleRequestWithErrorDelegateToNextHandler() throws Exception {
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(GET_ASSETS_RESULT_WITH_ERROR);
        Event event = event(document);
		mockNextHandler(validCommandHandler, document,event, writer);
        validCommandHandler.handleRequest(document, event, writer);
        Assertions.assertNotHasString(XMLCommandsFixture.NO_COMMANDS, writer.toString());
    }

    public void testHandleRequestUpdatesDeviceOnChange() throws Exception {
        String macId = MacIDGenerator.nextMacID();
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.fullAsset(GUID, macId, "1.1.1.1", 1));
		validCommandHandler.handleRequest(document, event(document), writer);
        evict();

        DeviceInfo device = deviceRepository.findByGuid(GUID);
        assertEquals("1.1.1.1", device.getActiveIp());

        Document document2 = XmlUtil.document(XMLResultsFixture.fullAsset(GUID, macId, "2.2.2.2", 1));
		validCommandHandler.handleRequest(document2, event(document2), writer);
        evict();
        assertEquals("2.2.2.2", deviceRepository.findByGuid(GUID).getActiveIp());
    }

    public void testResponseForRebootOrShutdownResult() throws DocumentException {
        DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.FULL_ASSET_REPORT);
        device.reboot(0);
        deviceRepository.createOrUpdate(device);
        String rebootGuid = device.nextCommand().getCommandGuid();
        device.getCurrentTask().start();
        evict();
        
        StringWriter writer = new StringWriter();
		Document document = XmlUtil.document(XMLResultsFixture.result(GUID, "reboot", rebootGuid, "success", null));
		validCommandHandler.handleRequest(document, event(document), writer);
        assertTrue(device.getTasks().isEmpty());
    	assertEquals(new Date(Device.LONG_HEART_BEAT),device.getNextAssetReportExpected());
    }

    public void testExistingDeviceWhenLegacyDeviceWithSameMacAndSameDeviceGuidExists() throws DocumentException {
        DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.FULL_ASSET_REPORT);
        device.setLegacy(true);
        deviceRepository.create(device);
        evict();

        DeviceInfo existingDevice = validCommandHandler.existingDevice(XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT));
        assertTrue(existingDevice != null);
        assertEquals(device, existingDevice);
    }

    public void testHandleRequestUpdatesLegacyToNewDevice() throws DocumentException {
        DeviceInfo device = new DeviceFixture().createDeviceWithNetworks("1.1.1.1", MAC);
        device.setDeviceGuid(GUID);
        device.setLegacy(true);
        deviceRepository.create(device);
        evict();
        assertTrue(device.getDeviceApplications().isEmpty());

        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT);
		DeviceInfo updatedDevice = validCommandHandler.handleRequest(document, event(document), writer);
        assertFalse(updatedDevice.isLegacy());
        assertFalse(updatedDevice.getDeviceApplications().isEmpty());
    }
    
    public void testCommandByCommandGuid() throws Exception {
		DeviceInfo device = new DeviceInfo();
		ICommand command = new UninstallFromDeviceCommand("appName");
		device.addTask(new TasksFactory().createTask(command), 0);
		deviceRepository.createOrUpdate(device);
		evict();
		
		DeviceInfo retrivedDevice = deviceRepository.findByGuid(device.getDeviceGuid());
		assertEquals(command, retrivedDevice.getCommandByGuid(command.getCommandGuid(), 60));
	}
    
    public void testServerSendsValidStartDialogFromServerCommandIfEventWithoutDialogGuidReceivedFromDevice() throws Exception {
    	DeviceInfo device = createDevice();
    	device.reboot(1);
    	assertNull(device.getDialogGuid());
    	StringWriter writer=new StringWriter();
    	Document document = XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT);
    	DeviceInfo retrievedDevice=validCommandHandler.handleRequest(document,event(document), writer);
    	assertNotNull(retrievedDevice.getDialogGuid());
    	Assertions.assertHasString(XMLCommandsFixture.START_DIALOG_FROM_SERVER,writer.toString());
	}

    public void testServerSendsValidEndDialogCommandIfDeviceHasValidDialogGuidAndHasNoCommand() throws Exception {
    	DeviceInfo device = createDevice();
    	device.setDialogGuid(MessageConstants.Values.BOGUS_GUID);
    	StringWriter writer=new StringWriter();
    	Document document = XmlUtil.document(XMLResultsFixture.FULL_ASSET_REPORT);
		DeviceInfo retrievedDevice=validCommandHandler.handleRequest(document,event(document), writer);
    	assertNotNull(retrievedDevice.getDialogGuid());
    	Assertions.assertHasString(XMLCommandsFixture.END_DIALOG,writer.toString());
	}
    
    @Test
	public void testStartDialogEventUpdatesTheDialogGuid() throws Exception {
		Document document = XmlUtil.document(XMLEventFixture.startDialogEvent(MessageConstants.Values.BOGUS_GUID, MessageConstants.Values.BOGUS_DIALOG_GUID ));
		Event event = new Event(document, new DeviceRequestParser());
		
		DeviceInfo device = deviceWithGuid(MessageConstants.Values.BOGUS_GUID);
		device.setDialogGuid(null);
		
		validCommandHandler.createOrUpdateDevice(document, event, device);
		assertNotNull(device.getDialogGuid());
		assertEquals(MessageConstants.Values.BOGUS_DIALOG_GUID, device.getDialogGuid());
	}
    
	private DeviceInfo createDevice() {
		DeviceInfo device=new DeviceFixture().createDeviceWithNetworks("10.150.2.1",WDMConstants.BOGUS_MAC);
    	device.setDeviceGuid(EventHandlerTestCase.GUID);
    	deviceRepository.create(device);
    	evict();
    	return device;
	}
    
}
