/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev: 3462 $$
Last Modified: $$Date: 2005-12-23 09:46:20 +0530 (Fri, 23 Dec 2005) $$
Last Modified By: $$Author: smariswamy $$
*/

package com.wyse.rapport.services.deviceinterface;

import java.io.StringWriter;

import org.dom4j.Document;
import org.dom4j.DocumentException;

import com.wyse.rapport.command.GetAssetsCommand;
import com.wyse.rapport.command.SetMonitorServerCommand;
import com.wyse.rapport.command.XMLEventFixture;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.util.Assertions;
import com.wyse.rapport.util.XmlUtil;

public class OSAgentBootEventHandlerUnitTest extends EventHandlerTestCase {
    OSAgentBootEventHandler osAgentBootHandler;

    protected void setUp() throws Exception {
        super.setUp();
        osAgentBootHandler = new OSAgentBootEventHandler(deviceRepository, systemLogService, 60, null, deviceCommunicationService);
    }

    public void testResponseHasFullAssetCommandIfDeviceHasNoFullAssetCommand() throws Exception {
        StringWriter response = new StringWriter();
        DeviceInfo device = new DeviceFixture().createDeviceWithNetworks("192.168.1.20", XMLEventFixture.MAC);
        device.setDeviceGuid(XMLEventFixture.GUID);
        deviceRepository.createOrUpdate(device);
        Document document = XmlUtil.document(XMLEventFixture.bootAssetReportEvent(device.getDeviceGuid(), XMLEventFixture.MAC));
		osAgentBootHandler.handleRequest(document, event(document), response);
        Assertions.assertHasString(GetAssetsCommand.FULL, response.toString());
    }
    
    public void testResponseAttachFullAssetCommandIfNewDeviceWithBootEventButDoesNotCreateDevice() throws Exception {
        StringWriter response = new StringWriter();
        Document document = XmlUtil.document(XMLEventFixture.bootAssetReportEvent(XMLEventFixture.GUID, XMLEventFixture.MAC));
		osAgentBootHandler.handleRequest(document, event(document), response);
        Assertions.assertHasString(GetAssetsCommand.FULL, response.toString());
        assertNull(deviceRepository.findByGuid(XMLEventFixture.GUID));
    }

    public void testResponseHasFullAssetCommand() throws Exception {
        try {
            StringWriter response = new StringWriter();
            Document document = XmlUtil.document(XMLEventFixture.BOOT_ASSET_REPORT_EVENT);
			osAgentBootHandler.handleRequest(document, event(document), response);
            Assertions.assertHasString(XMLResultsFixture.FULL_ASSET_LEVEL, response.toString());
        } catch (Exception e) {
            fail();
        }
    }

    public void testResponseDoesNotAttachFullAssetCommandIfDeviceAlreadyHasPendingFullAssetCommand() throws Exception {
        StringWriter response = new StringWriter();
        Document document = XmlUtil.document(XMLEventFixture.BOOT_ASSET_REPORT_EVENT);
		DeviceInfo device = osAgentBootHandler.handleRequest(document, event(document), response);
        response = new StringWriter();
        device = osAgentBootHandler.handleRequest(document, event(document), response);
        assertNull(device);
        Assertions.assertHasString(SetMonitorServerCommand.COMMAND_NAME, response.toString());
    }

    public void testHandleEventDelegatesCallToNextHandlerForNonBootAssetReport() throws Exception {
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLEventFixture.ASSET_REPORT_EVENT);
        Event event = event(document);
		mockNextHandler(osAgentBootHandler, document, event, writer);
        osAgentBootHandler.handleRequest(document, event, writer);
        Assertions.assertNotHasString(GetAssetsCommand.FULL, writer.toString());
    }

    public void testHandleEventDelegatesCallToNextHandlerForResults() throws Exception {
        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(XMLResultsFixture.RESULT_WITH_NO_ERROR_WITH_DEVICE);
        Event event = event(document);
        mockNextHandler(osAgentBootHandler, document, event, writer);
        osAgentBootHandler.handleRequest(document, event, writer);
        Assertions.assertNotHasString(GetAssetsCommand.FULL, writer.toString());
    }

    public void testDoesNotSendGuidForNormalBootEvents() throws Exception {
        DeviceInfo device = new DeviceFixture().createDeviceWithSimpleNetworkAdapter(null);
        deviceRepository.create(device);
        StringWriter result = new StringWriter();
        Document document = XmlUtil.document(XMLEventFixture.bootAssetReportEvent(device.getDeviceGuid(), device.getActiveMac()));
		osAgentBootHandler.handleRequest(document, event(document), result);
        assertNewGuidNotPresent(result);
    }

    public void testNoNetworkIntefacesMatchWithDifferentMACFormats() throws Exception {
        DeviceInfo device = constructDevice();
        StringWriter result = new StringWriter();
        handleBootEvent(device, result, device.getActiveMac());
        assertNewGuidNotPresent(result);
    }

    public void testNoNetworkInterfacesMatchWithMacInLowerCaseFormat() throws Exception {
        DeviceInfo device = constructDevice();
        StringWriter result = new StringWriter();
        handleBootEvent(device, result, device.getActiveMac().toLowerCase());
        assertNewGuidNotPresent(result);
    }

    public void testNoNetworkInterfacesMatchWithPlainMacFormat() throws Exception {
        DeviceInfo device = constructDevice();
        StringWriter result = new StringWriter();
        handleBootEvent(device, result, "aab1cdd1eff2");
        assertNewGuidNotPresent(result);
    }

    public void testNoNetworkInterfacesMatchWithMacInLowerAndUpperCaseFormat() throws Exception {
        DeviceInfo device = constructDevice();
        StringWriter result = new StringWriter();
        handleBootEvent(device, result, "aa-b1-cd-D1-eF-f2");
        assertNewGuidNotPresent(result);
    }
   
    private DeviceInfo constructDevice() {
        DeviceInfo device = new DeviceFixture().createDeviceWithSimpleNetworkAdapter(null);
        device.getActiveNetwork().setMacAddress("AA:b1:CD:D1:EF:F2");
        deviceRepository.create(device);
        return device;
    }

    private void assertNewGuidNotPresent(StringWriter result) {
        assertFalse(result.toString().indexOf("<newDeviceGuid>") >= 0);
    }

    private void handleBootEvent(DeviceInfo device, StringWriter result, String mac) throws DocumentException {
        Document document = XmlUtil.document(XMLEventFixture.bootAssetReportEvent(device.getDeviceGuid(), mac));
		osAgentBootHandler.handleRequest(document, event(document), result);
    }

    
}
