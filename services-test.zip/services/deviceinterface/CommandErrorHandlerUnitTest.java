/*
 Copyright (c) 2005 Wyse Technology, Inc.

 Current Revision: $$Rev$$
 Last Modified: $$Date$$
 Last Modified By: $$Author$$
 */

package com.wyse.rapport.services.deviceinterface;

import java.io.StringWriter;
import java.util.List;

import org.dom4j.Document;
import org.jmock.expectation.ExpectationCounter;

import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.RebootCommand;
import com.wyse.rapport.command.XMLCommandsFixture;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.SystemLogService;
import com.wyse.rapport.util.Assertions;
import com.wyse.rapport.util.XmlUtil;

public class CommandErrorHandlerUnitTest extends EventHandlerTestCase {
    CommandErrorHandler commandErrorHandler;

    protected void setUp() throws Exception {
        super.setUp();
        commandErrorHandler = new CommandErrorHandler(deviceRepository,
                                                      systemLogService, 3600, deviceCommunicationService);
    }

    public void testHandleRequestSendsTheFirstCommandInQueue() throws Exception {
        DeviceInfo device = new DeviceFixture().createDeviceWithCommand(
                XMLResultsFixture.FULL_ASSET_REPORT, rebootCommand());
        deviceRepository.createOrUpdate(device);
        evict();

        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(GET_ASSETS_RESULT_WITH_ERROR);
		commandErrorHandler.handleRequest(document, event(document), writer);
        Assertions.assertHasString(XMLCommandsFixture.REBOOT_COMMAND, writer.toString());
        Assertions.assertHasString("</wdmMessage>", writer.toString());
    }

    public void testHandleRequestForBadCommandName() throws Exception {
        DeviceInfo device = deviceWithRebootCommand();
        deviceRepository.createOrUpdate(device);
        evict();

        StringWriter writer = new StringWriter();
        Document document = XmlUtil.document(commandResult(
                "CommandGuid-123", "bad_command_name"));
		commandErrorHandler.handleRequest(document, event(document), writer);
        DeviceInfo retrieved = deviceRepository.findByGuid(device
                .getDeviceGuid());
        List<Task> tasks = retrieved.getTasks();

        assertTrue(tasks.get(0).isFailed());
        Assertions.assertHasString(XMLCommandsFixture.NO_COMMANDS, writer.toString());
    }

    public void testUpdateTaskFailureLogsMessage() throws Exception {
        DeviceInfo device = deviceWithRebootCommand();
        ICommand rebootCommand = device.nextCommand();
        final Document document = XmlUtil.document(commandResult(rebootCommand.getCommandGuid(), "command_error"));
        final ExpectationCounter counter = new ExpectationCounter("error");
        counter.setExpected(1);
        ISystemLogService logger = new SystemLogService(sessionService) {
        	@Override
        	public void error(String msg, com.wyse.rapport.db.tbl.Device device) {
              counter.inc();
              assertEquals(new RebootCommand().failureMessage(document), msg);
        	};
        };

        CommandErrorHandler errorHandler = new CommandErrorHandler(deviceRepository,
                                                                   logger, 3600, deviceCommunicationService);
        errorHandler.updateTaskFailure(device, document, false);
        counter.verify();
    }

    private DeviceInfo deviceWithRebootCommand() {
        DeviceInfo device = new DeviceFixture().createDeviceFromXml(XMLResultsFixture.FULL_ASSET_REPORT);
        device.reboot(0);
        device.incrementTaskStatus();
        return device;
    }
}
