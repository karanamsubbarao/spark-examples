package com.wyse.rapport.services.userGroups;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.wyse.rapport.db.tbl.DeviceUser;
import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.services.persistence.IDeviceUserRepository;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.IUserGroupRepository;
import com.wyse.rapport.services.persistence.IUserRepository;
import com.wyse.rapport.wnom.IWnomConfigurationRepository;
import com.wyse.rapport.wnom.WnomConfiguration;
import com.wyse.rapport.wnom.WnomConfigurationXmlFixture;
import com.wyse.rapport.wnom.WnomConstants;

public class UserGroupServiceUnitTest extends MockObjectTestCase {

	private Mock mockUserGroupRepository;
	private Mock mockDeviceUserRepository;
	private Mock mockSystemLogService;
	private Mock mockWnomConfigurationRepository;
	private Mock mockUserRepository;
	private UserGroupService userGroupService;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		initServiceDependencies();
	}

	private void initServiceDependencies() {
		mockUserGroupRepository = mock(IUserGroupRepository.class);
		mockDeviceUserRepository = mock(IDeviceUserRepository.class);
		mockSystemLogService = mock(ISystemLogService.class);
		mockWnomConfigurationRepository = mock(IWnomConfigurationRepository.class);
		mockUserRepository = mock(IUserRepository.class);
		
		userGroupService = new UserGroupService();
		userGroupService.setDeviceUserRepository((IDeviceUserRepository)mockDeviceUserRepository.proxy());
		userGroupService.setUserGroupRepository((IUserGroupRepository)mockUserGroupRepository.proxy());
		userGroupService.setSystemLogService((ISystemLogService)mockSystemLogService.proxy());
		userGroupService.setUserRepository((IUserRepository)mockUserRepository.proxy());
		userGroupService.setWnomConfigurationRepository((IWnomConfigurationRepository)mockWnomConfigurationRepository.proxy());
	}
	
	public void testResetDeviceUserPassword() throws Exception {
	   Long userId = 250L;
	   DeviceUser user = deviceUser("wyse", userId);
	   mockDeviceUserRepository.expects(once()).method("findUserByUserId").with(eq(userId)).will(returnValue(user));
	   mockDeviceUserRepository.expects(once()).method("update").with(eq(user));
	   userGroupService.resetDeviceUserPassword(userId);
	   assertTrue(user.isPasswordReset());
	}
	
	public void testDeleteUserGroupWithCustomConfiguration() throws Exception {
		Long userId = 250L;
		Long userGroupId = 300L;
		DeviceUser user = deviceUser("wyse", userId);
		UserGroup userGroup = userGroup("wyse-grp", userGroupId);
		user.setParentUserGroupId(userGroupId);
		user.setParentUserGroupName(userGroup.getName());
		
		String customConfigurationName = "WNOM";
		String customConfigurationId = "2000L";
		WnomConfiguration customConfiguration = userConfiguration(customConfigurationName,customConfigurationId);
		mockWnomConfigurationRepository.expects(once()).method("findConfigurationById").with(eq(customConfigurationId)).will(returnValue(customConfiguration));
		userGroupService.assignConfigurationToUserGroup(userGroup, WnomConstants.CUSTOM_USER_CONFIGURATION_TYPE, customConfigurationId);
		assertEquals(WnomConstants.CUSTOM_USER_CONFIGURATION_TYPE, userGroup.getConfigurationType());
		assertEquals(customConfigurationName, userGroup.getConfiguration().getName());
		
		String globalConfigurationId = "1000L";
		
		mockUserGroupRepository.expects(once()).method("findById").with(eq(userGroupId)).will(returnValue(userGroup));
		mockUserGroupRepository.expects(once()).method("update").with(eq(userGroup));
		mockWnomConfigurationRepository.expects(once()).method("findConfigurationById").with(eq(customConfigurationId)).will(returnValue(customConfiguration));
		mockWnomConfigurationRepository.expects(once()).method("getGlobalUserConfiguration").will(returnValue(globalUserConfiguration(globalConfigurationId)));
		mockWnomConfigurationRepository.expects(once()).method("delete").with(eq(customConfiguration));
		mockUserGroupRepository.expects(once()).method("delete").with(eq(userGroup));
		userGroupService.deleteUserGroup(userGroupId);
		assertEquals(WnomConstants.INHERITED, userGroup.getConfigurationType());
		assertEquals(globalConfigurationId, userGroup.getConfiguration().getConfigurationId());
	}
	
	
	public void testDeleteUserGroupWithPreDefinedTemplateConfiguration() throws Exception {
		Long userId = 250L;
		Long userGroupId = 300L;
		DeviceUser user = deviceUser("wyse", userId);
		UserGroup userGroup = userGroup("wyse-grp", userGroupId);
		user.setParentUserGroupId(userGroupId);
		user.setParentUserGroupName(userGroup.getName());
		
		String preDefinedConfigurationName = "WNOM";
		String preDefinedConfigurationId = "2000L";
		WnomConfiguration preDefinedConfiguration = userConfiguration(preDefinedConfigurationName,preDefinedConfigurationId);
		mockWnomConfigurationRepository.expects(once()).method("findConfigurationById").with(eq(preDefinedConfigurationId)).will(returnValue(preDefinedConfiguration));
		userGroupService.assignConfigurationToUserGroup(userGroup, WnomConstants.TEMPLATE, preDefinedConfigurationId);
		assertEquals(WnomConstants.TEMPLATE, userGroup.getConfigurationType());
		assertEquals(preDefinedConfigurationName, userGroup.getConfiguration().getName());
		
		String globalConfigurationId = "1000L";
		
		mockWnomConfigurationRepository.expects(once()).method("getGlobalUserConfiguration").will(returnValue(globalUserConfiguration(globalConfigurationId)));
		mockUserGroupRepository.expects(once()).method("findById").with(eq(userGroupId)).will(returnValue(userGroup));
		mockUserGroupRepository.expects(once()).method("update").with(eq(userGroup));
		mockUserGroupRepository.expects(once()).method("findUserGroupsForConfiguration").with(eq(preDefinedConfiguration)).will(returnValue(new ArrayList<WnomConfiguration>()));
		
		mockWnomConfigurationRepository.expects(once()).method("findConfigurationById").with(eq(preDefinedConfigurationId)).will(returnValue(preDefinedConfiguration));
		mockWnomConfigurationRepository.expects(once()).method("update").with(eq(preDefinedConfiguration));
		
		mockUserGroupRepository.expects(once()).method("delete").with(eq(userGroup));
		userGroupService.deleteUserGroup(userGroupId);
		assertEquals(WnomConstants.INHERITED, userGroup.getConfigurationType());
		assertEquals(globalConfigurationId, userGroup.getConfiguration().getConfigurationId());
	}
	
	public void testDeleteUser() throws Exception {
		Long userId = 250L;
		Long userGroupId = 300L;
		DeviceUser user = deviceUser("wyse", userId);
		UserGroup userGroup = userGroup("wyse-grp", userGroupId);
		user.setParentUserGroupId(userGroupId);
		user.setParentUserGroupName(userGroup.getName());
		
		mockDeviceUserRepository.expects(once()).method("findUserByUserId").with(eq(userId)).will(returnValue(user));
		mockDeviceUserRepository.expects(once()).method("delete").with(eq(user));
		mockSystemLogService.expects(atLeastOnce()).method("info").with(ANYTHING, eq(null));
		mockUserRepository.expects(once()).method("getCurrentAdmin").will(returnValue("Admin"));
		userGroupService.deleteUser(userId);
	}
	
	public void testMoveUsersToGroup() throws Exception {
		UserGroup userGroup1 = userGroup("wyse-grp", 100L);
		DeviceUser deviceUser1 = deviceUser("Subbarao", 10L);
		deviceUser1.setParentUserGroupId(userGroup1.getGroupId());
		deviceUser1.setParentUserGroupName(userGroup1.getName());

		DeviceUser deviceUser2  = deviceUser("Suneetha", 20L);
		deviceUser2.setParentUserGroupId(userGroup1.getGroupId());
		deviceUser2.setParentUserGroupName(userGroup1.getName());

		DeviceUser deviceUser3  = deviceUser("Mukesh", 30L);
		deviceUser3.setParentUserGroupId(userGroup1.getGroupId());
		deviceUser3.setParentUserGroupName(userGroup1.getName());
		
		DeviceUser deviceUser4  = deviceUser("Inderjit", 40L);
		deviceUser4.setParentUserGroupId(userGroup1.getGroupId());
		deviceUser4.setParentUserGroupName(userGroup1.getName());
		
		List<DeviceUser> usersToMove = new ArrayList<DeviceUser>();
		usersToMove.add(deviceUser1);
		usersToMove.add(deviceUser2);
		
		UserGroup userGroup2 = userGroup("wnom-grp", 200L);
		mockDeviceUserRepository.expects(once()).method("update").with(eq(deviceUser1));
		mockDeviceUserRepository.expects(once()).method("update").with(eq(deviceUser2));
		mockUserRepository.expects(atLeastOnce()).method("getCurrentAdmin").will(returnValue("Admin"));
		mockSystemLogService.expects(atLeastOnce()).method("info").with(ANYTHING, eq(null));
		userGroupService.moveUsersToGroup(usersToMove, userGroup2);
		assertEquals(userGroup2.getName(),  deviceUser1.getParentUserGroupName());
		assertEquals(userGroup2.getName(),  deviceUser2.getParentUserGroupName());
	}
		
	public void testAssignConfigurationToUserGroup() throws Exception {
		UserGroup userGroup1 = userGroup("wyse-grp", 100L);
		String configurationId = "1000L";
		WnomConfiguration globalConfiguration = globalUserConfiguration(configurationId);
		mockWnomConfigurationRepository.expects(once()).method("getGlobalUserConfiguration").will(returnValue(globalConfiguration));
		mockUserGroupRepository.expects(atLeastOnce()).method("findParentWnomConfiguration").with(eq(userGroup1)).will(returnValue(null));
		userGroupService.assignConfigurationToUserGroup(userGroup1, WnomConstants.INHERITED, configurationId);
		assertEquals(WnomConstants.INHERITED, userGroup1.getConfigurationType());
	}
	
	public void testChangeConfigurationFromInheritedToTemplate() throws Exception {
		UserGroup userGroup1 = userGroup("wyse-grp", 100L);
		String configurationId = "1000L";
		WnomConfiguration globalConfiguration = globalUserConfiguration(configurationId);
		userGroup1.setConfigurationType(WnomConstants.INHERITED);
		
		mockWnomConfigurationRepository.expects(once()).method("getGlobalUserConfiguration").will(returnValue(globalConfiguration));
		mockUserGroupRepository.expects(atLeastOnce()).method("findParentWnomConfiguration").with(eq(userGroup1)).will(returnValue(null));
		userGroupService.assignConfigurationToUserGroup(userGroup1, WnomConstants.INHERITED, configurationId);
		assertEquals(WnomConstants.INHERITED, userGroup1.getConfigurationType());
		
		String preDefinedConfigurationName = "WNOM";
		String preDefinedConfigurationId = "2000L";
		WnomConfiguration predefinedConfiguration = userConfiguration(preDefinedConfigurationName,preDefinedConfigurationId);
		mockWnomConfigurationRepository.expects(once()).method("findConfigurationById").with(eq(preDefinedConfigurationId)).will(returnValue(predefinedConfiguration));
		userGroupService.assignConfigurationToUserGroup(userGroup1, WnomConstants.TEMPLATE, preDefinedConfigurationId);
		assertEquals(WnomConstants.TEMPLATE, userGroup1.getConfigurationType());
		assertEquals(preDefinedConfigurationName, userGroup1.getConfiguration().getName());
	}
	
	public void testChangeConfigurationFromInheritedToCustom() throws Exception {
		UserGroup userGroup1 = userGroup("wyse-grp", 100L);
		String configurationId = "1000L";
		WnomConfiguration globalConfiguration = globalUserConfiguration(configurationId);
		userGroup1.setConfigurationType(WnomConstants.INHERITED);
		
		mockWnomConfigurationRepository.expects(once()).method("getGlobalUserConfiguration").will(returnValue(globalConfiguration));
		mockUserGroupRepository.expects(atLeastOnce()).method("findParentWnomConfiguration").with(eq(userGroup1)).will(returnValue(null));
		userGroupService.assignConfigurationToUserGroup(userGroup1, WnomConstants.INHERITED, configurationId);
		assertEquals(WnomConstants.INHERITED, userGroup1.getConfigurationType());
		
		String customConfigurationName = "WNOM";
		String customConfigurationId = "2000L";
		WnomConfiguration customConfiguration = userConfiguration(customConfigurationName,customConfigurationId);
		mockWnomConfigurationRepository.expects(once()).method("findConfigurationById").with(eq(customConfigurationId)).will(returnValue(customConfiguration));
		userGroupService.assignConfigurationToUserGroup(userGroup1, WnomConstants.CUSTOM_USER_CONFIGURATION_TYPE, customConfigurationId);
		assertEquals(WnomConstants.CUSTOM_USER_CONFIGURATION_TYPE, userGroup1.getConfigurationType());
		assertEquals(customConfigurationName, userGroup1.getConfiguration().getName());
	}
	
	private DeviceUser deviceUser(String userName, Long userId) {
		DeviceUser deviceUser = new DeviceUser(userName, 250L, "firstName", "middleName", "lastName", "dept", "jobTitle", "office", "email", "remarks");
		deviceUser.setUserId(userId);
		deviceUser.setPassword("wyse");
		return deviceUser;
	}
	
	private UserGroup userGroup(String groupName, Long userGroupId) {
		UserGroup userGroup = new UserGroup(groupName,groupName);
		userGroup.setGroupId(userGroupId);
		return userGroup;
	}
	
	private WnomConfiguration globalUserConfiguration(String configurationId) {
		WnomConfiguration wnomConfiguration = new WnomConfiguration("Default user Configuration",  WnomConfiguration.USER_CONFIGURATION_TYPE);
		wnomConfiguration.setConfigurationId(configurationId);
		wnomConfiguration.setConfigurationXml(WnomConfigurationXmlFixture.FULL_WNOM_CONFIGURATION_XML);        
		return wnomConfiguration;
	}
	
	private WnomConfiguration userConfiguration(String configurationName, String configurationId) {
		WnomConfiguration wnomConfiguration = new WnomConfiguration(configurationName,  WnomConfiguration.USER_CONFIGURATION_TYPE);
		wnomConfiguration.setConfigurationId(configurationId);
		wnomConfiguration.setConfigurationXml(WnomConfigurationXmlFixture.FULL_WNOM_CONFIGURATION_XML);        
		return wnomConfiguration;
	}
	
}
