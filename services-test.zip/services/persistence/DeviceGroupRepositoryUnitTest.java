package com.wyse.rapport.services.persistence;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.junit.Test;

import com.wyse.rapport.db.tbl.DeviceGroup;
import com.wyse.rapport.services.RapportDBTestCase;
import com.wyse.rapport.wnom.IWnomConfigurationRepository;
import com.wyse.rapport.wnom.WnomConfiguration;
import com.wyse.rapport.wnom.WnomConfigurationRepository;
import com.wyse.rapport.wnom.WnomConstants;

public class DeviceGroupRepositoryUnitTest extends RapportDBTestCase {
	
	private static final String ROOT_CONFIGURATION = "ROOT_CONFIGURATION";

	private static final String CHILD_CONFIGURATION = "CHILD_CONFIGURATION";

	private IDeviceGroupRepository repository;
	
	private IWnomConfigurationRepository configurationRepository;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		repository = new DeviceGroupRepository(sessionService);
		repository.deleteAll();
		configurationRepository = new WnomConfigurationRepository(sessionService);
		configurationRepository.deleteAll();
		
		evict();
	}

	@Override
	protected void tearDown() throws Exception {
		repository.deleteAll();
		evict();
	}
	
	public void testCreateGroup() throws Exception {
		DeviceGroup root = createRootGroup();
		
		DeviceGroup retrievedGroup = repository.findById(root.getGroupId());
		assertNotNull(retrievedGroup);
		assertEquals(retrievedGroup, root);
		assertEquals(retrievedGroup.isConfigurationInherited(), root.isConfigurationInherited());
	}

	public void testDeviceGroupWithCustomConfiguration() throws Exception {
		DeviceGroup root = createRootGroup();
		
		DeviceGroup child = new DeviceGroup("child 1", "First Child");
		child.setConfigurationType(WnomConstants.CUSTOM_DEVICE_CONFIGURATION_TYPE);
		root.addChild(child);
		repository.update(root);
		evict();
		
		DeviceGroup retrievedGroup = repository.findById(child.getGroupId());
		assertTrue(retrievedGroup.isCustomDeviceConfiguration());
		
		assertEquals(root.getAbsoluteIdPath(), child.getParentPath());
	}
	
	public void testParentPath() throws Exception {
		DeviceGroup root = createRootGroup();
		
		DeviceGroup child1 = new DeviceGroup("child 1", "First Child");
		root.addChild(child1);
		repository.update(root);
		evict();
		
		DeviceGroup child2 = new DeviceGroup("Child 2", "Second Child");
		child1.addChild(child2);
		repository.update(root);
		evict();
		
		assertEquals(root.getAbsoluteIdPath(), child1.getParentPath());
		assertEquals(child1.getAbsoluteIdPath(), child2.getParentPath());
	}

	public void testFindDefaultGroup() throws Exception {
		DeviceGroup root = createRootGroup();
		
		assertEquals(root, repository.findDefaultGroup());
	}

	public void testGetChildrenSortedBasedOnName() throws Exception {
		DeviceGroup root = createRootGroup();
		
		DeviceGroup child1 = new DeviceGroup("Child 1", "First Child");
		DeviceGroup child2 = new DeviceGroup("Child 2", "Second Child");
		root.addChild(child2);
		root.addChild(child1);
		repository.update(root);
		evict();
		
		DeviceGroup retrievedGroup = repository.findById(root.getGroupId());
		List<DeviceGroup> children = retrievedGroup.getChildren();
		assertEquals(2, children.size());
		
		assertEquals(child1, children.get(0));
		assertEquals(child2, children.get(1));
	}
	
	public void testGroupsSortedBasedOnName() throws Exception {
		DeviceGroup root = createRootGroup();
		
		DeviceGroup child1 = new DeviceGroup("Child 1", "First Child");
		DeviceGroup child2 = new DeviceGroup("bcc", "Second Child");
		root.addChild(child1);
		root.addChild(child2);
		repository.update(root);
		evict();
		
		Collection<DeviceGroup> groups = repository.findAll();
		assertEquals(3, groups.size());
		
		Iterator<DeviceGroup> iterator = groups.iterator();
		assertEquals(iterator.next(), root);
		assertEquals(iterator.next(), child2);
		assertEquals(iterator.next(), child1);
	}
	
	@Test
	public void testDeleteGroupsDeleteChildrenAlso() throws Exception {
		DeviceGroup root = createRootGroup();
		DeviceGroup child1 = new DeviceGroup("Child 1", "First Child");
		DeviceGroup child2 = new DeviceGroup("bcc", "Second Child");
		root.addChild(child1);
		root.addChild(child2);
		repository.update(root);
		evict();
		
		assertEquals(3, repository.findAll().size());
		
		repository.delete(root);
		assertEquals(0, repository.findAll().size());
	}
	
	public void testFindParentWnomConfigurationFor2Levels() throws Exception {
	
		DeviceGroup rootDeviceGroup = createRootGroup();
		createConfigurationForDeviceGroup(rootDeviceGroup, ROOT_CONFIGURATION, WnomConstants.TEMPLATE);
		
		
		DeviceGroup childGroup = new DeviceGroup("Child 1", "First Child");
		childGroup.setConfigurationType(WnomConstants.INHERITED);
				
		rootDeviceGroup.addChild(childGroup);
		repository.update(rootDeviceGroup);
		
		evict();
		
		DeviceGroup retrievedGroup = repository.findById(childGroup.getGroupId()); 
		WnomConfiguration expected = repository.findParentWnomConfiguration(retrievedGroup);
		WnomConfiguration actual = rootDeviceGroup.getConfiguration();
		assertEquals(actual,expected);
	}
	
	@Test
	public void testFindParentWnomConfigurationFor3Levels() throws Exception {
	
		DeviceGroup root = createRootGroup();
		createConfigurationForDeviceGroup(root, ROOT_CONFIGURATION, WnomConstants.TEMPLATE);
		
		
		DeviceGroup childGroup = new DeviceGroup("Child 1", "First Child");
		createConfigurationForDeviceGroup(childGroup, CHILD_CONFIGURATION, WnomConstants.TEMPLATE);
		
		DeviceGroup childGroup2 = new DeviceGroup("Child 2", "Second Child");
		childGroup2.setConfigurationType(WnomConstants.INHERITED);
		
		root.addChild(childGroup);
		childGroup.addChild(childGroup2);
		repository.update(root);
		
		evict();
		
		DeviceGroup retrievedGroup = repository.findById(childGroup2.getGroupId()); 
		WnomConfiguration expected = repository.findParentWnomConfiguration(retrievedGroup);
		WnomConfiguration actual = childGroup.getConfiguration();
		assertEquals(actual,expected);
	}
	
	@Test
	public void testFindParentWnomConfigurationFor3LevelsWithParentAsCustom() throws Exception {
	
		DeviceGroup root = createRootGroup();
		createConfigurationForDeviceGroup(root, root.getName(), WnomConstants.CUSTOM_DEVICE_CONFIGURATION_TYPE);
		
		DeviceGroup childGroup = new DeviceGroup("Child 1", "First Child");
		addInheritedChild(root, childGroup);
		
		DeviceGroup childGroup2 = new DeviceGroup("Child 2", "Second Child");
		addInheritedChild(childGroup, childGroup2);
		
		DeviceGroup retrievedChildGroup2 = repository.findById(childGroup2.getGroupId()); 
		WnomConfiguration expected = repository.findParentWnomConfiguration(retrievedChildGroup2);
		WnomConfiguration actual = root.getConfiguration();
		assertEquals(actual,expected);
	}

	private void addInheritedChild(DeviceGroup parentGroup, DeviceGroup childGroup) {
		childGroup.setConfigurationType(WnomConstants.INHERITED);
		childGroup.setConfiguration(parentGroup.getConfiguration());
		parentGroup.addChild(childGroup);
		repository.update(parentGroup);
		evict();
	}
	
	public void testDeleteCustomGroupWhenConfigurationIsChangedFromCustomToPreDefinedTemplate() throws Exception {
		DeviceGroup root = createRootGroup();
		createConfigurationForDeviceGroup(root, root.getName(), WnomConstants.TEMPLATE);
		
		DeviceGroup childGroup = new DeviceGroup("Child 1", "First Child");
		createConfigurationForDeviceGroup(childGroup, "Custom Configuration", WnomConstants.CUSTOM_DEVICE_CONFIGURATION_TYPE);
		root.addChild(childGroup);
		repository.update(childGroup);
		evict();
		
		DeviceGroup retrievedChildGroup = repository.findById(childGroup.getGroupId()); 
		WnomConfiguration expected = configurationRepository.findConfigurationById(retrievedChildGroup.getConfiguration().getConfigurationId());
		WnomConfiguration actual = childGroup.getConfiguration();
		assertEquals(actual,expected);
				
		createConfigurationForDeviceGroup(childGroup, "Pre Defined configuration", WnomConstants.TEMPLATE);
		repository.update(childGroup);
		evict();
		
		retrievedChildGroup = repository.findById(childGroup.getGroupId()); 
		expected = configurationRepository.findConfigurationById(retrievedChildGroup.getConfiguration().getConfigurationId());
		actual = childGroup.getConfiguration();
		assertEquals(actual,expected);
		
	}
	
	public void testFindDeviceGroupsForConfiguration() throws Exception {
		
		WnomConfiguration configuration = new WnomConfiguration();
		configuration.setType(WnomConfiguration.DEVICE_CONFIGURATION_TYPE);
		configuration.setName("TEst");
		configuration.setConfigurationXml("Test");
		configurationRepository.update(configuration);
				
		DeviceGroup root = createRootGroup();
		configuration.setGlobal(true);
		root.setConfigurationType(WnomConstants.TEMPLATE);
		root.setConfiguration(configuration);
		repository.update(root);
		
		
		DeviceGroup childGroup = new DeviceGroup("Child 1", "First Child");
		configuration.setGlobal(false);
		childGroup.setConfigurationType(WnomConstants.TEMPLATE);
		childGroup.setConfiguration(configuration);
		root.addChild(childGroup);
		repository.update(childGroup);
		evict();
		
		DeviceGroup childGroup2 = new DeviceGroup("Child 2", "Second Child");
		configuration.setGlobal(false);
		childGroup2.setConfigurationType(WnomConstants.TEMPLATE);
		childGroup2.setConfiguration(configuration);
		root.addChild(childGroup2);
		repository.update(childGroup2);
		evict();
		
		List<DeviceGroup> groups = repository.findDeviceGroupsForConfiguration(configuration);
		assertEquals(3,groups.size());
	}
	
	
	private void createConfigurationForDeviceGroup(DeviceGroup group,String configurationName,String configurationType) {
		WnomConfiguration configuration = new WnomConfiguration();
		configuration.setType(WnomConfiguration.DEVICE_CONFIGURATION_TYPE);
		configuration.setName(configurationName);
		configuration.setConfigurationXml("Test");
		configurationRepository.update(configuration);
		group.setConfigurationType(configurationType);
		group.setConfiguration(configuration);
		repository.update(group);
		evict();
	}
	
	private DeviceGroup createRootGroup() {
		DeviceGroup root = new DeviceGroup(DeviceGroup.DEFAULT_ALL, "Root");
		root.setRootNode(true);
		repository.update(root);
		evict();
		return root;
	}


}
