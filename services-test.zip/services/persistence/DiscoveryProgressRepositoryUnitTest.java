/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.persistence;

import com.wyse.rapport.db.tbl.DiscoveryProgress;
import com.wyse.rapport.services.RapportDBTestCase;

public class DiscoveryProgressRepositoryUnitTest extends RapportDBTestCase {
    DiscoveryProgressRepository progressRepository;

    protected void setUp() throws Exception {
        super.setUp();
        progressRepository = new DiscoveryProgressRepository(sessionService, new DiscoveryRangesRepository(sessionService));
        progressRepository.deleteAll();
        evict();
    }
    @Override
    protected void tearDown() throws Exception {
    	super.tearDown();
        progressRepository.deleteAll();
        evict();
    }

    public void testPersistance() {
        DiscoveryProgress progress = createProgress("172.19.1.1");

        assertNotNull(progressRepository.findById(progress.getID()));
    }

    public void testDeleteAll() throws Exception {
        String ip = "172.19.1.2";
        DiscoveryProgress progress = createProgress(ip);
        DiscoveryProgress findById = progressRepository.findById(progress.getID());
        assertNotNull(findById);
        progressRepository.deleteAll();
        evict();
        assertNull(progressRepository.findById(progress.getID()));
    }

    private DiscoveryProgress createProgress(String ip) {
        DiscoveryProgress progress = new DiscoveryProgress(ip);
        progressRepository.create(progress);
        evict();
        return progress;
    }
}