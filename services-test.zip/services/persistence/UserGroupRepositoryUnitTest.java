package com.wyse.rapport.services.persistence;

import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.services.RapportDBTestCase;

public class UserGroupRepositoryUnitTest extends RapportDBTestCase {

	private static final String CHILD_GROUP = "Child Group";
	private UserGroup globalGroup;
	private UserGroup defaultUnassignedGroup;
	private UserGroup childGroup;
	private IUserGroupRepository userGroupRepository;

	@Before
	public void setUp() throws Exception{
		super.setUp();
		userGroupRepository = new UserGroupRepository(sessionService);
		globalGroup = UserGroup.getRootGroup();
		defaultUnassignedGroup = UserGroup.defaultUnassignedGroup();
		childGroup = userGroup(CHILD_GROUP);
	}

	public void testPersistanceAndRetrievalOfUserGroup() throws Exception {
		userGroupRepository.create(globalGroup);
		evict();

		UserGroup retrievedGroup = userGroupRepository.findById(globalGroup.getGroupId());
		assertEquals(globalGroup, retrievedGroup);
	}

	public void testUpdateOfUserGroup() throws Exception {
		userGroupRepository.create(globalGroup);
		evict();

		globalGroup.setName("Root Changed");

		userGroupRepository.update(globalGroup);
		evict();

		UserGroup retrievedGroup = userGroupRepository.findById(globalGroup.getGroupId());
		assertEquals("Root Changed", retrievedGroup.getName());
	}

	@Test
	public void testFindAllReturnsAllGroupsIncludingChildGroups() throws Exception {
		userGroupRepository.update(globalGroup);
		evict();

		UserGroup childGroup2 = userGroup(childGroup.getName()+"_2");
		globalGroup.addChild(childGroup2);
		globalGroup.addChild(childGroup);
		userGroupRepository.update(globalGroup);
		
		List<UserGroup> allGroups = userGroupRepository.findAll();
		assertEquals(3, allGroups.size());
	}

	@Test
	public void testAddChildSetsTheParentIdToCurrentGroupId() throws Exception {
		userGroupRepository.update(globalGroup);
		evict();

		globalGroup.addChild(defaultUnassignedGroup);
		globalGroup.addChild(childGroup);

		List<UserGroup> children = globalGroup.getChildren();

		Assert.assertEquals(2, children.size());
		Assert.assertEquals(defaultUnassignedGroup, children.get(0));
		Assert.assertEquals(childGroup, children.get(1));
		Assert.assertEquals(globalGroup.getGroupId(), defaultUnassignedGroup.getParentGroupId());
		Assert.assertEquals(globalGroup.getGroupId(), childGroup.getParentGroupId());
	}

	/*@Test
	public void testDeleteAllUserGroups() throws Exception {
		userGroupRepository.update(globalGroup);
		evict();

		globalGroup.addChild(defaultUnassignedGroup);
		globalGroup.addChild(childGroup);
		userGroupRepository.update(globalGroup);
		evict();

		List<UserGroup> children = globalGroup.getChildren();
		Assert.assertEquals(2, children.size());
		userGroupRepository.deleteAll();
		assertTrue(userGroupRepository.findAll().isEmpty());
	}*/
	
//	public void testFindDefaultGroup() throws Exception {
//		userGroupRepository.update(globalGroup);
//		evict();
//		
//		globalGroup.addChild(defaultUnassignedGroup);
//		globalGroup.addChild(childGroup);
//		userGroupRepository.update(globalGroup);
//		evict();
//		
//		assertEquals(globalGroup, userGroupRepository.findRoot());
//	}

//	@Test
	public void testDeleteUserGroup() throws Exception {
		userGroupRepository.update(globalGroup);
		evict();
		globalGroup.addChild(defaultUnassignedGroup);
		UserGroup myGroup = userGroup("test");
		myGroup.setParentGroupId(globalGroup.getGroupId());
		userGroupRepository.update(myGroup);
		evict();
		Long deletedGroupId = myGroup.getGroupId();
		userGroupRepository.delete(deletedGroupId);
		evict();	
		UserGroup group = userGroupRepository.findById(deletedGroupId);
		Assert.assertNull(group);	
		}

	@Override
	protected void tearDown() throws Exception {
		userGroupRepository.deleteAll();
	}

	private UserGroup userGroup(String name) {
		return new UserGroup(name, name+" Description");
	}



}
