/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev: 6757 $$
Last Modified: $$Date: 2006-12-15 11:11:50 +0530 (Fri, 15 Dec 2006) $$
Last Modified By: $$Author: skaranam $$
*/

package com.wyse.rapport.services.persistence;

import com.wyse.rapport.configuration.UserPreference;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.services.RapportDBTestCase;

public class UserPreferencesRepositoryUnitTest extends RapportDBTestCase {
    private UserPreferencesRepository userPreferencesRepository;
    UserPreferences preferences = null;

    protected void setUp() throws Exception {
        super.setUp();
        userPreferencesRepository = new UserPreferencesRepository(sessionService);
        preferences = new UserPreferences();
        userPreferencesRepository.createOrUpdate(preferences);
        evict();
    }
    
    public void testUserPreferencesPersistence() {
        updatePreference(new UserPreference(UserPreferences.CHECKIN_INTERVAL, "1", UserPreferences.HOURS));
     
        assertCheckinInterval("1", UserPreferences.HOURS, userPreferencesRepository.findAll());
    }

	public void testUserPreferencesUpdates() {
        updatePreference(new UserPreference(UserPreferences.CHECKIN_INTERVAL, "567", UserPreferences.MINUTES));
        updatePreference(new UserPreference(UserPreferences.CHECKIN_INTERVAL, "1", UserPreferences.HOURS));

        assertCheckinInterval("1", UserPreferences.HOURS, userPreferencesRepository.findAll());
    }
	
    public void testUserPreferensesPersistance() {
    	//Assert for default Task Retry value
		assertEquals("0", getTaskRetry(preferences));
		assertEquals("50", getNumberOfSystemLogsPerPage(preferences));
		
		UserPreference userPreference = new UserPreference(UserPreferences.TASK_RETRIES, "5");
		UserPreference userPreference1 = new UserPreference(UserPreferences.SYSTEM_LOGS_PER_PAGE, "50");
		UserPreference userPreference2 = new UserPreference(UserPreferences.ALLOW_AUTOMATIC_DISCOVERY, "true");
		updatePreference(userPreference);
		updatePreference(userPreference1);
		updatePreference(userPreference2);
        UserPreferences retrievedSettings = userPreferencesRepository.findAll();
		
        assertEquals("5", getTaskRetry(retrievedSettings));
        assertEquals("50", getNumberOfSystemLogsPerPage(retrievedSettings));
        assertTrue(isAutomaticDiscoveryAllowed(retrievedSettings));
	}
    
	private boolean isAutomaticDiscoveryAllowed(UserPreferences userPreferences) {
		String isAutomaticDiscoveryAllowed = userPreferences.getUserPreferences().get(UserPreferences.ALLOW_AUTOMATIC_DISCOVERY).getValue();
		return Boolean.parseBoolean(isAutomaticDiscoveryAllowed);
	}

	private void updatePreference(UserPreference setting) {
        preferences.setUserPreference(setting);
        userPreferencesRepository.createOrUpdate(preferences);
        evict();
    }
	
	private void assertCheckinInterval(String value, String unit, UserPreferences preferences) {
		assertEquals(value, getCheckinIntervalValue(preferences));
		assertEquals(unit, getCheckinIntervalUnit(preferences));
	}

    private String getCheckinIntervalUnit(UserPreferences preferences) {
		return preferences.getUserPreferences().get(UserPreferences.CHECKIN_INTERVAL).getUnit();
	}

	private String getCheckinIntervalValue(UserPreferences preferences) {
		return preferences.getUserPreferences().get(UserPreferences.CHECKIN_INTERVAL).getValue();
	}

	private String getTaskRetry(UserPreferences userPreferences) {
		return userPreferences.getUserPreferences().get(UserPreferences.TASK_RETRIES).getValue();
	}

	private String getNumberOfSystemLogsPerPage(UserPreferences userPreferences) {
		return userPreferences.getUserPreferences().get(UserPreferences.SYSTEM_LOGS_PER_PAGE).getValue();
	}
	
    @Override
    protected void tearDown() throws Exception {
    	super.tearDown();
        userPreferencesRepository.createOrUpdate(preferences);
        evict();
    }

}
