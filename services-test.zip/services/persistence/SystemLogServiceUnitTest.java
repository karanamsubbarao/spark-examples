/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 5010 $
 Last Modified: $Date: 2006-08-25 17:05:03 +0530 (Fri, 25 Aug 2006) $
 Last Modified By: $Author: ijibanandaray $
 */

package com.wyse.rapport.services.persistence;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wyse.common.SystemLogConstant;
import com.wyse.rapport.businesslogic.comparator.ELogFilterCriteria;
import com.wyse.rapport.businesslogic.comparator.ELogSortCriteria;
import com.wyse.rapport.db.tbl.SystemLog;
import com.wyse.rapport.services.RapportDBTestCase;
import com.wyse.rapport.util.WDMUtil;

public class SystemLogServiceUnitTest extends RapportDBTestCase {
	private ISystemLogService sysLogService;
    public static final Integer RANGE_FACTOR=new Integer(35);
    private SystemLog systemLog1,systemLog2,systemLog3,systemLog4,systemLog5,systemLog6;
    
    protected void setUp() throws Exception {
        super.setUp();
        sysLogService = new SystemLogService(sessionService){
          	public int getRangeFactor() {
          		return 35;
          	}
          };
        sysLogService.deleteAll();
        evict();
        createAllLogs();
      }

    protected void tearDown() throws Exception {
    	super.tearDown();
    	sysLogService.deleteAll();
    	evict();
    }
    
    public void testAddAndRetrieveSystemLog() throws Exception {
        List<SystemLog> systemLogs = sysLogService.findAll();
        assertEquals(6, systemLogs.size());
        assertEquals(systemLog6, systemLogs.get(0));
        assertEquals(systemLog5, systemLogs.get(1));
        assertEquals(systemLog4, systemLogs.get(2));
        assertEquals(systemLog3, systemLogs.get(3));
        assertEquals(systemLog2, systemLogs.get(4));
        assertEquals(systemLog1, systemLogs.get(5));
    }

    public void testDeleteSystemLogs() throws Exception {
        Collection<Long> ids = new ArrayList<Long>();
        ids.add(systemLog1.getId());
        ids.add(systemLog2.getId());
        ids.add(systemLog3.getId());
        ids.add(systemLog4.getId());
        ids.add(systemLog5.getId());
        ids.add(systemLog6.getId());
        sysLogService.delete(ids);
        evict();

        List<SystemLog> systemLogs = sysLogService.findAll();
        assertTrue(systemLogs.isEmpty());
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfLogTimeInDescOrder() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR,ELogFilterCriteria.WARNING), 
							   WDMUtil.DESC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog2, systemLogs.get(2));
	    assertEquals(systemLog1, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfLogTimeInAscendingOrder() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR,ELogFilterCriteria.WARNING), 
    							   WDMUtil.ASC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog5, systemLogs.get(2));
        assertEquals(systemLog6, systemLogs.get(3));
    }
    
    
    public void testAddAndRetrieveSystemLogInTheOrderOfIPAddressInDescOrder() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR,ELogFilterCriteria.WARNING), 
							   WDMUtil.DESC, ELogSortCriteria.IPADDRESS, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog2, systemLogs.get(2));
	    assertEquals(systemLog1, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfIPAddressInAscendingOrder() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR,ELogFilterCriteria.WARNING), 
    							   WDMUtil.ASC, ELogSortCriteria.IPADDRESS, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog5, systemLogs.get(2));
        assertEquals(systemLog6, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfMacAddressInAscendingOrder() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR,ELogFilterCriteria.WARNING), 
    							   WDMUtil.ASC, ELogSortCriteria.MACADDRESS, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog5, systemLogs.get(2));
        assertEquals(systemLog6, systemLogs.get(3));
    }
        
    public void testAddAndRetrieveSystemLogInTheOrderOfMacAddressInDescOrder() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR,ELogFilterCriteria.WARNING), 
							   WDMUtil.DESC, ELogSortCriteria.MACADDRESS, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog2, systemLogs.get(2));
	    assertEquals(systemLog1, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfSeverityInAscendingOrder() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR,ELogFilterCriteria.WARNING), 
    							   WDMUtil.ASC, ELogSortCriteria.SEVERITY, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog5, systemLogs.get(0));
        assertEquals(systemLog6, systemLogs.get(1));
        assertEquals(systemLog1, systemLogs.get(2));
        assertEquals(systemLog2, systemLogs.get(3));
    }
        
    public void testAddAndRetrieveSystemLogInTheOrderOfSeverityInDescOrder() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR,ELogFilterCriteria.WARNING), 
							   WDMUtil.DESC, ELogSortCriteria.SEVERITY, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog1, systemLogs.get(0));
	    assertEquals(systemLog2, systemLogs.get(1));
	    assertEquals(systemLog5, systemLogs.get(2));
	    assertEquals(systemLog6, systemLogs.get(3));
    }
       
    public void testAddAndRetrieveSystemLogInTheOrderOfLogTimeInDescOrderInfoAndError() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.ERROR), 
							   WDMUtil.DESC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog4, systemLogs.get(0));
	    assertEquals(systemLog3, systemLogs.get(1));
	    assertEquals(systemLog2, systemLogs.get(2));
	    assertEquals(systemLog1, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfLogTimeInAscendingOrderInfoAndError() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.ERROR), 
    							   WDMUtil.ASC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog3, systemLogs.get(2));
        assertEquals(systemLog4, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfLogTimeInDescOrderInfoAndWarning() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING), 
							   WDMUtil.DESC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog4, systemLogs.get(2));
	    assertEquals(systemLog3, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfLogTimeInAscendingOrderInfoAndWarning() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING), 
    							   WDMUtil.ASC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog3, systemLogs.get(0));
        assertEquals(systemLog4, systemLogs.get(1));
        assertEquals(systemLog5, systemLogs.get(2));
        assertEquals(systemLog6, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfMacAddressInDescOrderInfoAndError() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.ERROR), 
							   WDMUtil.DESC, ELogSortCriteria.MACADDRESS, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog4, systemLogs.get(0));
	    assertEquals(systemLog3, systemLogs.get(1));
	    assertEquals(systemLog2, systemLogs.get(2));
	    assertEquals(systemLog1, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfMacAddressInAscendingOrderInfoAndError() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.ERROR), 
    							   WDMUtil.ASC, ELogSortCriteria.MACADDRESS, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog3, systemLogs.get(2));
        assertEquals(systemLog4, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfMacAddressInDescOrderInfoAndWarning() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING), 
							   WDMUtil.DESC, ELogSortCriteria.MACADDRESS, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog4, systemLogs.get(2));
	    assertEquals(systemLog3, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfMacAddressInAscendingOrderInfoAndWarning() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING), 
    							   WDMUtil.ASC, ELogSortCriteria.MACADDRESS, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog3, systemLogs.get(0));
        assertEquals(systemLog4, systemLogs.get(1));
        assertEquals(systemLog5, systemLogs.get(2));
        assertEquals(systemLog6, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfIpAddressInDescOrderInfoAndError() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.ERROR), 
							   WDMUtil.DESC, ELogSortCriteria.IPADDRESS, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog4, systemLogs.get(0));
	    assertEquals(systemLog3, systemLogs.get(1));
	    assertEquals(systemLog2, systemLogs.get(2));
	    assertEquals(systemLog1, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfIpAddressInAscendingOrderInfoAndError() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.ERROR), 
    							   WDMUtil.ASC, ELogSortCriteria.IPADDRESS, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog3, systemLogs.get(2));
        assertEquals(systemLog4, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfIpAddressInDescOrderInfoAndWarning() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING), 
							   WDMUtil.DESC, ELogSortCriteria.IPADDRESS, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog4, systemLogs.get(2));
	    assertEquals(systemLog3, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfIpAddressInAscendingOrderInfoAndWarning() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING), 
    							   WDMUtil.ASC, ELogSortCriteria.IPADDRESS, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog3, systemLogs.get(0));
        assertEquals(systemLog4, systemLogs.get(1));
        assertEquals(systemLog5, systemLogs.get(2));
        assertEquals(systemLog6, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfSeverityInDescOrderInfoAndError() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.ERROR), 
							   WDMUtil.DESC, ELogSortCriteria.SEVERITY, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog1, systemLogs.get(0));
	    assertEquals(systemLog2, systemLogs.get(1));
	    assertEquals(systemLog3, systemLogs.get(2));
	    assertEquals(systemLog4, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfSeverityInAscendingOrderInfoAndError() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.ERROR), 
    							   WDMUtil.ASC, ELogSortCriteria.SEVERITY, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog3, systemLogs.get(0));
        assertEquals(systemLog4, systemLogs.get(1));
        assertEquals(systemLog1, systemLogs.get(2));
        assertEquals(systemLog2, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfSeverityInDescOrderInfoAndWarning() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING), 
							   WDMUtil.DESC, ELogSortCriteria.SEVERITY, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(4, systemLogs.size());
	    assertEquals(systemLog5, systemLogs.get(0));
	    assertEquals(systemLog6, systemLogs.get(1));
	    assertEquals(systemLog3, systemLogs.get(2));
	    assertEquals(systemLog4, systemLogs.get(3));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfSeverityInAscendingOrderInfoAndWarning() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING), 
    							   WDMUtil.ASC, ELogSortCriteria.SEVERITY, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(4, systemLogs.size());
        assertEquals(systemLog3, systemLogs.get(0));
        assertEquals(systemLog4, systemLogs.get(1));
        assertEquals(systemLog5, systemLogs.get(2));
        assertEquals(systemLog6, systemLogs.get(3));
    }
    public void testAddAndRetrieveSystemLogInTheOrderOfLogtimeInDescOrderAll() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING,ELogFilterCriteria.ERROR), 
							   WDMUtil.DESC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(6, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog4, systemLogs.get(2));
	    assertEquals(systemLog3, systemLogs.get(3));
	    assertEquals(systemLog2, systemLogs.get(4));
	    assertEquals(systemLog1, systemLogs.get(5));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfLogtimeInAscendingOrderAll() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING,ELogFilterCriteria.ERROR), 
    							   WDMUtil.ASC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(6, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog3, systemLogs.get(2));
        assertEquals(systemLog4, systemLogs.get(3));
        assertEquals(systemLog5, systemLogs.get(4));
        assertEquals(systemLog6, systemLogs.get(5));
    }
    public void testAddAndRetrieveSystemLogInTheOrderOfIpAddressInDescOrderAll() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING,ELogFilterCriteria.ERROR), 
							   WDMUtil.DESC, ELogSortCriteria.IPADDRESS, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(6, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog4, systemLogs.get(2));
	    assertEquals(systemLog3, systemLogs.get(3));
	    assertEquals(systemLog2, systemLogs.get(4));
	    assertEquals(systemLog1, systemLogs.get(5));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfIpAddressInAscendingOrderAll() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING,ELogFilterCriteria.ERROR), 
    							   WDMUtil.ASC, ELogSortCriteria.IPADDRESS, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(6, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog3, systemLogs.get(2));
        assertEquals(systemLog4, systemLogs.get(3));
        assertEquals(systemLog5, systemLogs.get(4));
        assertEquals(systemLog6, systemLogs.get(5));
    }
    public void testAddAndRetrieveSystemLogInTheOrderOfMACAddressInDescOrderAll() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING,ELogFilterCriteria.ERROR), 
							   WDMUtil.DESC, ELogSortCriteria.MACADDRESS, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(6, systemLogs.size());
	    assertEquals(systemLog6, systemLogs.get(0));
	    assertEquals(systemLog5, systemLogs.get(1));
	    assertEquals(systemLog4, systemLogs.get(2));
	    assertEquals(systemLog3, systemLogs.get(3));
	    assertEquals(systemLog2, systemLogs.get(4));
	    assertEquals(systemLog1, systemLogs.get(5));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfMACAddressInAscendingOrderAll() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING,ELogFilterCriteria.ERROR), 
    							   WDMUtil.ASC, ELogSortCriteria.MACADDRESS, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(6, systemLogs.size());
        assertEquals(systemLog1, systemLogs.get(0));
        assertEquals(systemLog2, systemLogs.get(1));
        assertEquals(systemLog3, systemLogs.get(2));
        assertEquals(systemLog4, systemLogs.get(3));
        assertEquals(systemLog5, systemLogs.get(4));
        assertEquals(systemLog6, systemLogs.get(5));
    }
    public void testAddAndRetrieveSystemLogInTheOrderOfSeverityInDescOrderAll() throws Exception {
    	Map<String,Object> data = 
			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING,ELogFilterCriteria.ERROR), 
							   WDMUtil.DESC, ELogSortCriteria.SEVERITY, ELogFilterCriteria.ALL);
   
	    List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
	    assertEquals(6, systemLogs.size());
	    assertEquals(systemLog1, systemLogs.get(0));
	    assertEquals(systemLog2, systemLogs.get(1));
	    assertEquals(systemLog5, systemLogs.get(2));
	    assertEquals(systemLog6, systemLogs.get(3));
	    assertEquals(systemLog3, systemLogs.get(4));
	    assertEquals(systemLog4, systemLogs.get(5));
    }
    
    public void testAddAndRetrieveSystemLogInTheOrderOfSeverityInAscendingOrderAll() throws Exception {
    	Map<String,Object> data = 
    			systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO,ELogFilterCriteria.WARNING,ELogFilterCriteria.ERROR), 
    							   WDMUtil.ASC, ELogSortCriteria.SEVERITY, ELogFilterCriteria.ALL);
       
        List<SystemLog> systemLogs = (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(6, systemLogs.size());
        assertEquals(systemLog3, systemLogs.get(0));
        assertEquals(systemLog4, systemLogs.get(1));
        assertEquals(systemLog5, systemLogs.get(2));
        assertEquals(systemLog6, systemLogs.get(3));
        assertEquals(systemLog1, systemLogs.get(4));
        assertEquals(systemLog2, systemLogs.get(5));
    }
    public void testRetriveSystemLogsOfErrorType() throws Exception {
    	assertLogCountForCriteria(ELogFilterCriteria.ERROR, SystemLogConstant.ERROR, ELogFilterCriteria.ALL);
      }

    public void testRetriveSystemLogsOfInfoType() throws Exception {
    	assertLogCountForCriteria(ELogFilterCriteria.INFO, SystemLogConstant.INFO, ELogFilterCriteria.ALL);
      }
    
    public void testRetriveSystemLogsOfWarningType() throws Exception {
    	assertLogCountForCriteria(ELogFilterCriteria.WARNING, SystemLogConstant.WARNING, ELogFilterCriteria.ALL);
    }
    
    public void assertLogCountForCriteria(ELogFilterCriteria criteria, int type, ELogFilterCriteria dateFilterCriteria) throws Exception {       
        Map<String,Object> data=new HashMap<String,Object>();
        data.put(SystemLogConstant.SORT_CRITERIA,ELogSortCriteria.SEVERITY);
        data.put(SystemLogConstant.SORT_ORDER,WDMUtil.DESC);
        data.put(SystemLogConstant.END_ROW,2);
        data.put(SystemLogConstant.START_ROW,1);
        data.put(SystemLogConstant.PAGE_NUMBER,1);
        List<ELogFilterCriteria> filterList=new ArrayList<ELogFilterCriteria>();
        filterList.add(criteria);
        data.put(SystemLogConstant.FILTER_CRITERIA,filterList);
        data.put(SystemLogConstant.DATE_FILTER_CRITERIA,dateFilterCriteria);
        List<SystemLog> systemLogs =  (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
        assertEquals(2,systemLogs.size());
        assertLogType(type,systemLogs.get(0));
       }
    
    public void testSortSystemLogsOfErrorType() throws Exception {
        Map<String,Object> data=systemLogConstants(WDMUtil.asList(ELogFilterCriteria.ERROR), WDMUtil.DESC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
        List<SystemLog> systemLogs =  (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
    	assertEquals(2,systemLogs.size());
        assertEquals(systemLog2, systemLogs.get(0));
        assertEquals(systemLog1, systemLogs.get(1));
        assertLogType(SystemLogConstant.ERROR,systemLogs.get(0));
        assertLogType(SystemLogConstant.ERROR,systemLogs.get(1));
      }
    
    public void testSortSystemLogsOfWarningType() throws Exception {
    	SystemLogService sysLogService = new SystemLogService(sessionService){
         	public int getRangeFactor() {
         		return 35;
         	}
         };     
         Map<String,Object> data=systemLogConstants(WDMUtil.asList(ELogFilterCriteria.WARNING), WDMUtil.DESC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
        List<SystemLog> systemLogs =  (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
    	assertEquals(2,systemLogs.size());
        assertEquals(systemLog6, systemLogs.get(0));
        assertEquals(systemLog5, systemLogs.get(1));
        assertLogType(SystemLogConstant.WARNING,systemLogs.get(0));
        assertLogType(SystemLogConstant.WARNING,systemLogs.get(1));
      }
    
    public void testSortSystemLogsOfInfoType() throws Exception { 
        Map<String,Object> data=systemLogConstants(WDMUtil.asList(ELogFilterCriteria.INFO), WDMUtil.DESC, ELogSortCriteria.LOGTIME, ELogFilterCriteria.ALL);
        List<SystemLog> systemLogs =  (List<SystemLog>)sysLogService.findAll(data).get(SystemLogConstant.SYSTEM_LOG_SUMMARY);
    	assertEquals(2,systemLogs.size());
        assertEquals(systemLog4, systemLogs.get(0));
        assertEquals(systemLog3, systemLogs.get(1));
        assertLogType(SystemLogConstant.INFO,systemLogs.get(0));
        assertLogType(SystemLogConstant.INFO,systemLogs.get(1));
      }
    
    private Map<String,Object> systemLogConstants(List<ELogFilterCriteria> filterCriteriaList, String order, ELogSortCriteria sortCriteria, ELogFilterCriteria dateFilterCriteria) {
    	  Map<String,Object> data=new HashMap<String,Object>();
          data.put(SystemLogConstant.SORT_CRITERIA,sortCriteria);
          data.put(SystemLogConstant.SORT_ORDER,order);
          data.put(SystemLogConstant.END_ROW,2);
          data.put(SystemLogConstant.START_ROW,1);
          data.put(SystemLogConstant.FILTER_CRITERIA,filterCriteriaList);
          data.put(SystemLogConstant.DATE_FILTER_CRITERIA,dateFilterCriteria);
          String currentDate = getCurrentdate().toString();
          data.put(SystemLogConstant.START_DATE,currentDate);
          data.put(SystemLogConstant.END_DATE,currentDate);
          data.put(SystemLogConstant.PAGE_NUMBER,1);
          return data;
    	
    }
	    
    private void assertLogType(int type,SystemLog log){
    	assertTrue(type == log.getLevel());
    }
   
    private SystemLog createLog(int level,String ipAddress,String mac, String description,Date date) {
        SystemLog systemLog = new SystemLog(level, ipAddress,mac, description, date);
        SystemLogService service = new SystemLogService(sessionService);
        service.create(systemLog);
        evict();
        return systemLog;
    }

    private Date createDate(int year, int month, int date, int hour, int minute, int second) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1);
        calendar.set(Calendar.DATE, date);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, second);
        return calendar.getTime();
    }
    
    
    private void createAllLogs() {
    	systemLog1 = createLog(SystemLogConstant.ERROR, "10.150.2.100","11:22:33:44:55:11","Upgrade Agent Task Failed", createDate(2006, 8, 10, 10, 20, 25));
        systemLog2 = createLog(SystemLogConstant.ERROR, "10.150.2.200","11:22:33:44:55:22","Pull Image Failed",createDate(2006, 8, 10,10, 20, 26));
        systemLog3 = createLog(SystemLogConstant.INFO, "10.150.2.300","11:22:33:44:55:33","Upgrade Agent Command Sent",createDate(2006, 8, 10, 10, 20, 27));
        systemLog4 = createLog(SystemLogConstant.INFO, "10.150.2.400","11:22:33:44:55:44","Pull Image Command Sent", createDate(2006, 8, 10,10, 20, 28));
        systemLog5 = createLog(SystemLogConstant.WARNING, "10.150.2.500","11:22:33:44:55:55","Upgrade Agent Not Working", createDate(2006, 8, 10, 10, 20, 29));
        systemLog6 = createLog(SystemLogConstant.WARNING, "10.150.2.600","11:22:33:44:55:66","Pull Image Not Working" ,createDate(2006, 8, 10, 10, 20, 30));
    }
    
    private Date getCurrentdate(){
        return new Date();
    }
}
