/**
 * 
 */
package com.wyse.rapport.services.persistence;

import java.util.List;

import com.wyse.rapport.db.tbl.DeviceUser;
import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.services.RapportDBTestCase;

public class DeviceUserRepositoryUnitTest extends RapportDBTestCase {

	private IDeviceUserRepository deviceUserRepository;
	private IUserGroupRepository userGroupRepository;


	protected void setUp() throws Exception {
		super.setUp();
		deviceUserRepository=new DeviceUserRepository(sessionService);
		userGroupRepository = new UserGroupRepository(sessionService);
	}
	
	public void testDeviceUserPersistence() throws Exception {
		createUsers();
		assertEquals(Long.valueOf(2), sessionService.getCount(DeviceUser.class, null, null));
	}
	
	public void testDeleteAll() throws Exception {
		createUsers();
		deviceUserRepository.deleteAll();
		assertEquals(Long.valueOf(0), sessionService.getCount(DeviceUser.class, null, null));
	}
	
	public void testDeleteOneDeviceUser() throws Exception {
		DeviceUser deviceUser1=new DeviceUser("myadav","mukesh", "yadav", "engg");
		deviceUserRepository.update(deviceUser1);
		DeviceUser deviceUser2=new DeviceUser("skaranm","subba", "karanam", "engg");
		deviceUserRepository.update(deviceUser2);
		
		deviceUserRepository.delete(deviceUser2);
		List<DeviceUser> users = deviceUserRepository.findAll();
		assertEquals(1, users.size());
		assertEquals("myadav",users.get(0).getUserName());
	}
	
	public void testFindOneUser() throws Exception {
		createUsers();
		DeviceUser user=new DeviceUser();
		user.setUserName("myadav");
		DeviceUser retrievedUser = deviceUserRepository.findUser(user.getUserName());
		assertEquals("myadav", retrievedUser.getUserName());
	}
	
	public void testGetUserGroupName() throws Exception {
		UserGroup globalGroup = UserGroup.getRootGroup();
		userGroupRepository.update(globalGroup);
		evict();
		
		Long groupId = globalGroup.getGroupId();
		DeviceUser deviceUser1=new DeviceUser("myadav","mukesh", "yadav", "engg");
		deviceUser1.setParentUserGroupId(groupId);
		deviceUserRepository.update(deviceUser1);
		
		DeviceUser user = deviceUserRepository.findAll().get(0);
		assertEquals(UserGroup.DEFAULT_GLOBAL, deviceUserRepository.getUserGroupName(user));
	}

	public void testFindUserInRepositoryByUserName() throws Exception {
		DeviceUser user = deviceUserRepository.findUser("xxxx");
		assertNull(user);
	}
	
	private void createUsers() {
		DeviceUser deviceUser1=new DeviceUser("myadav","mukesh", "yadav", "engg");
		deviceUser1.setParentUserGroupId(1L);
		deviceUserRepository.update(deviceUser1);
		DeviceUser deviceUser2=new DeviceUser("skaranm","subba", "karanam", "engg");
		deviceUser2.setParentUserGroupId(1L);
		deviceUserRepository.update(deviceUser2);
	}
	
	protected void tearDown() throws Exception {
		deviceUserRepository.deleteAll();
	}

}
