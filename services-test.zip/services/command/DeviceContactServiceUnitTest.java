/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev: 7521 $$
Last Modified: $$Date: 2007-06-25 15:15:21 +0530 (Mon, 25 Jun 2007) $$
Last Modified By: $$Author: skaranam $$
*/

package com.wyse.rapport.services.command;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;

import org.jmock.Mock;
import org.jmock.expectation.ExpectationCounter;

import com.wyse.common.MacIDGenerator;
import com.wyse.common.RandomIPGenerator;
import com.wyse.rapport.businesslogic.httpclient.ConnectionTimeoutException;
import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceDisplayStatus;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.db.tbl.UUIDTestCase;
import com.wyse.rapport.services.IHibernateSessionService;
import com.wyse.rapport.services.IThreadPoolService;
import com.wyse.rapport.services.persistence.ISystemLogService;
import com.wyse.rapport.services.persistence.SystemLogService;

public class DeviceContactServiceUnitTest extends UUIDTestCase {
	
	public void testChangingCheckinIntervalSetsNextAssetReportTimeOnDevice() throws Exception {
        Collection<DeviceInfo> devices = new ArrayList<DeviceInfo>();
        DeviceInfo device = new DeviceFixture().createEmptyDevice();
        devices.add(device);
        Mock mock = mock(IThreadPoolService.class);
        mock.expects(once()).method("submitJob");
        IThreadPoolService threadPoolService = (IThreadPoolService) mock.proxy();
        new DeviceContactService(null, threadPoolService, systemLogService(null)).changeCheckinInterval(devices, 10);
        assertNotNull(device.getNextAssetReportExpected());
    }

    public void testSystemLoggerLogsDeviceNotContactableError() throws Exception {
        final ExpectationCounter errorCalled = new ExpectationCounter("System logger's error");
        Mock mockHibernateService = mockHibernateService(MessageConstants.Values.BOGUS_GUID, false);
        DeviceContactService service = new DeviceContactService((IHibernateSessionService) mockHibernateService.proxy(), null, systemLogService(errorCalled)){
        	String sendCommand(Device device, String command, IDeviceCommunicationService communicationService) {
        	      throw new ConnectionTimeoutException("Timed out");
        	};
        };
        DeviceContactService.ContactDeviceThread contactThread = service.new ContactDeviceThread(MessageConstants.Values.BOGUS_GUID, false);
        errorCalled.setExpected(1);
        contactThread.run();
        errorCalled.verify();
    }

    public void testSystemLoggerLogsLegacyDeviceNotContactableError() throws Exception {
        final ExpectationCounter errorCalled = new ExpectationCounter("System logger's error");
        Mock mockHibernateService = mockHibernateService(MessageConstants.Values.BOGUS_GUID, true);
		DeviceContactService service = new DeviceContactService((IHibernateSessionService) mockHibernateService.proxy(), null, systemLogService(errorCalled)) {
            String sendCommand(String ipAddress, IDeviceCommunicationService communicationService, String command) throws UnknownHostException {
                throw new ConnectionTimeoutException("Timed out");
            }
        };
        DeviceContactService.SendCommandToLegacyDeviceThread sendThread = service.new SendCommandToLegacyDeviceThread("device1", "comamnd");
        errorCalled.setExpected(1);
        sendThread.run();
        errorCalled.verify();
    }

     
    public void testSystemLogServiceLogsOnlyOnceEvenIfContactedDeviceMoreThanOnce() throws Exception {
    	final ExpectationCounter contactedDeviceCalled=new ExpectationCounter("No of times contaced device");
    	final ExpectationCounter errorCalled=new ExpectationCounter("systemLog error");
    	Mock mockHibernateServiceForRetry = mockHibernateServiceForRetry("device2",false);
    	DeviceContactService service=new DeviceContactService((IHibernateSessionService) mockHibernateServiceForRetry.proxy(),null,systemLogService(errorCalled)){
    		String sendCommand(String ipAddress, IDeviceCommunicationService communicationService, String command) throws UnknownHostException {
    			contactedDeviceCalled.inc();
    			throw new ConnectionTimeoutException("Connection Timeout");
    		}
    	};
    	DeviceContactService.ContactDeviceThread contactThread=service.new ContactDeviceThread("device2", false);
    	contactedDeviceCalled.setExpected(3);
    	errorCalled.setExpected(1);
    	contactThread.run();
    	contactedDeviceCalled.verify();
    	errorCalled.verify();
	}
    
    public void testContactDeviceSendsStartDialogFromDeviceCommand() throws Exception {
    	final ExpectationCounter dialogCommandCalled=new ExpectationCounter("Sending Dialog Command");
    	final ExpectationCounter errorCalled=new ExpectationCounter("System log error");
    	final ExpectationCounter sendCalled=new ExpectationCounter("SendCommand called");
    	Mock mockHibernateServiceForRetry=mockHibernateServiceForRetry("device",false);
    	
    	DeviceContactService service=new DeviceContactService((IHibernateSessionService)mockHibernateServiceForRetry.proxy(),null,systemLogService(errorCalled)){
    		String sendCommand(String ipAddress, IDeviceCommunicationService communicationService, String command) throws UnknownHostException {
    			sendCalled.inc();
    			throw new ConnectionTimeoutException("Connection Timeout");
    		}
    		
    		public String messageWithStartDialog(Device device, String dialogGuid) {
    			dialogCommandCalled.inc();
    			return "Sending StartDialogFromDevice command";
    		}
    	};
    	
    	DeviceContactService.ContactDeviceThread contactThread=service.new ContactDeviceThread("device", false);
    	sendCalled.setExpected(3);
    	dialogCommandCalled.setExpected(1);
    	errorCalled.setExpected(1);
    	contactThread.run();
    	dialogCommandCalled.verify();
    	errorCalled.verify();
	}
    
    public void testContactDeviceChangesDeviceStateToBusyOnStartDialogError() throws Exception {
        Collection<Device> devices = new ArrayList<Device>();
        DeviceInfo device = new DeviceFixture().createEmptyDevice();
        devices.add(device);
        DeviceContactService deviceContactService = new DeviceContactService(null, null, systemLogService(null)){
        	String sendCommand(Device device, String command, IDeviceCommunicationService communicationService) {
        		return XMLResultsFixture.errorResult(MessageConstants.Values.BOGUS_GUID,MessageConstants.Values.BOGUS_GUID,"error","Device Busy");
        	}
        };
        DeviceContactService.ContactDeviceThread contactThread=deviceContactService.new ContactDeviceThread("device", false);
        contactThread.contactDevice(device);
        assertEquals(DeviceDisplayStatus.BUSY, device.getStatus(null));
        
    }
    
    private ISystemLogService systemLogService(final ExpectationCounter errorCalled) {
        return new SystemLogService(null) {
            public void error(String message,Device device) {
                errorCalled.inc();
            }
        };
    }

    private Mock mockHibernateService(String deviceGuid, boolean isLegacy) {
        Mock mockHibernate = mock(IHibernateSessionService.class);
        DeviceInfo device = new DeviceInfo();
        if (isLegacy) device.setLegacy(true);
        
        DeviceNetworkInfo network = new DeviceNetworkInfo();
        network.setIpAddress(RandomIPGenerator.nextIP());
        network.setMacAddress(MacIDGenerator.nextMacID());
        device.addDeviceNetwork(network);
        
        device.setDeviceGuid(deviceGuid);
        mockHibernate.expects(once()).method("find").will(returnValue(device));
        mockHibernate.expects(once()).method("closeSession");
        return mockHibernate;
    }

    private Mock mockHibernateServiceForRetry(String deviceGuid, boolean isLegacy) {
        Mock mockHibernate = mock(IHibernateSessionService.class);
        DeviceInfo device = new DeviceInfo();
        if (isLegacy) device.setLegacy(true);
        device.setDeviceGuid(deviceGuid);
        DeviceNetworkInfo network = new DeviceNetworkInfo();
        network.setIpAddress(RandomIPGenerator.nextIP());
        network.setMacAddress(MacIDGenerator.nextMacID());
        device.addDeviceNetwork(network);
        mockHibernate.expects(atLeastOnce()).method("find").will(returnValue(device));
        mockHibernate.expects(atLeastOnce()).method("closeSession");
        return mockHibernate;
    }
}
