package com.wyse.rapport.services.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.wyse.rapport.db.tbl.UserGroup;
import com.wyse.rapport.services.persistence.IDeviceUserRepository;
import com.wyse.rapport.services.persistence.IUserGroupRepository;
import com.wyse.rapport.wnom.IWnomConfigurationRepository;
import com.wyse.rapport.wnom.WnomConfiguration;


public class OrganizationServiceUnitTest extends MockObjectTestCase {

	private static final String TEST_GROUP_ID = "100";
	private Mock mockServeletRequest ;
	Mock mockHttpSession ;
	private Mock mockUserGroupRepository;
	private Mock mockDeviceUserRepository;
	private Mock mockConfigurationRepository;
	private OrganizationService organizationService;
	UserGroup defaultGroup;
	UserGroup rootGroup = UserGroup.getRootGroup();
	UserGroup defaultUnassignedGroup = UserGroup.defaultUnassignedGroup();


	protected void setUp() throws Exception {
		super.setUp();
		defaultGroup = getDefaultRootGroup();
		defaultUnassignedGroup = UserGroup.defaultUnassignedGroup();

		organizationService = new OrganizationService(){
			void updateUserCount(UserGroup userGroup) {
			}
		};
		mockServeletRequest = mock(HttpServletRequest.class);
		mockHttpSession = mock(HttpSession.class);
		mockUserGroupRepository = mock(IUserGroupRepository.class);
		mockDeviceUserRepository = mock(IDeviceUserRepository.class);
		mockConfigurationRepository=mock(IWnomConfigurationRepository.class);
		organizationService.setDeviceUserRepository((IDeviceUserRepository) mockDeviceUserRepository.proxy());
		organizationService.setUserGroupRepository((IUserGroupRepository) mockUserGroupRepository.proxy());
		organizationService.setWnomConfigurationRepository((IWnomConfigurationRepository) mockConfigurationRepository.proxy());
	}

	public void testAddUserGroupDetailsWhenDefaultGroupIsNull() throws Exception { 
		mockUserGroupRepository.expects(once()).method("findRoot").will(returnValue(null));
		mockUserGroupRepository.expects(once()).method("create").with(eq(rootGroup));

		rootGroup.addChild(defaultUnassignedGroup);
		mockUserGroupRepository.expects(once()).method("update").with(eq(rootGroup));

		mockConfigurationRepository.expects(atLeastOnce()).method("getGlobalUserConfiguration").will(returnValue(new WnomConfiguration()));
		Map<String, Object> userGroupDetails = organizationService.getUserGroupDetails((HttpServletRequest) mockServeletRequest.proxy());

		assertEquals(defaultGroup, userGroupDetails.get(OrganizationService.ROOT_USER_GROUP));
		assertEquals(defaultGroup, userGroupDetails.get(OrganizationService.CURRENT_USER_GROUP));
	}

	public void testAddUserGroupDetailsWhenDefaultGroupIsNotNullAndCurrentGroupIdIsNull() throws Exception {
		mockServeletRequest.expects(once()).method("getSession").will(returnValue(mockHttpSession.proxy()));
		mockHttpSession.expects(once()).method("setAttribute").with(eq(OrganizationService.CURRENT_USER_GROUP_ID),ANYTHING);
		mockHttpSession.expects(once()).method("getAttribute").with(eq(OrganizationService.CURRENT_USER_GROUP_ID)).will(returnValue(""));
		mockUserGroupRepository.expects(atLeastOnce()).method("findRoot").will(returnValue(defaultGroup));
		mockUserGroupRepository.expects(once()).method("findById").with(eq(defaultGroup.getGroupId())).will(returnValue(rootGroup));

		mockConfigurationRepository.expects(once()).method("getGlobalUserConfiguration").will(returnValue(new WnomConfiguration()));
		currentGroupIdExpectation(null);
		Map<String, Object> userGroupDetails = organizationService.getUserGroupDetails((HttpServletRequest) mockServeletRequest.proxy());
		
		assertEquals(defaultGroup, userGroupDetails.get(OrganizationService.ROOT_USER_GROUP));
		assertEquals(defaultGroup, userGroupDetails.get(OrganizationService.CURRENT_USER_GROUP));
	}

	public void testAddUserGroupDetailsWhenDefaultGroupIsNotNullAndCurrentGroupIdIsNotNull() throws Exception {
		mockServeletRequest.expects(once()).method("getSession").will(returnValue(mockHttpSession.proxy()));
		mockHttpSession.expects(atLeastOnce()).method("setAttribute").with(eq(OrganizationService.CURRENT_USER_GROUP_ID), eq(TEST_GROUP_ID));
		mockUserGroupRepository.expects(once()).method("findRoot").will(returnValue(rootGroup));
		currentGroupIdExpectation(TEST_GROUP_ID);
		UserGroup currentGroup = userGroup("Test Group");
		mockUserGroupRepository.expects(once()).method("findById").with(eq(Long.parseLong(TEST_GROUP_ID))).will(returnValue(currentGroup));

		mockConfigurationRepository.expects(once()).method("getGlobalUserConfiguration").will(returnValue(new WnomConfiguration()));
		Map<String, Object> userGroupDetails = organizationService.getUserGroupDetails((HttpServletRequest) mockServeletRequest.proxy());
		
		assertEquals(rootGroup, userGroupDetails.get(OrganizationService.ROOT_USER_GROUP));
		assertEquals(currentGroup, userGroupDetails.get(OrganizationService.CURRENT_USER_GROUP));
	}

	private UserGroup userGroup(String name) {
		return new UserGroup(name, name+" Description");
	}

	private void currentGroupIdExpectation(String currentGroupId) {
		mockServeletRequest.expects(once()).method("getParameter").with(eq(OrganizationService.CURRENT_USER_GROUP_ID)).will(returnValue(currentGroupId));
	}

	public static UserGroup getDefaultRootGroup() {
		UserGroup userGroup = UserGroup.getRootGroup();
		userGroup.setGroupId(1L);
		userGroup.addChild(UserGroup.defaultUnassignedGroup());
		return userGroup;
	}


}
