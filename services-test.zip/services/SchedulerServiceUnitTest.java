package com.wyse.rapport.services;

import com.wyse.rapport.command.RebootCommand;
import com.wyse.rapport.command.TasksFactory;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.Schedule;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.services.persistence.DeviceRepository;

/**
 */
public class SchedulerServiceUnitTest extends RapportDBTestCase {
    public void testFetchingATaskAtAScheduledTime() throws InterruptedException {
        DeviceInfo device = new DeviceFixture().createDeviceWithNetworks("10.150.4.123", "aabbccddeeff");
        DeviceRepository deviceRepository = deviceRepository();
        deviceRepository.create(device);
        device.reboot(0);
        deviceRepository.update(device);
        evict();
        deviceRepository.closeSession();
        Thread.sleep(3000);
        device = deviceRepository().findByGuid(device.getDeviceGuid());
        assertEquals(rebootTask().getCommands().get(0), device.getCurrentTask().getCommands().get(0));
    }

    private DeviceRepository deviceRepository() {
        DeviceRepository deviceRepository = new DeviceRepository(sessionService);
        return deviceRepository;
    }

    private Task rebootTask() {
        Task task = new TasksFactory().createTask(new RebootCommand());
        task.setSchedule(Schedule.now());
        return task;
    }
}