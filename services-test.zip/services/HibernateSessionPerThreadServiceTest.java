/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 4183 $
Last Modified: $Date: 2006-05-26 01:06:44 +0530 (Fri, 26 May 2006) $
Last Modified By: $Author: kquinto $
*/

package com.wyse.rapport.services;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.engine.SessionImplementor;
import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

/** Ensures the behaviour of the session per thread service. */
public class HibernateSessionPerThreadServiceTest extends MockObjectTestCase {
    private Mock mockSessionFactory;
    private HibernateSessionPerThreadService service;
    private Mock mockSession;

    protected void setUp() throws Exception {
        super.setUp();
        mockSessionFactory = mock(SessionFactory.class);
        service = new HibernateSessionPerThreadService((SessionFactory) mockSessionFactory.proxy());
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        service.clearSession();
    }

    public void testCurrentSessionIsNotNull() {
        expectOpenSession();
        assertNotNull(service.currentSession());
    }

    public void testReturnsSameSessionAfterTwoRequests() {
        expectOpenSession();
        Session hibernateSession = service.currentSession();
        assertSame(hibernateSession, service.currentSession());
    }

    public void testCloseSession() {
        expectOpenSession();
        Session hibernateSession = service.currentSession();
        expectCloseSession();
        service.closeSession();
        expectOpenSession();
        assertNotSame(hibernateSession, service.currentSession());
    }

    public void testTwoSessionsFromTwoThreads() throws InterruptedException {
        expectOpenSession();
        final Session hibernateSession = service.currentSession();
        //In order to allow obtain the hibernate session from the thread below,
        //we have to declare a final local variable. However, declaring a variable
        //as final prevents it from being assigned. Hence the solution is to
        //declare a final array, and then set the session as an element in the array.
        //In addition, JUnit assertions should *always* be done on the test thread -
        //they will have no effect if they're done in a separate thread.
        final Session[] otherHibernateSession = new Session[2];
        Thread otherThread = new Thread(new Runnable() {
            public void run() {
                expectOpenSession();
                otherHibernateSession[0] = service.currentSession();
                otherHibernateSession[1] = service.currentSession();
                service.clearSession();
            }
        });
        otherThread.start();
        otherThread.join();
        assertNotSame(hibernateSession, otherHibernateSession[0]);
        //In the same thread, currentSession() should always return the same session.
        assertSame(otherHibernateSession[0], otherHibernateSession[1]);
    }

    private void expectCloseSession() {
        mockSession.expects(once()).method("close");
    }

    private void expectOpenSession() {
        mockSession = mock(SessionImplementor.class);
        mockSessionFactory.expects(once())
                .method("openSession")
                .will(returnValue(mockSession.proxy()));
    }
}
