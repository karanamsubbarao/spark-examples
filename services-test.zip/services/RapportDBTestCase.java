/*
 Copyright (c) Wyse Technology, Inc.

 Current Revision: $Rev: 7431 $
 Last Modified: $Date: 2007-05-24 09:11:44 +0530 (Thu, 24 May 2007) $
 Last Modified By: $Author: gkanagaraj $
 */

package com.wyse.rapport.services;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceTestCase;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.persistence.DeviceRepository;
import com.wyse.rapport.util.MasterRepository;

/** @author smariswamy */
public abstract class RapportDBTestCase extends DeviceTestCase {
    //the bean factory below allows multiple config files. we can use this to implement separate hibernate session strategies
    //for tests (single, global session, as the tests are essentially single threaded), or session-per-request /
    //session-per-thread.
    protected static ApplicationContext beanFactory;
    protected IHibernateSessionService sessionService;
    private SchedulerService scheduler;

    protected void setUp() throws Exception {
        super.setUp();
        initBeans();
        new DeviceRepository(sessionService).deleteAll();
        evict();
    }

	private void initBeans() {
		//hack: to enable debugging from eclipse
        Boolean isAntBuild = Boolean.valueOf(System.getProperty("ant_build"));
        if (isAntBuild) {
            initBeanFactory();
        } else {
            beanFactory = new FileSystemXmlApplicationContext(new String[] {"webapps/admin_client/WEB-INF/springapp-persistence.xml"});
            SpringApplicationContext.setWebApplicationContext(new FileSystemXmlApplicationContext(
            		new String[] {"webapps/admin_client/WEB-INF/springapp-services.xml", "webapps/admin_client/WEB-INF/springapp-persistence.xml"}));
        }
        sessionService = hibernateSession();
	}

    protected IHibernateSessionService hibernateSession() {
        return (IHibernateSessionService) beanFactory.getBean("hibernateSessionPerThread");
    }

    private void initBeanFactory() {
        if (beanFactory == null) {
            RapportServer.start();
            beanFactory = SpringApplicationContext.getWebApplicationContext();
            Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
                public void run() {
                    RapportServer.stop();
                }
            }));
        }
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        new DeviceRepository(sessionService).deleteAll();
        String certificatesDirectory = 
        	MasterRepository.wtosCertificatesFileDirectory();
        File certFileDir = new File(certificatesDirectory);
        FileUtils.cleanDirectory(certFileDir); 
        evict();
    }
    
    protected DeviceInfo persistDevice(DeviceInfo device) {
        new DeviceRepository(sessionService).update(device);
        evict();
        return device;
    }


    protected void evict() {
        sessionService.flush();
    }

    protected SchedulerService scheduler() {
        if (scheduler == null) scheduler = (SchedulerService) beanFactory.getBean("schedulerService");
        return scheduler;
    }
}
