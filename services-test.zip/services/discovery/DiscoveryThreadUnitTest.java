/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev: 4809 $$
Last Modified: $$Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $$
Last Modified By: $$Author: smariswamy $$
*/

package com.wyse.rapport.services.discovery;

import java.net.InetAddress;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.wyse.rapport.services.IHibernateSessionService;

public class DiscoveryThreadUnitTest extends MockObjectTestCase {
    private InetAddress TEN_ONEFIFTY_TWO_THIRTY;
    private Mock mockDeviceCommander;
    private Mock mockLegacyDeviceCommander;
    private Mock mockDeviceService;

    protected void setUp() throws Exception {
        super.setUp();
        TEN_ONEFIFTY_TWO_THIRTY = InetAddress.getByName("10.150.2.30");
        mockDeviceCommander = mock(IDeviceDiscoveryService.class);
        mockLegacyDeviceCommander = mock(IDeviceDiscoveryService.class);
        mockDeviceService = mock(IHibernateSessionService.class);
    }

    public void testDiscoverDevicesDelegatesToDeviceCommander() throws Exception {
        expectDiscovery();
        expectSessionClose();
        DiscoveryThread discoveryThread = new DiscoveryThread(TEN_ONEFIFTY_TWO_THIRTY, (IDeviceDiscoveryService) mockLegacyDeviceCommander.proxy(), (IDeviceDiscoveryService) mockDeviceCommander.proxy(), (IHibernateSessionService) mockDeviceService.proxy());
        discoveryThread.discoverDevices();
    }

    public void testFailingWDMAgentDiscoveryTriggersLegacyDiscovery() {
        expectFailedDiscovery();
        expectLegacyDiscovery();
        expectSessionClose();
        DiscoveryThread discoveryThread = new DiscoveryThread(TEN_ONEFIFTY_TWO_THIRTY, (IDeviceDiscoveryService) mockLegacyDeviceCommander.proxy(), (IDeviceDiscoveryService) mockDeviceCommander.proxy(), (IHibernateSessionService) mockDeviceService.proxy());
        discoveryThread.discoverDevices();
    }

    public void testFailingDiscoveryClosesSession() {
        expectFailedDiscovery();
        expectFailedLegacyDiscovery();
        expectSessionClose();
        DiscoveryThread discoveryThread = new DiscoveryThread(TEN_ONEFIFTY_TWO_THIRTY, (IDeviceDiscoveryService) mockLegacyDeviceCommander.proxy(), (IDeviceDiscoveryService) mockDeviceCommander.proxy(), (IHibernateSessionService) mockDeviceService.proxy());
        discoveryThread.discoverDevices();
    }

    private void expectSessionClose() {
        mockDeviceService.expects(once()).method("closeSession");
    }

    private void expectLegacyDiscovery() {
        mockLegacyDeviceCommander.expects(once()).method("discover").with(eq(TEN_ONEFIFTY_TWO_THIRTY));
    }

    private void expectFailedLegacyDiscovery() {
        mockLegacyDeviceCommander.expects(once()).method("discover").with(eq(TEN_ONEFIFTY_TWO_THIRTY)).will(throwException(new RuntimeException("Legacy discovery failed")));
    }

    private void expectFailedDiscovery() {
        mockDeviceCommander.expects(once()).method("discover").with(eq(TEN_ONEFIFTY_TWO_THIRTY)).will(throwException(new RuntimeException("New Device Discovery Failed")));
    }

    private void expectDiscovery() {
        mockDeviceCommander.expects(once()).method("discover").with(eq(TEN_ONEFIFTY_TWO_THIRTY));
    }
}
