/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 7462 $
Last Modified: $Date: 2007-05-29 16:08:17 +0530 (Tue, 29 May 2007) $
Last Modified By: $Author: ijibanandaray $
*/

package com.wyse.rapport.services.discovery;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import org.jmock.Mock;

import com.wyse.rapport.command.MessageConstants;
import com.wyse.rapport.command.XMLResultsFixture;
import com.wyse.rapport.configuration.UserPreference;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.server.RapportServer;
import com.wyse.rapport.services.RapportDBTestCase;
import com.wyse.rapport.services.command.DeviceCommunicationService;
import com.wyse.rapport.services.command.IDeviceCommunicationService;
import com.wyse.rapport.services.deviceinterface.EventChainFactory;
import com.wyse.rapport.services.persistence.DeviceRepository;
import com.wyse.rapport.services.persistence.DiscoveryProgressRepository;
import com.wyse.rapport.services.persistence.DiscoveryRangesRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.util.WDMConstants;
import com.wyse.rapport.util.WDMUtil;
import com.wyse.rapport.wnom.WnomConstants;

/** Ensures the behavior of the DeviceDiscoveryService */
public class DeviceDiscoveryServiceUnitTest extends RapportDBTestCase {
    private InetAddress TEN_ONEFIFTY_TWO_THIRTY;
    private InetAddress TEN_ONEFIFTY_TWO_THIRTYONE;
    private static final String DEVICE_GUID = MessageConstants.Values.BOGUS_GUID;
    private static final String MAC = WDMConstants.BOGUS_MAC;
    private static final String IP = "192.168.1.1";
    private static final String DEVICE_ADDRESS = "1.2.3.4";
    private static final String EXPECTED_RESPONSE_FOR_GET_ASSETS = XMLResultsFixture.deviceWithMac(MAC, IP, DEVICE_GUID);
    private static final String EXPECTED_RESPONSE_FOR_GET_ASSETS_WITH_TWO_NICS = XMLResultsFixture.fullAsset(DEVICE_GUID, MAC, IP, 2);
    private Mock mockDeviceCommunicationService;
    private InetAddress inet;
    private DeviceRepository deviceRepository;
    private DeviceDiscoveryService deviceDiscoveryService;
    
    private DiscoveryProgressRepository discoveryProgressService;
    private Mock mockSettingsRepository;

    protected void setUp() throws Exception {
        super.setUp();
        RapportServer.DEFAULT_DEVICES_ALLOWED=10;
        TEN_ONEFIFTY_TWO_THIRTY = InetAddress.getByName("10.150.2.30");
        TEN_ONEFIFTY_TWO_THIRTYONE = InetAddress.getByName("10.150.2.31");
        deviceRepository = new DeviceRepository(sessionService);
        discoveryProgressService = new DiscoveryProgressRepository(sessionService, new DiscoveryRangesRepository(sessionService));
        
        mockDeviceCommunicationService = mock(IDeviceCommunicationService.class);
        mockSettingsRepository = mock(IUserPreferencesRepository.class);
        
        EventChainFactory factory = new EventChainFactory(sessionService, deviceRepository, new DeviceCommunicationService());
        
        deviceDiscoveryService = new DeviceDiscoveryService(deviceRepository,
                                                            (IDeviceCommunicationService) mockDeviceCommunicationService.proxy(),
                                                            discoveryProgressService, factory, (IUserPreferencesRepository) mockSettingsRepository.proxy());
        inet = InetAddress.getByName(DEVICE_ADDRESS);
      	System.setProperty(WnomConstants.PRODUCT_NAME,"WDM");
        discoveryProgressService.deleteAll();
        evict();
    }

    public void testDiscoverDevice() throws UnknownHostException {
        expectDiscovery(inet, EXPECTED_RESPONSE_FOR_GET_ASSETS);
        deviceDiscoveryService.discover(inet);
        assertNotNull(device());
    }

    public void testDevicePersistanceAndRetrieval() throws IOException {
        expectDiscovery(inet, EXPECTED_RESPONSE_FOR_GET_ASSETS);
        deviceDiscoveryService.discover(inet);
        DeviceInfo actual = deviceRepository.findByGuid(DEVICE_GUID);
        assertNotNull(actual);
        DeviceNetworkInfo deviceNetwork = actual.getActiveNetwork();
        assertEquals(MAC, WDMUtil.formatMac(deviceNetwork.getMacAddress()));
        assertEquals(IP, deviceNetwork.getIpAddress());
    }

    public void testUpdatesExistingDeviceOnRediscovery() throws IOException {
        expectDiscovery(inet, EXPECTED_RESPONSE_FOR_GET_ASSETS);
        deviceDiscoveryService.discover(inet);
        DeviceInfo device = device();
        device.nextCommandOnBoot(60000);
        deviceRepository.createOrUpdate(device);
        expectDiscovery(inet, EXPECTED_RESPONSE_FOR_GET_ASSETS);
        deviceDiscoveryService.discover(inet);
        assertEquals(device, device());
    }

    public void testUpdateDeviceReturnsOnlyNewNetworksForAnExistingDevice() throws Exception {
        expectDiscovery(inet, EXPECTED_RESPONSE_FOR_GET_ASSETS);
        deviceDiscoveryService.discover(inet);
        evict();

        expectDiscovery(inet, EXPECTED_RESPONSE_FOR_GET_ASSETS_WITH_TWO_NICS);
        deviceDiscoveryService.discover(inet);

        DeviceInfo updatedDevice = device();
        assertEquals(2, updatedDevice.getDeviceNetworks().size());
    }

    public void testMultipleDiscoveriesUpdateDevice() throws Exception {
        DeviceRepository ds = new DeviceRepository(sessionService);
        expectDiscovery(TEN_ONEFIFTY_TWO_THIRTY, EXPECTED_RESPONSE_FOR_GET_ASSETS);

        EventChainFactory factory = new EventChainFactory(sessionService, deviceRepository, new DeviceCommunicationService());
        DeviceDiscoveryService service = new DeviceDiscoveryService(ds, (IDeviceCommunicationService) mockDeviceCommunicationService.proxy(), discoveryProgressService, factory, (IUserPreferencesRepository) mockSettingsRepository.proxy());
        service.discover(TEN_ONEFIFTY_TWO_THIRTY);
        evict();

        assertEquals(IP, device().getActiveIp());

        expectDiscovery(TEN_ONEFIFTY_TWO_THIRTYONE, XMLResultsFixture.deviceWithMac(MAC, "10.150.2.31", DEVICE_GUID));
        service.discover(TEN_ONEFIFTY_TWO_THIRTYONE);

        DeviceInfo device = device();
        evict();

        assertEquals("10.150.2.31", device.getActiveIp());
    }

    public void testErrorsDueToGarbageResponseArePropagated() throws IOException {
        mockDeviceCommunicationService.expects(once())
                .method("sendCommand")
                .with(eq(inet), ANYTHING)
                .will(returnValue("This is not a valid response"));
        try {
            deviceDiscoveryService.discover(inet);
            fail();
        } catch (RuntimeException e) {

        }
    }

    private void expectDiscovery(InetAddress inet, String getAssetsResponse) {
        mockDeviceCommunicationService.expects(once())
                .method("sendCommand")
                .with(eq(inet), ANYTHING);
        mockDeviceCommunicationService.expects(once())
                .method("sendCommand")
                .with(eq(inet), ANYTHING)
                .will(returnValue(getAssetsResponse));
        expectCheckinInterval();
    }

    private DeviceInfo device() {
        return deviceRepository.findByGuid(DEVICE_GUID);
    }

    private void expectCheckinInterval() {
        UserPreferences settings = new UserPreferences();
        settings.setUserPreference(new UserPreference(UserPreferences.CHECKIN_INTERVAL, "3600", UserPreferences.SECONDS));
        mockSettingsRepository.expects(once()).method("findAll").will(returnValue(settings));
    }
}
