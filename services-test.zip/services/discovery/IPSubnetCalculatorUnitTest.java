/*
Copyright (c) Wyse Technology, Inc.

Current Revision: $Rev: 4809 $
Last Modified: $Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.discovery;

import junit.framework.TestCase;

import com.wyse.rapport.businesslogic.iprange.IPRange;

public class IPSubnetCalculatorUnitTest extends TestCase {
    private static final String dummyIP = "1.1.1.1";

    public void testGetCorerectSubnetMask() {
        IPSubnetCalculator subnetCalc = new IPSubnetCalculator("255.224.255.0", dummyIP);
        String correctedMask = subnetCalc.correctMask();
        assertEquals("255.224.0.0", correctedMask);
    }

    public void testGetNetworkAddress() {
        IPSubnetCalculator subnetCalc = new IPSubnetCalculator("255.255.192.0", "172.16.1.1");
        String newtworkAddress = subnetCalc.subnetAddress();
        assertEquals("172.16.0.0", newtworkAddress);
    }

    public void testGetNumberOfHostsPerNetwork() {
        long ipVector = 0L;
        IPSubnetCalculator subnetCalc = new IPSubnetCalculator("255.0.0.0", dummyIP);
        ipVector = subnetCalc.numberOfHostsPerNetwork();
        assertTrue(ipVector == 16777214);

        subnetCalc = new IPSubnetCalculator("255.128.0.0", dummyIP);
        ipVector = subnetCalc.numberOfHostsPerNetwork();
        assertTrue(ipVector == 8388606);

        subnetCalc = new IPSubnetCalculator("255.255.0.0", dummyIP);
        ipVector = subnetCalc.numberOfHostsPerNetwork();
        assertTrue(ipVector == 65534);

        subnetCalc = new IPSubnetCalculator("255.255.128.0", dummyIP);
        ipVector = subnetCalc.numberOfHostsPerNetwork();
        assertTrue(ipVector == 32766);

        subnetCalc = new IPSubnetCalculator("255.255.255.0", dummyIP);
        ipVector = subnetCalc.numberOfHostsPerNetwork();
        assertTrue(ipVector == 254);

        subnetCalc = new IPSubnetCalculator("255.255.255.128", dummyIP);
        ipVector = subnetCalc.numberOfHostsPerNetwork();
        assertTrue(ipVector == 126);
    }

    public void testCalculateIpRanges() {
        IPSubnetCalculator subnetCalc = new IPSubnetCalculator("255.255.255.128", "172.16.2.38");
        IPRange ipRange = subnetCalc.ipRange();
        assertEquals("172.16.2.1", ipRange.getStartIP());
        assertEquals("172.16.2.126", ipRange.getEndIP());
    }

    public void testGetEndIPAddress() {
        IPSubnetCalculator subnetCalc = new IPSubnetCalculator("255.255.224.0", "192.168.2.28");
        String network = subnetCalc.subnetAddress();
        String startIP = network.substring(0, network.lastIndexOf('.'))
                         + "." + (subnetCalc.prefferedOctect(network, 4) + 1);

        long noOfHostsPerNet = subnetCalc.numberOfHostsPerNetwork();
        String endIP = subnetCalc.endIP(startIP, noOfHostsPerNet);
        assertEquals("192.168.31.254", endIP);
    }

    public void testGetNetworkBits() {
        IPSubnetCalculator subnetCalc = new IPSubnetCalculator("255.255.192.0", dummyIP);
        int netBits = subnetCalc.networkBits();

        assertEquals(18, netBits);
    }
}
