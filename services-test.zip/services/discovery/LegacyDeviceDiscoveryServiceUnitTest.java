/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 4809 $
Last Modified: $Date: 2006-08-10 09:44:46 +0530 (Thu, 10 Aug 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.discovery;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.jmock.Mock;
import org.jmock.MockObjectTestCase;

import com.wyse.rapport.services.command.IDeviceCommunicationService;

/** Ensures behaviour of the LegacyDeviceDiscoveryService */
public class LegacyDeviceDiscoveryServiceUnitTest extends MockObjectTestCase {
    private InetAddress legacyDeviceAddress;

    protected void setUp() throws Exception {
        super.setUp();
        legacyDeviceAddress = InetAddress.getByName("1.2.3.4");
    }

    public void testContactsLegacyDevices() throws UnknownHostException {
        Mock mockDeviceCommunicationService = mock(IDeviceCommunicationService.class);
        mockDeviceCommunicationService.expects(once()).method("sendCommand").with(eq(legacyDeviceAddress), ANYTHING);
        LegacyDeviceDiscoveryService service = new LegacyDeviceDiscoveryService((IDeviceCommunicationService) mockDeviceCommunicationService.proxy(), "host", 123);
        service.discover(legacyDeviceAddress);
    }
}
