/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 5110 $
Last Modified: $Date: 2006-08-31 12:32:57 +0530 (Thu, 31 Aug 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.legacy;

import com.wyse.rapport.util.MacAddress;

public class LegacyCheckinString {
    public static final String MAC = MacAddress.format("0011CCDDEE00");
    public static final String IP = "172.19.1.154";
    public static final String BLAZER_FULL_CHECKIN =
            "&V10|&IMAC=0080642a7519|CS=1|TP=1|P1=6|IM=4.4.055f|IP=" + IP + "|SM=255.255.255.0|SN=10.150.5.255|GW=10.150.5.1|ED=1|SN#=9QB8D900143|CN=WT0080642a7519|RM=32768|FS=16|DS=10.150.2.10|DM=wyse.com|1D=10.150.2.10|2D=10.150.2.16|1W=10.150.2.14|";

    public static String heartBeat(String macAddress) {
        return "&V03|&IMAC=" + macAddress + "|CID=35|IT=60|WFE=1|WF=" + LegacyDeviceCheckinService.DISABLE_WRITE_FILTER;
    }

    public static String heartBeat() {
        return heartBeat(MAC);
    }

    public static String fullAsset(boolean hasCustomFields) {
        return fullAsset(MAC, IP, hasCustomFields);
    }

    public static String fullAsset(String macAddress, String ipAddress, boolean hasCustomFields) {
        String custom1 = "xxx", custom2 = "yyy", custom3 = "zzz";
        if (!hasCustomFields) {
            custom1 = "";
            custom2 = "";
            custom3 = "";
        }
        return
                "&V01|&IMAC=" + macAddress + "|CID=30|OS=23|VI=1|AL=\\windows|AV=4.0.5.3|P1=15|TZ=PacificDaylightTime|TZO=-420|" +
                "MD=2005-01|CN=LegacyMock|DM=wyse.com|ED=1|SM=255.255.255.0|IP=" + ipAddress + "|GW=172.19.1.254|DS=172.19.1.253|" +
                "SN=172.19.1.255|CS=2|FS=64|0D=1|1D=132.237.1.97|2D=132.237.1.96|0W=1|IM=537.0|CP=VIAEdenNehemiah|NS=0|B1=|PD2=|" +
                "PD1=Internal|RM=131072|SN#=6361E100050|CO=|LO=|C1=" + custom1 + "|C2=" + custom2 + "|C3=" + custom3 + "|AP0=ELOTOUCHUSB||2.0|AP1=SLOCKICAVC||2.0|AP2=PPPoE||1.0|" +
                "AP3=SCRLOCK||1.0|AP4=CERTIFICATES||1.00|AP5=Rapport||4.0.5.3|AP6=ERICOM||7.2.0|AP7=RSHADOW||2.0|AP8=MS-Storage|" +
                "|3.0|AP9=ACTIONTEC||Wireless|AP10=PPTP||1.1|AP11=PCSC_DRIVER||2.0|AP12=Edgeport||3.0.0.0/2.0.0.1|" +
                "AP13=USBMGCOM||1.0|AP14=SNMP||2.1|AP15=JETCET||3.01|AP16=SCRSAVER||1.0|AP17=ELOTOUCH||1.0|AP18=AIRONET||2.20|" +
                "AP19=DIALUP||2.1|AP20=USBModem||1.00|AP21=IE||6.0|AP22=ICA||8.32|AP23=RDP||5.5|";
    }

    public static String fullAssetWithPlatformAgentId(int osTypeId, int platformAgentId) {
        return
                "&V01|&IMAC=" + MAC + "|CID=30|OS="+osTypeId+"|VI=1|AL=\\windows|AV=4.0.5.3|P1="+platformAgentId+"|TZ=PacificDaylightTime|TZO=-420|" +
                "MD=2005-01|CN=LegacyMock|DM=wyse.com|ED=1|SM=255.255.255.0|IP=" + IP + "|GW=172.19.1.254|DS=172.19.1.253|" +
                "SN=172.19.1.255|CS=2|FS=64|0D=1|1D=132.237.1.97|2D=132.237.1.96|0W=1|IM=537.0|CP=VIAEdenNehemiah|NS=0|B1=|PD2=|" +
                "PD1=Internal|RM=131072|SN#=6361E100050|CO=|LO=|C1=|C2=|C3=|AP0=ELOTOUCHUSB||2.0|AP1=SLOCKICAVC||2.0|AP2=PPPoE||1.0|" +
                "AP3=SCRLOCK||1.0|AP4=CERTIFICATES||1.00|AP5=Rapport||4.0.5.3|AP6=ERICOM||7.2.0|AP7=RSHADOW||2.0|AP8=MS-Storage|" +
                "|3.0|AP9=ACTIONTEC||Wireless|AP10=PPTP||1.1|AP11=PCSC_DRIVER||2.0|AP12=Edgeport||3.0.0.0/2.0.0.1|" +
                "AP13=USBMGCOM||1.0|AP14=SNMP||2.1|AP15=JETCET||3.01|AP16=SCRSAVER||1.0|AP17=ELOTOUCH||1.0|AP18=AIRONET||2.20|" +
                "AP19=DIALUP||2.1|AP20=USBModem||1.00|AP21=IE||6.0|AP22=ICA||8.32|AP23=RDP||5.5|";
    }

    public static String fullCheckin(boolean dnsAuto, boolean winsAuto) {
        String dnsAutoVal = dnsAuto ? "1" : "0";
        String winsAutoVal = winsAuto ? "1" : "0";
        return "&V01|&IMAC=" + MAC + "|CID=30|OS=5|VI=1|AL=\\windows|AV=4.0.5.3|P1=15|TZ=PacificDaylightTime|TZO=-420|" +
               "MD=2005-01|CN=WBT008064134A35|DM=wyse.com|ED=1|SM=255.255.255.0|IP=" + IP + "|GW=172.19.1.254|DS=172.19.1.253|" +
               "SN=172.19.1.255|CS=2|FS=64|0D=" + dnsAutoVal + "|1D=132.237.1.97|2D=132.237.1.96|0W=" + winsAutoVal + "|IM=537.0|CP=VIAEdenNehemiah|NS=0|B1=|PD2=|" +
               "PD1=Internal|RM=131072|SN#=6361E100050|CO=|LO=|C1=|C2=|C3=|AP0=ELOTOUCHUSB||2.0|AP1=SLOCKICAVC||2.0|AP2=PPPoE||1.0|" +
               "AP3=SCRLOCK||1.0|AP4=CERTIFICATES||1.00|AP5=Rapport||4.0.5.3|AP6=ERICOM||7.2.0|AP7=RSHADOW||2.0|AP8=MS-Storage|" +
               "|3.0|AP9=ACTIONTEC||Wireless|AP10=PPTP||1.1|AP11=PCSC_DRIVER||2.0|AP12=Edgeport||3.0.0.0/2.0.0.1|" +
               "AP13=USBMGCOM||1.0|AP14=SNMP||2.1|AP15=JETCET||3.01|AP16=SCRSAVER||1.0|AP17=ELOTOUCH||1.0|AP18=AIRONET||2.20|" +
               "AP19=DIALUP||2.1|AP20=USBModem||1.00|AP21=IE||6.0|AP22=ICA||8.32|AP23=RDP||5.5|";
    }

    public static String scriptCompletion(String activeMac, boolean success) {
        if (success) {
            return "&V01|&IMAC=" + MAC + "|IN=1|WISard-pull-Success";
        }
        return "&V01|&IMAC=" + MAC + "|ER=1|WISard-pull-Failure";
    }
}
