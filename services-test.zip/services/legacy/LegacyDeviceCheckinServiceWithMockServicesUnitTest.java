/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.legacy;

import java.util.Date;

import org.jmock.Mock;

import com.domainlanguage.time.Duration;
import com.domainlanguage.time.TimePoint;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.UUIDTestCase;
import com.wyse.rapport.db.tbl.UserPreferences;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IDiscoveryProgressRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.services.persistence.SystemLogService;

public class LegacyDeviceCheckinServiceWithMockServicesUnitTest extends UUIDTestCase {
    private static String IP = "10.150.2.10";
    private static String MAC = "11:22:22:11:11:22";
    private LegacyDeviceCheckinService checkinService;
    private LegacyQueryParser parser;
    private Mock mockDeviceRepository;
    private Mock mockDiscoveryProgressRepository;
    private Mock mockUserPreferenceRepository;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        mockDeviceRepository = mock(IDeviceRepository.class);
        mockDiscoveryProgressRepository = mock(IDiscoveryProgressRepository.class);
        mockUserPreferenceRepository = mock(IUserPreferencesRepository.class);
        parser = new LegacyQueryParser(LegacyCheckinString.fullAsset(MAC, IP, true), IP);
        initCheckinService();
        checkinService.systemLogService = doNothingLogger();
    }

    public void testCheckinAddsToDiscoveredDeviceCountWhenNoDeviceFoundInDB() {
        expectation(null);
        mockDeviceRepository.expects(once()).method("findByMac").with(eq(MAC)).will(returnValue(null));
        mockDeviceRepository.expects(once()).method("getLastLegacyId").will(returnValue(new Long(1)));
        mockDeviceRepository.expects(once()).method("isLicenseLimitExceeded").will(returnValue(false));
        checkinService.checkin(parser);
        mockDeviceRepository.verify();
        mockDiscoveryProgressRepository.verify();
    }

    private SystemLogService doNothingLogger() {
        return new SystemLogService(null) {
        	@Override
        	public void info(String msg, Device device) {
        	
        	}
            
        };
    }

    public void testCheckinAddsToDiscoveredDeviceCountWhenDeviceFoundInDB() {
        expectation(device());
        checkinService.checkin(parser);
        mockDeviceRepository.verify();
        mockDiscoveryProgressRepository.verify();
    }

    public void testHeartbeatAddsToDiscoveredDeviceCountWhenNoDeviceFoundInDB() {
    	mockDeviceRepository.expects(once()).method("findLegacyDeviceByMac").with(eq(MAC)).will(returnValue(null));
        checkinService.heartbeat(parser);
        mockDeviceRepository.verify();
    }

    public void testHeartBeatAddsToDiscoveredDeviceCountWhenDeviceFoundInDB() {
        expectation(device());
        checkinService.heartbeat(parser);
        mockDeviceRepository.verify();
        mockDiscoveryProgressRepository.verify();
    }

    public void testUpdatesNextCheckinTimeOnCheckin() throws Exception {
        DeviceInfo device = device();
        Date checkin = TimePoint.from(new Date()).minus(Duration.hours(1)).asJavaUtilDate();
        device.setCheckIn(checkin);
        expectation(device);
        checkinService.checkin(parser);
        assertTrue(device.getCheckIn().after(checkin));
        assertTrue(device.getNextAssetReportExpected().after(device.getCheckIn()));
    }

    public void testUpdatesNextCheckinTimeOnHeartbeat() throws Exception {
        DeviceInfo device = device();
        Date checkin = TimePoint.from(new Date()).minus(Duration.hours(1)).asJavaUtilDate();
        device.setCheckIn(checkin);
        expectation(device);
        checkinService.heartbeat(parser);
        assertTrue(device.getCheckIn().after(checkin));
        assertTrue(device.getNextAssetReportExpected().after(device.getCheckIn()));
    }

    private DeviceInfo device() {
        return new DeviceFixture().createDeviceWithNetworks(IP, MAC);
    }

    private void initCheckinService() {
        checkinService = new LegacyDeviceCheckinService(null);
        checkinService.setDeviceRepository((IDeviceRepository) mockDeviceRepository.proxy());
        checkinService.setDiscoveryProgressRepository((IDiscoveryProgressRepository) mockDiscoveryProgressRepository.proxy());
        checkinService.setUserPreferenceRepository((IUserPreferencesRepository) mockUserPreferenceRepository.proxy());
    }

    private void expectation(DeviceInfo device) {
        mockUserPreferenceRepository.expects(once()).method("findAll").will(returnValue(new UserPreferences()));
        mockDeviceRepository.expects(once()).method("findLegacyDeviceByMac").with(eq(MAC)).will(returnValue(device));
        mockDeviceRepository.expects(once()).method("createOrUpdate");
        mockDiscoveryProgressRepository.expects(once()).method("discovered").with(eq(IP));
    }
}
