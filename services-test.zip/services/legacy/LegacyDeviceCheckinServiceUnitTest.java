/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 6246 $
Last Modified: $Date: 2006-11-18 14:59:57 +0530 (Sat, 18 Nov 2006) $
Last Modified By: $Author: smariswamy $
*/

package com.wyse.rapport.services.legacy;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jmock.Mock;
import org.junit.Test;

import com.wyse.common.MacIDGenerator;
import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.deviceinterface.LegacyDeviceRequest;
import com.wyse.rapport.services.RapportDBTestCase;
import com.wyse.rapport.services.persistence.DeviceRepository;
import com.wyse.rapport.util.MacAddress;
import com.wyse.rapport.util.OSTypes;

public class LegacyDeviceCheckinServiceUnitTest extends RapportDBTestCase {
    private static final String MAC = MacAddress.format("0011CCDDEE00");
    private DeviceRepository deviceRepository;
    private LegacyDeviceCheckinService service;

    protected void setUp() throws Exception {
        super.setUp();
        service = new LegacyDeviceCheckinService(sessionService);
        deviceRepository = new DeviceRepository(sessionService);
        deviceRepository.deleteAll();
    }

    public void testRediscoveryUpdatesCustomField() throws Exception {
        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullAsset(false), LegacyCheckinString.IP);
        service.checkin(parser);
        evict();
        
        parser = new LegacyQueryParser(LegacyCheckinString.fullAsset(true), LegacyCheckinString.IP);
        service.checkin(parser);

        DeviceInfo device = deviceRepository.findLegacyDeviceByMac(LegacyCheckinString.MAC);
        evict();
        
        assertEquals("xxx", device.getCustomValue("custom1").getValue());
        assertEquals("yyy", device.getCustomValue("custom2").getValue());
        assertEquals("zzz", device.getCustomValue("custom3").getValue());
    }

    public void testLegacyFullCheckinForOSName() {
        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullAsset("008064535224", "1.1.1.1", true), "1.1.1.1");
        service.checkin(parser);
        evict();

        DeviceInfo dev = deviceRepository.findLegacyDeviceByMac(MacAddress.format("008064535224"));
        assertEquals(OSTypes.legacyOsName(new Long(23)), dev.getOsName());
        assertEquals(OSTypes.WYSE_LINUX_V6, dev.getOsName());
    }

    // blazer does not send OS type/name
    public void testDeviceOSNameIsSetToBlazerForBlazerCheckin() {
        HttpServletRequest blazerRequest = mockRequest(LegacyCheckinString.BLAZER_FULL_CHECKIN);
        HttpServletResponse blazerResponse = mockResponse();
        LegacyDeviceRequest request = new LegacyDeviceRequest(blazerRequest, blazerResponse, service);
        request.handle();
        evict();
        DeviceInfo dev = deviceRepository.findLegacyDeviceByMac(MacAddress.format("0080642a7519"));
        assertEquals(OSTypes.legacyOsName(new Long(9)), dev.getOsName());
    }

    public void testHeartBeatDoesNotEraseDeviceDetails() throws Exception {
        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullAsset(false), "172.19.1.154");
        service.checkin(parser);
        evict();

        parser = new LegacyQueryParser(LegacyCheckinString.heartBeat(), "172.19.1.154");
        service.heartbeat(parser);

        DeviceInfo device = deviceRepository.findLegacyDeviceByMac(LegacyCheckinString.MAC);
        evict();
        device = deviceRepository.findLegacyDeviceByMac(LegacyCheckinString.MAC);
        DeviceNetworkInfo activeNetwork = device.getActiveNetwork();
        assertEquals("172.19.1.154", activeNetwork.getIpAddress());
        assertEquals("132.237.1.97", activeNetwork.getDnsServer1());
        assertEquals(LegacyCheckinString.MAC, activeNetwork.getMacAddress());
    }

    public void testSetLegacyIdForADevice() throws Exception {
        DeviceInfo device1 = deviceWithLegacyId(123, true);
        service.persistDevice(device1);
        DeviceInfo device2 = deviceWithLegacyId(0, true);
        service.createDevice(device2);

        DeviceInfo retrieved = deviceRepository.findByGuid(device2.getDeviceGuid());
        assertEquals(Long.valueOf(124), retrieved.getLegacyId());
    }

    public void testCreateDeviceReassignsLegacyIdForAFreshDevice() throws Exception {
        DeviceInfo device = deviceWithLegacyId(123, true);
        service.createDevice(device);

        DeviceInfo retrieved = deviceRepository.findByGuid(device.getDeviceGuid());
        assertEquals(Long.valueOf(1), retrieved.getLegacyId());
    }

    public void testCheckinCreatesANewDeviceWhenNoDeviceWithMacFound() throws Exception {
        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullAsset(false), LegacyCheckinString.IP);
        service.checkin(parser);

        assertNotNull(deviceRepository.findLegacyDeviceByMac(LegacyCheckinString.MAC));
    }

    public void testHeartBeatDoesNotCreateDeviceWhenDeviceWithMacDoesNotExist() throws Exception {
        String macID = MacIDGenerator.nextMacID();
        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.heartBeat(macID), LegacyCheckinString.IP);
        service.heartbeat(parser);
        assertNull(deviceRepository.findByMac(macID));
        assertNull(deviceRepository.findLegacyDeviceByMac(macID));
    }

    public void testCheckinDoesNotCreatesANewDeviceWhenANonLegacyDeviceWithMacFound() throws Exception {
        DeviceInfo device = new DeviceFixture().createDeviceWithNetworks(LegacyCheckinString.IP, LegacyCheckinString.MAC);
        deviceRepository.create(device);
        evict();

        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullAsset(false), LegacyCheckinString.IP);
        service.checkin(parser);

        assertNull(deviceRepository.findLegacyDeviceByMac(LegacyCheckinString.MAC));
    }

    public void testCheckinUpdatesLegacyDeviceWhenALegacyDeviceWithMacFound() throws Exception {
        DeviceInfo device = new DeviceFixture().createDeviceWithNetworks(LegacyCheckinString.IP, LegacyCheckinString.MAC);
        device.setLegacy(true);
        deviceRepository.create(device);
        evict();

        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullAsset(false), "10.150.2.114");
        service.checkin(parser);

        DeviceInfo retrievedDevice = deviceRepository.findLegacyDeviceByMac(LegacyCheckinString.MAC);
        assertNotNull(retrievedDevice);
        assertEquals("10.150.2.114", retrievedDevice.getActiveIp());
    }

    public void testDnsAutoSetToTrueWhenCheckinHasOne() throws Exception {
        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullCheckin(true, false), "10.150.2.114");
        service.checkin(parser);

        DeviceInfo retrieved = deviceRepository.findByMac(MAC);
        assertTrue(retrieved.getActiveNetwork().getDnsAuto());
        assertFalse(retrieved.getActiveNetwork().getWinsAuto());
    }

    public void testDnsAutoSetToFalseWhenCheckinHasZero() throws Exception {
        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullCheckin(false, true), "10.150.2.114");
        service.checkin(parser);

        DeviceInfo retrieved = deviceRepository.findByMac(MAC);
        assertFalse(retrieved.getActiveNetwork().getDnsAuto());
        assertTrue(retrieved.getActiveNetwork().getWinsAuto());
    }
    
    @Test
	public void testModelForVX0SeriesModel() throws Exception {
    	 LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullAssetWithPlatformAgentId(23, 15), "10.150.2.114");
    	 service.checkin(parser);
    	 DeviceInfo retrieved = deviceRepository.findByMac(MAC);
    	 evict();
    	 assertEquals("V50" ,retrieved.getModel());
	}

   private DeviceInfo deviceWithLegacyId(long legacyId, boolean isLegacy) {
        DeviceInfo device = new DeviceFixture().createDeviceWithNetworks("10.101.1.1", MacIDGenerator.nextMacID());
        device.setLegacyId(legacyId);
        device.setLegacy(isLegacy);
        return device;
    }

    private HttpServletResponse mockResponse() {
        Mock mockResponse = mock(HttpServletResponse.class);
        mockResponse.expects(atLeastOnce()).method("reset");
        mockResponse.expects(atLeastOnce()).method("resetBuffer");
        mockResponse.expects(atLeastOnce()).method("setHeader");
        return (HttpServletResponse) mockResponse.proxy();
    }

    private HttpServletRequest mockRequest(String requestString) {
        Mock mockRequest = mock(HttpServletRequest.class);
        mockRequest.expects(atLeastOnce()).method("getQueryString").will(returnValue(requestString));
        mockRequest.expects(atLeastOnce()).method("getRemoteAddr").will(returnValue(LegacyCheckinString.IP));
        return (HttpServletRequest) mockRequest.proxy();
    }

}
