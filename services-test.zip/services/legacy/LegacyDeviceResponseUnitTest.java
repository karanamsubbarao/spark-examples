/*
Copyright (c) 2005 Wyse Technology, Inc.
 
Current Revision: $Rev: 4351 $
Last Modified: $Date: 2006-06-19 14:57:34 +0530 (Mon, 19 Jun 2006) $
Last Modified By: $Author: myadav $
*/

package com.wyse.rapport.services.legacy;

import com.wyse.rapport.db.tbl.UUIDTestCase;

/** @author smariswamy */
public class LegacyDeviceResponseUnitTest extends UUIDTestCase {
    private LegacyDeviceResponseService service = new LegacyDeviceResponseService();

    public void testWhetherPatchRequiredForHAgentVersionAbove4052() throws Exception {
        String hAgentVersion = "4.1.0.0";
        assertTrue(service.isPatchRequired(hAgentVersion));
    }

    public void testWhetherPatchRequiredBelow4052() throws Exception {
        String hAgentVersion = "4.0.5.1";
        assertFalse(service.isPatchRequired(hAgentVersion));
    }

    public void testWhetherPatchRequiredForHAgentsEquals4052() throws Exception {
        String hAgentVersion = "4.0.5.2";
        assertTrue(service.isPatchRequired(hAgentVersion));
    }
}
