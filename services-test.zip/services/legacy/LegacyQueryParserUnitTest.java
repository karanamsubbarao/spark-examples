/*
Copyright (c) 2005 Wyse Technology, Inc.
Current Revision: $$Rev$$
Last Modified: $$Date$$
Last Modified By: $$Author$$
*/

package com.wyse.rapport.services.legacy;

import java.util.List;

import junit.framework.TestCase;

import org.junit.Test;

import com.wyse.rapport.db.tbl.DeviceFixture;
import com.wyse.rapport.db.tbl.DeviceInfo;

public class LegacyQueryParserUnitTest extends TestCase {
    private static final String IP = "10.150.2.114";
    private static final String EMPTY_LEGACY_DEVICE_RESPONSE = "&V10|";
    private static final String INVALID_REQUEST = "V10|";
    private static final String LEGACY_DEVICE_RESPONSE_WITH_NETWORK =
            "&V03|&IMAC=00:12:13:80:88:14|IP=" + IP + "|";

    public void testEmptyDevice() {
        LegacyQueryParser parser = new LegacyQueryParser(EMPTY_LEGACY_DEVICE_RESPONSE, IP);
        assertNull(parser.device());
    }

    public void testDeviceWithNetworks() {
        LegacyQueryParser parser = new LegacyQueryParser(LEGACY_DEVICE_RESPONSE_WITH_NETWORK, IP);
        DeviceInfo actual = parser.device();
        assertTrue(actual.isLegacy());

        DeviceInfo expected = new DeviceFixture().createLegacyDeviceWithSimpleNetworkAdapter(null);
        assertEquals(expected, actual);
    }

    public void testPipeSplit() {
        LegacyQueryParser parser = new LegacyQueryParser(EMPTY_LEGACY_DEVICE_RESPONSE, IP);
        List<String> splitValues = parser.pipeSplit("name1=value1|name2=value2|name3=XXX|yyy||", "|");
        assertEquals(5, splitValues.size());
    }

    public void testPipeSplitForEmptyValues() {
        LegacyQueryParser parser = new LegacyQueryParser(EMPTY_LEGACY_DEVICE_RESPONSE, IP);
        List<String> splitValues = parser.pipeSplit("name1=value1|name2=value2|name3=xxx|yyy|||", "|");
        assertEquals("name1=value1", splitValues.get(0));
        assertEquals("name2=value2", splitValues.get(1));
        assertEquals("name3=xxx", splitValues.get(2));
        assertEquals("yyy", splitValues.get(3));
        assertEquals(" ", splitValues.get(4));
        assertEquals(" ", splitValues.get(5));
    }

    public void testDeviceWithCustomData() throws Exception {
        LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.fullAsset(true), IP);
        DeviceInfo actual = parser.device();
        assertEquals("xxx", actual.getCustomValue("custom1").getValue());
        assertEquals("yyy", actual.getCustomValue("custom2").getValue());
        assertEquals("zzz", actual.getCustomValue("custom3").getValue());
    }
    
    @Test
	public void testModelForWyseThinOs() throws Exception {
    	LegacyQueryParser parser = new LegacyQueryParser(LegacyCheckinString.BLAZER_FULL_CHECKIN, IP);
    	parser.setBlazer(true);
        DeviceInfo actual = parser.device();
        assertEquals("Franklin", actual.getModel());
	}

    public void testGetVerbReturnsValidRequestTypeForValidDeviceRequest() throws Exception {
        LegacyQueryParser parser = new LegacyQueryParser(EMPTY_LEGACY_DEVICE_RESPONSE, IP);
        assertEquals(10, parser.getVerb());
    }

    public void testGetVerbReturnsInvalidRequestTypeForInvalidValidDeviceRequest() throws Exception {
        LegacyQueryParser parser = new LegacyQueryParser(INVALID_REQUEST, IP);
        assertEquals(-1, parser.getVerb());
    }
}
