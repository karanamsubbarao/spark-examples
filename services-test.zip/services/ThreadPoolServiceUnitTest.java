package com.wyse.rapport.services;

import junit.framework.TestCase;

/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $Rev: 1358 $
Last Modified: $Date: 2005-10-11 11:50:17 +0530 (Tue, 11 Oct 2005) $
Last Modified By: $Author: vprahlad $
*/

public class ThreadPoolServiceUnitTest extends TestCase {
    public void testIsIdleWhenNoJobHasBeenSubmitted() {
        ThreadPoolService threadPool = new ThreadPoolService(5);
        assertEquals(-1, threadPool.isIdle());
    }

    public void testIsIdleWhenNoJobHasNotCompleted() {
        final Object lock = new Object();
        synchronized (lock) {
            ThreadPoolService threadPool = new ThreadPoolService(5);
            threadPool.submitJob(new Runnable() {
                public void run() {
                    try {
                        synchronized (lock) {
                            lock.wait();
                        }
                    } catch (InterruptedException e) {
                        // do nothing
                    }
                }
            });
            assertEquals(1, threadPool.isIdle());
            lock.notify();
        }
    }
}
