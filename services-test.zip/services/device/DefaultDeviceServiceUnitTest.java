/*
Copyright (c) 2005 Wyse Technology, Inc.

Current Revision: $$Rev: 7293 $$
Last Modified: $$Date: 2007-05-07 17:53:02 +0530 (Mon, 07 May 2007) $$
Last Modified By: $$Author: skaranam $$
*/

package com.wyse.rapport.services.device;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.jmock.Mock;

import com.wyse.rapport.command.DeleteDirectoryCommand;
import com.wyse.rapport.command.DeleteFileCommand;
import com.wyse.rapport.command.DownloadFileFromServerCommand;
import com.wyse.rapport.command.ExecuteOnDeviceCommand;
import com.wyse.rapport.command.GetAssetsCommand;
import com.wyse.rapport.command.ICommand;
import com.wyse.rapport.command.MergeRegistryCommand;
import com.wyse.rapport.command.RebootCommand;
import com.wyse.rapport.command.SetConfigurationCommand;
import com.wyse.rapport.command.ShutdownCommand;
import com.wyse.rapport.command.TasksFactory;
import com.wyse.rapport.command.UninstallFromDeviceCommand;
import com.wyse.rapport.command.UploadFileToServerCommand;
import com.wyse.rapport.configuration.DeviceConfigurationTaskBuilder;
import com.wyse.rapport.db.tbl.Device;
import com.wyse.rapport.db.tbl.DeviceInfo;
import com.wyse.rapport.db.tbl.DeviceNetworkInfo;
import com.wyse.rapport.db.tbl.DeviceTestCase;
import com.wyse.rapport.db.tbl.Schedule;
import com.wyse.rapport.db.tbl.Task;
import com.wyse.rapport.services.persistence.IDeviceRepository;
import com.wyse.rapport.services.persistence.IUserPreferencesRepository;
import com.wyse.rapport.util.WDMUtil;

/** Ensures the behaviour of the default device service. */
public class DefaultDeviceServiceUnitTest extends DeviceTestCase {
    private DefaultDeviceService deviceService;
    private Mock mockDeviceRepository;
    private DeviceInfo device;
    private static final String PATH_TO_SERVER = "path/to/server";

    protected void setUp() throws Exception {
        super.setUp();
        mockDeviceRepository = mock(IDeviceRepository.class);
        deviceService = new DefaultDeviceService((IDeviceRepository) mockDeviceRepository.proxy());
        device = device();
    }

    public void testDeleteMultipleDevices() {
        expectDeviceDeletion("deviceGuid1");
        expectDeviceDeletion("deviceGuid2");
        deviceService.delete(WDMUtil.asList("deviceGuid1", "deviceGuid2"));
    }

    public void testDoesNotDeleteDevicesWithTasksInProgress() {
        mockDeviceRepository.expects(once()).method("findByGuid").with(eq("deviceGuid")).will(returnValue(deviceWithTasksInProgress()));
        deviceService.delete(WDMUtil.asList("deviceGuid"));
    }

    public void testShutdownOneDevice() {
        DeviceInfo device = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice(device.getDeviceGuid(), device);
        deviceService.shutdown(asList(device.getDeviceGuid()));
        assertShutdown(device);
    }

    public void testShutdownTwoDevices() {
        DeviceInfo device1 = deviceWithMockScheduler();
        DeviceInfo device2 = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid1", device1);
        expectDevice("deviceGuid2", device2);
        deviceService.shutdown(asList(new String[] {"deviceGuid1", "deviceGuid2"}));
        assertShutdown(device1);
        assertShutdown(device2);
    }

    public void testRebootOneDevice() {
        DeviceInfo device = deviceWithMockScheduler();
        expectDevice("deviceGuid", device);
        setTaskRetryCount();
        deviceService.reboot(asList("deviceGuid"));
        assertReboot(device);
    }

    public void testRebootTwoDevices() {
        DeviceInfo device1 = deviceWithMockScheduler();
        DeviceInfo device2 = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid1", device1);
        expectDevice("deviceGuid2", device2);
        deviceService.reboot(asList(new String[] {"deviceGuid1", "deviceGuid2"}));
        assertReboot(device1);
        assertReboot(device2);
    }

    public void testUninstallApplicationFromOneDevice() {
        DeviceInfo device = deviceWithMockScheduler();
        expectDevice("deviceGuid", device);
        deviceService.uninstallFromDevice("deviceGuid", "appName", Schedule.now(), 0, false);
        assertUninstall(device, "appName");
    }

    public void testDeleteDirectoryFromOneDevice() {
    	Collection<String> guids=new ArrayList();
    	guids.add("deviceGuid");
        DeviceInfo device = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid", device);
        deviceService.deleteDirectory(guids, "/home/somedir");
        assertDeleteDirectory(device, "/home/somedir");
    }

    public void testDeleteDirectoryFromTwoDevices() {
        DeviceInfo device1 = deviceWithMockScheduler();
        DeviceInfo device2 = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid1", device1);
        expectDevice("deviceGuid2", device2);
        String[] guids = new String[] {"deviceGuid1", "deviceGuid2"};
		deviceService.deleteDirectory(Arrays.asList(guids), "/home/somedir");
        assertDeleteDirectory(device1, "/home/somedir");
        assertDeleteDirectory(device2, "/home/somedir");
    }

    public void testDeleteFileFromOneDevice() {
        DeviceInfo device = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid", device);
		deviceService.deleteFile(WDMUtil.asList("deviceGuid"), "/home/someFile");
        assertDeleteFile(device, "/home/someFile");
    }

    public void testDeleteFileFromTwoDevices() {
        DeviceInfo device1 = deviceWithMockScheduler();
        DeviceInfo device2 = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid1", device1);
        expectDevice("deviceGuid2", device2);
        String[] guids = new String[] {"deviceGuid1", "deviceGuid2"};
		deviceService.deleteFile(Arrays.asList(guids), "/home/someFile");
        assertDeleteFile(device1, "/home/someFile");
        assertDeleteFile(device2, "/home/someFile");
    }

    public void testExecuteOnOneDevice() {
        DeviceInfo device = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid", device);
        deviceService.execute(asList("deviceGuid"), "execLocation", "command", true, false, true);
        assertExecute(device, "execLocation", "command", true, false, true);
    }

    public void testExecuteOnTwoDevices() {
        DeviceInfo device1 = deviceWithMockScheduler();
        DeviceInfo device2 = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid1", device1);
        expectDevice("deviceGuid2", device2);
        deviceService.execute(asList(new String[] {"deviceGuid1", "deviceGuid2"}), "execLocation", "command", true, false, true);
        assertExecute(device1, "execLocation", "command", true, false, true);
        assertExecute(device2, "execLocation", "command", true, false, true);
    }

    public void testDownloadFileFromServerToOneDevice() {
        DeviceInfo device = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid", device);
        deviceService.downloadFileFromServer(asList("deviceGuid"), "/home/someFile", PATH_TO_SERVER);
        assertDownloadFileFromServer(device, "/home/someFile", PATH_TO_SERVER);
    }

    public void testDownloadFileFromServerToTwoDevices() {
        DeviceInfo device1 = deviceWithMockScheduler();
        DeviceInfo device2 = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid1", device1);
        expectDevice("deviceGuid2", device2);
        deviceService.downloadFileFromServer(asList(new String[] {"deviceGuid1", "deviceGuid2"}), "/home/someFile", PATH_TO_SERVER);
        assertDownloadFileFromServer(device1, "/home/someFile", PATH_TO_SERVER);
        assertDownloadFileFromServer(device2, "/home/someFile", PATH_TO_SERVER);
    }

    public void testMergeRegistryOnOneDevice() {
        DeviceInfo device = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid", device);
        deviceService.mergeRegistry(asList("deviceGuid"), PATH_TO_SERVER);
        assertMergeRegistry(device, PATH_TO_SERVER);
    }

    public void testMergeRegistryOnTwoDevices() {
        DeviceInfo device1 = deviceWithMockScheduler();
        DeviceInfo device2 = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid1", device1);
        expectDevice("deviceGuid2", device2);
        deviceService.mergeRegistry(asList(new String[] {"deviceGuid1", "deviceGuid2"}), PATH_TO_SERVER);
        assertMergeRegistry(device1, PATH_TO_SERVER);
        assertMergeRegistry(device2, PATH_TO_SERVER);
    }

    public void testUploadFileToServerFromOneDevice() {
        DeviceInfo device = deviceWithMockScheduler();
        setTaskRetryCount();
        expectDevice("deviceGuid", device);
        deviceService.uploadFileToServer(asList("deviceGuid"), "/home/someFile", PATH_TO_SERVER);
        assertUploadFileToServer(device, "/home/someFile", WDMUtil.getUploadUrl(PATH_TO_SERVER).toString());
    }
    
    public void testUploadFileToServerFromTwoDevices() {
    	setTaskRetryCount();
        DeviceInfo device1 = deviceWithMockScheduler();
        DeviceInfo device2 = deviceWithMockScheduler();
        expectDevice("deviceGuid1", device1);
        expectDevice("deviceGuid2", device2);
        deviceService.uploadFileToServer(asList(new String[] {"deviceGuid1", "deviceGuid2"}), "/home/someFile", PATH_TO_SERVER);
        assertUploadFileToServer(device1, "/home/someFile", WDMUtil.getUploadUrl(PATH_TO_SERVER).toString());
        assertUploadFileToServer(device2, "/home/someFile", WDMUtil.getUploadUrl(PATH_TO_SERVER).toString());
        
    }
    
    public void testSetConfiguration(){
    	DeviceInfo device1 = deviceWithMockScheduler();
        addNetwork(device1);
        expectDevice("deviceGuid1", device1);
        deviceService.setConfiguration("deviceGuid1",sampleBuilder("deviceGuid1"), Schedule.now(),1,false);
		assertSetConfigurationTask(device1);
    }

    private void assertSetConfigurationTask(DeviceInfo device) {
    	Task currentTask = device.getCurrentTask();
		assertTrue(TasksFactory.SET_CONFIGURATION.equals(currentTask.getName()) );
		List<ICommand> commands = currentTask.getCommands();
		assertEquals(2, commands.size());
		assertTrue(commands.get(0) instanceof SetConfigurationCommand);
		assertTrue(commands.get(1) instanceof GetAssetsCommand);
	}

	private void assertDeleteFile(DeviceInfo device, String path) {
        assertEquals(new DeleteFileCommand(path), currentCommand(device));
    }

    private void assertDeleteDirectory(Device device, String path) {
        assertEquals(new DeleteDirectoryCommand(path), currentCommand(device));
    }

    private void assertUninstall(DeviceInfo device, String applicationName) {
        assertEquals(new UninstallFromDeviceCommand(applicationName), currentCommand(device));
    }

    private Collection<String> asList(String deviceGuid){
    	return Arrays.asList(deviceGuid);
    }

    private Collection<String> asList(String[] guid){
    	return Arrays.asList(guid);
    }

    private ICommand currentCommand(Device device) {
        return device.getCurrentTask().getCommands().get(0);
    }

    private DeviceInfo deviceWithTasksInProgress() {
        return new DeviceInfo() {
            public boolean hasTaskInProgress() {
                return true;
            }
        };
    }

    private void expectDeviceDeletion(String deviceGuid) {
        expectDevice(deviceGuid, device);
        mockDeviceRepository.expects(once()).method("delete").with(eq(device()));
    }

    private void expectDevice(String deviceGuid, DeviceInfo device) {
        mockDeviceRepository.expects(once()).method("findByGuid").with(eq(deviceGuid)).will(returnValue(device));
    }

    private DeviceInfo device() {
        return new DeviceInfo();
    }

    private void assertReboot(DeviceInfo device) {
        assertEquals(new RebootCommand(), currentCommand(device));
    }

    private void assertDownloadFileFromServer(DeviceInfo device, String deviceLocation, String repositoryUrl) {
        assertEquals(new DownloadFileFromServerCommand(deviceLocation, repositoryUrl(repositoryUrl)), currentCommand(device));
    }

    private void assertExecute(DeviceInfo device, String execLocation, String command, boolean stdoutenabled, boolean stderrEnabled, boolean writeFilterEnabled) {
        assertEquals(new ExecuteOnDeviceCommand(execLocation, command, stdoutenabled, stderrEnabled, writeFilterEnabled), currentCommand(device));
    }

    private void assertShutdown(DeviceInfo device) {
        assertEquals(new ShutdownCommand(), currentCommand(device));
    }

    private void assertMergeRegistry(DeviceInfo device, String repositoryUrl) {
        assertEquals(new MergeRegistryCommand(repositoryUrl(repositoryUrl)), currentCommand(device));
    }
    
    private Mock mockUserPreferencesRepository() {
		Mock repository = mock(IUserPreferencesRepository.class);
		repository.expects(atLeastOnce()).method("getTaskRetryCount").will(returnValue(0));
		return repository;
	}
    
    private void setTaskRetryCount() {
		deviceService.setUserPreferenceRepository((IUserPreferencesRepository) mockUserPreferencesRepository().proxy());
	}
    
    private void assertUploadFileToServer(DeviceInfo device, String deviceLocation, String repositoryUrl) {
        assertEquals(new UploadFileToServerCommand(deviceLocation, repositoryUrl), currentCommand(device));
    }
    
    private DeviceConfigurationTaskBuilder sampleBuilder(String deviceGuid) {
        DeviceConfigurationTaskBuilder builder = sampleNetworkConfiguration(true);
        builder.setGuids(WDMUtil.asList(deviceGuid));
        return builder;
    }
    
    private DeviceConfigurationTaskBuilder sampleNetworkConfiguration(boolean dhcpEnabled) {
		DeviceConfigurationTaskBuilder builder = new DeviceConfigurationTaskBuilder();
		if(dhcpEnabled){
			builder.put(DeviceConfigurationTaskBuilder.DHCP_ENABLED, "true");
		}
		builder.put(DeviceConfigurationTaskBuilder.DNS_ASSIGNED_FLAG, "false");
		builder.put(DeviceConfigurationTaskBuilder.WINS_ASSIGNED_FLAG, "false");
		builder.put(DeviceConfigurationTaskBuilder.SECONDARY_DNS, "1.1.1.3");
		builder.put(DeviceConfigurationTaskBuilder.PRIMARY_WINS, "1.1.1.4");
		builder.put(DeviceConfigurationTaskBuilder.SECONDARY_WINS, "1.1.1.5");
		return builder;
	}
	
    private void addNetwork(DeviceInfo device) {
		DeviceNetworkInfo activeNetwork = new DeviceNetworkInfo();
		activeNetwork.setMacAddress("11:22:33:44:55:66");
		activeNetwork.setIpAddress("1.1.1.1");
		activeNetwork.setSubnetMask("255.255.255.0");
		activeNetwork.setType("wired");
		activeNetwork.setSpeed("1000");
		activeNetwork.setDuplex("full");
		device.addDeviceNetwork(activeNetwork);
		device.setActiveNetwork(activeNetwork.getIpAddress());
	}
	

}
